/* Pure, dependency-free conservative lumped model. See docs/MODEL.md. */
(function (root) {
  "use strict";
  const VERSION = "4.1.0";
  const R = 287.05, GAMMA = 1.4, CV = R / (GAMMA - 1), CP = CV + R;
  const STICK_SPEED = 1e-5;
  const area = d => Math.PI * (d / 2000) ** 2;
  const DEFAULTS = Object.freeze({
    cylinderBore: 23.157256696, strokeLength: 85, barrelLength: 430, barrelDiameter: 6.01,
    pistonMass: 71, bbMass: .46, bbDiameter: 5.95,
    // Start with an explicitly labelled no-pin reference, not an invented AMP brake fit.
    airbrakeLength: 0, airbrakeDiameter: 3.8, airbrakeTipDiameter: 2, airbrakeTaper: 0,
    headBore: 4, headLength: 12, nozzleBore: 4, nozzleLength: 15,
    // Added annular pad ahead of the rigid head. Zero thickness preserves the
    // bare-head geometry; its bore remains explicit for installed pads.
    bumperThickness: 0, bumperBore: 4,
    // Kelvin-Voigt loading model. These values are illustrative until measured;
    // with a zero-thickness bumper they are inactive and the rigid stop remains.
    bumperStiffness: 250, bumperDamping: 160, bumperMaxCompression: 1,
    bumperCurve: [],
    deadVolume: .55, breechVolume: .45, frontDeadVolume: .05, dischargeCoefficient: .75, muzzleDischargeCoefficient: .85,
    // Optional muzzle suppressor/silencer. Geometry defines a fourth conservative
    // gas volume; outlet Cd, packing fraction and heat transfer remain conditional
    // effective inputs rather than an acoustic/dB model.
    silencerEnabled: 0, silencerLength: 150, silencerInnerDiameter: 28,
    silencerBaffleCount: 5, silencerBaffleThickness: 2, silencerBaffleBore: 8, silencerEndCapBore: 8,
    silencerPackingFraction: 0, silencerDischargeCoefficient: .65, silencerHeatTransfer: .02,
    pistonLeak: .005, nozzleLeak: .005, bbLeakCoefficient: .15,
    springStiffness: 550, springPreload: 50, springMass: 0, springCurve: [],
    springLengthMode: 0, springFreeLength: 0, springInstalledLength: 0, springCutLength: 0,
    springActiveCoils: 0, springRemovedCoils: 0, springSolidLength: 0,
    pistonFriction: 3.2, sealFriction: .01, rearDamping: 0, bbBreakaway: 1.35, barrelDrag: .11,
    restitution: .05, heatTransfer: 0, ambientPressure: 101.3, airTemperature: 20,
    usefulFraction: .95, decelThreshold: 1000, maxTime: 60
  });
  function normalize(raw = {}) { return { ...DEFAULTS, ...raw }; }
  function contactStroke(raw) {
    const p = normalize(raw);
    return (p.strokeLength - p.bumperThickness) / 1000;
  }
  function bumperLimit(raw) {
    const p = normalize(raw);
    return Math.min(p.bumperThickness, p.bumperMaxCompression) / 1000;
  }
  // Lengths are axial mm, not wire length. Rate scaling is a uniform-coil estimate.
  // The entered front seat/preload refers to the rigid-head plane before an
  // added bumper. A bumper moves piston contact rearward while leaving cocked
  // compression unchanged for the same physical spring seats.
  function springState(p) {
    const lengths = p.springLengthMode === 1;
    const cut = lengths ? p.springCutLength : 0;
    const freeLength = lengths ? p.springFreeLength - cut : null;
    const installedLength = lengths ? p.springInstalledLength - p.bumperThickness : null;
    const preload = lengths ? freeLength - installedLength : p.springPreload + p.bumperThickness;
    const travel = (p.strokeLength - p.bumperThickness);
    const rateRatio = cut > 0 ? p.springActiveCoils / (p.springActiveCoils - p.springRemovedCoils) : 1;
    return { freeLength, preload, contactTravel: travel, installedLength,
      cockedCompression: preload + travel,
      cockedLength: lengths ? installedLength - travel : null,
      stiffness: p.springStiffness * rateRatio, rateRatio,
      coilBindChecked: lengths && p.springSolidLength > 0 };
  }
  function validate(raw) {
    const p = normalize(raw), errors = [];
    const positive = ["cylinderBore", "strokeLength", "barrelLength", "barrelDiameter", "pistonMass", "bbMass", "bbDiameter", "bumperBore", "headBore", "headLength", "nozzleBore", "nozzleLength", "deadVolume", "breechVolume", "frontDeadVolume", "silencerLength", "silencerInnerDiameter", "silencerBaffleThickness", "silencerBaffleBore", "silencerEndCapBore", "ambientPressure", "maxTime"];
    for (const key of Object.keys(DEFAULTS)) if (!["springCurve", "bumperCurve"].includes(key) && !Number.isFinite(p[key])) errors.push(`${key}:finite`);
    for (const key of positive) if (!(p[key] > 0)) errors.push(`${key}:positive`);
    for (const key of ["airbrakeLength", "airbrakeDiameter", "airbrakeTipDiameter", "airbrakeTaper", "bumperThickness", "bumperStiffness", "bumperDamping", "bumperMaxCompression", "silencerBaffleCount", "silencerPackingFraction", "silencerHeatTransfer", "springStiffness", "springPreload", "springMass", "pistonLeak", "nozzleLeak", "pistonFriction", "sealFriction", "rearDamping", "bbBreakaway", "barrelDrag", "heatTransfer", "decelThreshold"]) if (p[key] < 0) errors.push(`${key}:nonnegative`);
    if (p.bbDiameter >= p.barrelDiameter) errors.push("bb:clearance");
    if ((p.bumperThickness > 0 && p.cylinderBore <= p.bumperBore) || p.cylinderBore <= p.headBore || p.cylinderBore <= p.airbrakeDiameter) errors.push("cylinder:clearance");
    const maximumPinReach = p.airbrakeLength + Math.min(p.bumperThickness, p.bumperMaxCompression);
    const reachedPinDiameter = start => maximumPinReach > start
      ? pinDiameter(p, Math.min(p.airbrakeLength, maximumPinReach - start) / 1000)
      : 0;
    if (p.airbrakeLength > 0 && (
      (p.bumperThickness > 0 && reachedPinDiameter(0) >= p.bumperBore) ||
      (maximumPinReach > p.bumperThickness && reachedPinDiameter(p.bumperThickness) >= p.headBore) ||
      (maximumPinReach > p.bumperThickness + p.headLength && reachedPinDiameter(p.bumperThickness + p.headLength) >= p.nozzleBore)
    )) errors.push("pin:clearance");
    if (!(p.bumperThickness < p.strokeLength)) errors.push("bumper:thickness");
    if (p.bumperThickness > 0 && p.bumperMaxCompression > 0 && !p.bumperCurve?.length && !(p.bumperStiffness > 0)) errors.push("bumper:stiffness");
    const travel = p.strokeLength - p.bumperThickness;
    if (p.airbrakeLength > travel || maximumPinReach > p.bumperThickness + p.headLength + p.nozzleLength) errors.push("pin:length");
    if (p.airbrakeTipDiameter > p.airbrakeDiameter || p.airbrakeTaper > p.airbrakeLength && p.airbrakeLength > 0) errors.push("pin:profile");
    if (!(p.dischargeCoefficient > 0 && p.dischargeCoefficient <= 1) || !(p.muzzleDischargeCoefficient > 0 && p.muzzleDischargeCoefficient <= 1) || !(p.silencerDischargeCoefficient > 0 && p.silencerDischargeCoefficient <= 1) || !(p.bbLeakCoefficient >= 0 && p.bbLeakCoefficient <= 1) || !(p.restitution >= 0 && p.restitution <= 1)) errors.push("coefficient:range");
    if (!(p.usefulFraction > 0 && p.usefulFraction <= 1) || p.airTemperature <= -273.15 || p.maxTime > 250) errors.push("range:invalid");
    if (![0, 1].includes(p.silencerEnabled)) errors.push("silencer:enabled");
    if (!Number.isInteger(p.silencerBaffleCount) || p.silencerBaffleCount > 50) errors.push("silencer:baffles");
    if (!(p.silencerPackingFraction >= 0 && p.silencerPackingFraction < .9)) errors.push("silencer:packing");
    if (p.silencerBaffleBore >= p.silencerInnerDiameter || p.silencerEndCapBore >= p.silencerInnerDiameter) errors.push("silencer:clearance");
    if (p.silencerEnabled === 1 && (p.silencerBaffleBore <= p.bbDiameter || p.silencerEndCapBore <= p.bbDiameter)) errors.push("silencer:bb-clearance");
    if (p.silencerBaffleCount * p.silencerBaffleThickness >= p.silencerLength) errors.push("silencer:length");
    if (p.silencerEnabled === 1) {
      const silencer = silencerGeometry(p);
      if (!(silencer.freeVolume > 0 && silencer.effectiveOutletArea > 0)) errors.push("silencer:volume");
    }
    if (![0, 1].includes(p.springLengthMode)) errors.push("spring:mode");
    for (const key of ["springFreeLength", "springInstalledLength", "springCutLength", "springActiveCoils", "springRemovedCoils", "springSolidLength"]) if (p[key] < 0) errors.push(`${key}:nonnegative`);
    const spring = springState(p);
    if (p.springLengthMode === 1) {
      if (!(p.springFreeLength > 0 && p.springInstalledLength > p.strokeLength && spring.freeLength > 0)) errors.push("spring:lengths");
      if (spring.preload < 0) errors.push("spring:slack");
      if (p.springCutLength > 0 && !(p.springActiveCoils > 0 && p.springRemovedCoils < p.springActiveCoils)) errors.push("spring:coils");
      if (p.springCutLength === 0 && p.springRemovedCoils > 0) errors.push("spring:cut-length");
      if (p.springSolidLength > 0 && spring.cockedLength <= p.springSolidLength) errors.push("spring:coil-bind");
      if (p.springCutLength > 0 && p.springCurve?.length) errors.push("spring:cut-curve");
    }
    if (!Array.isArray(p.springCurve)) errors.push("spring:curve");
    else if (p.springCurve.length) {
      if (p.springCurve.length < 2 || p.springCurve.some((v, i, a) => !Array.isArray(v) || v.length !== 2 || !v.every(Number.isFinite) || v[0] < 0 || v[1] < 0 || i > 0 && v[0] <= a[i - 1][0])) errors.push("spring:curve");
      else if (p.springCurve[0][0] > spring.preload - bumperLimit(p) * 1000 || p.springCurve.at(-1)[0] < spring.cockedCompression) errors.push("spring:coverage");
    }
    if (!Array.isArray(p.bumperCurve)) errors.push("bumper:curve");
    else if (p.bumperCurve.length) {
      const limit = Math.min(p.bumperThickness, p.bumperMaxCompression);
      if (p.bumperCurve.length < 2 || p.bumperCurve.some((v, i, a) => !Array.isArray(v) || v.length !== 2 || !v.every(Number.isFinite) || v[0] < 0 || v[1] < 0 || i > 0 && (v[0] <= a[i - 1][0] || v[1] < a[i - 1][1]))) errors.push("bumper:curve");
      else if (p.bumperCurve[0][0] !== 0 || p.bumperCurve[0][1] !== 0 || p.bumperCurve.at(-1)[0] < limit) errors.push("bumper:coverage");
    }
    if (!errors.length) {
      const g = geometry(p, contactStroke(p) + bumperLimit(p), 0);
      if (g.vc <= 0 || g.vb <= 0) errors.push("volume:pin");
    }
    return [...new Set(errors)];
  }
  function pinDiameter(p, distanceFromTip) {
    if (distanceFromTip <= 0 || p.airbrakeLength === 0) return 0;
    const f = p.airbrakeTaper > 0 ? Math.min(1, distanceFromTip * 1000 / p.airbrakeTaper) : 1;
    return p.airbrakeTipDiameter + (p.airbrakeDiameter - p.airbrakeTipDiameter) * f;
  }
  function pinVolume(p, length) {
    const l = Math.max(0, Math.min(length, p.airbrakeLength / 1000));
    const taper = Math.min(p.airbrakeTaper, p.airbrakeLength) / 1000;
    const c = Math.min(l, taper), d0 = p.airbrakeTipDiameter / 1000;
    const slope = taper > 0 ? (p.airbrakeDiameter / 1000 - d0) / taper : 0;
    return Math.PI / 4 * (d0 * d0 * c + d0 * slope * c * c + slope * slope * c ** 3 / 3) + area(p.airbrakeDiameter) * Math.max(0, l - taper);
  }
  function geometry(raw, x, y) {
    const p = normalize(raw), ac = area(p.cylinderBore), ab = area(p.barrelDiameter), stroke = contactStroke(p);
    const hardStop = stroke + bumperLimit(p);
    const bumper = p.bumperThickness / 1000;
    const bumperSolidVolume = Math.max(0, ac - area(p.bumperBore)) * bumper;
    const insertion = Math.max(0, p.airbrakeLength / 1000 - (stroke - x));
    const pinLength = p.airbrakeLength / 1000, inserted = Math.min(insertion, pinLength);
    const displaced = pinVolume(p, inserted);
    // Once the whole pin is downstream, further piston travel no longer moves
    // pin volume between the two control volumes.
    const ap = insertion > 0 && insertion < pinLength ? area(pinDiameter(p, insertion)) : 0;
    return {
      ac, ab, stroke, hardStop, insertion, inserted, pinArea: ap,
      vc: p.deadVolume * 1e-6 + ac * (p.strokeLength / 1000 - x) - bumperSolidVolume - pinVolume(p, p.airbrakeLength / 1000) + displaced,
      vb: p.breechVolume * 1e-6 + ab * y - displaced,
      vf: p.frontDeadVolume * 1e-6 + ab * Math.max(0, p.barrelLength / 1000 - y),
      dvc: -ac + ap, dvb: -ap, dvf: y < p.barrelLength / 1000 ? -ab : 0,
      sweptVolume: ac * stroke, barrelVolume: ab * p.barrelLength / 1000,
      bumperSolidVolume,
      bumperGap: (p.bumperBore - p.airbrakeDiameter) / 2,
      bumperAnnulus: Math.PI / 4 * ((p.bumperBore / 1000) ** 2 - (p.airbrakeDiameter / 1000) ** 2),
      gap: (p.headBore - p.airbrakeDiameter) / 2,
      annulus: Math.PI / 4 * ((p.headBore / 1000) ** 2 - (p.airbrakeDiameter / 1000) ** 2)
    };
  }
  function silencerGeometry(raw) {
    const p = normalize(raw), enabled = p.silencerEnabled === 1;
    const length = p.silencerLength / 1000, chamberArea = area(p.silencerInnerDiameter);
    const baffleArea = Math.max(0, chamberArea - area(p.silencerBaffleBore));
    const baffleSolidVolume = p.silencerBaffleCount * baffleArea * p.silencerBaffleThickness / 1000;
    const grossVolume = chamberArea * length;
    const openBeforePacking = Math.max(0, grossVolume - baffleSolidVolume);
    const packingSolidVolume = openBeforePacking * p.silencerPackingFraction;
    const freeVolume = openBeforePacking - packingSolidVolume;
    const apertureArea = Math.min(area(p.silencerBaffleBore), area(p.silencerEndCapBore));
    const openRatio = Math.max(1e-6, area(p.silencerBaffleBore) / chamberArea);
    // A transparent lumped minor-loss proxy: each abrupt baffle contraction,
    // finite plate thickness and porous fill reduce the equivalent outlet area.
    // It is deliberately not presented as CFD or an acoustic transfer function.
    const plateFraction = p.silencerBaffleCount * p.silencerBaffleThickness / p.silencerLength;
    const lossFactor = 1 + p.silencerBaffleCount * (1 - openRatio) ** 2
      + 2 * plateFraction / openRatio + 3 * p.silencerPackingFraction / Math.max(.1, 1 - p.silencerPackingFraction);
    return { enabled, length, chamberArea, grossVolume, baffleSolidVolume, packingSolidVolume, freeVolume,
      apertureArea, openRatio, lossFactor, effectiveOutletArea: enabled ? apertureArea * p.silencerDischargeCoefficient / Math.sqrt(lossFactor) : 0 };
  }
  function springForce(p, x) {
    const spring = springState(p), c = spring.preload + spring.contactTravel - x * 1000;
    if (!p.springCurve?.length) return spring.stiffness * Math.max(0, c) / 1000;
    const pairs = p.springCurve;
    for (let i = 1; i < pairs.length; i++) if (c <= pairs[i][0]) {
      const a = pairs[i - 1], b = pairs[i];
      return a[1] + (b[1] - a[1]) * (c - a[0]) / (b[0] - a[0]);
    }
    return pairs.at(-1)[1];
  }
  function springEnergy(p, x) {
    const end = contactStroke(p);
    const direction = x <= end ? 1 : -1, low = Math.min(x, end), high = Math.max(x, end);
    const points = [low, high];
    const spring = springState(p);
    for (const pair of p.springCurve || []) {
      const at = (spring.preload + spring.contactTravel - pair[0]) / 1000;
      if (at > low && at < high) points.push(at);
    }
    points.sort((a, b) => a - b);
    let sum = 0;
    for (let i = 1; i < points.length; i++) sum += (springForce(p, points[i - 1]) + springForce(p, points[i])) / 2 * (points[i] - points[i - 1]);
    return direction * sum;
  }
  function bumperElasticForce(p, compression) {
    const mm = Math.max(0, compression * 1000), pairs = p.bumperCurve || [];
    if (!pairs.length) return p.bumperStiffness * mm;
    for (let i = 1; i < pairs.length; i++) if (mm <= pairs[i][0]) {
      const a = pairs[i - 1], b = pairs[i];
      return a[1] + (b[1] - a[1]) * (mm - a[0]) / (b[0] - a[0]);
    }
    return pairs.at(-1)[1];
  }
  function bumperPotential(p, compression) {
    const mm = Math.max(0, compression * 1000), pairs = p.bumperCurve || [];
    if (!pairs.length) return .5 * p.bumperStiffness * mm * mm / 1000;
    const points = [[0, 0], ...pairs.filter(pair => pair[0] > 0 && pair[0] < mm), [mm, bumperElasticForce(p, compression)]];
    let energy = 0;
    for (let i = 1; i < points.length; i++) energy += (points[i - 1][1] + points[i][1]) / 2 * (points[i][0] - points[i - 1][0]) / 1000;
    return energy;
  }
  // Isentropic reservoir-to-reservoir short restriction; signed, including choking.
  function massFlow(pa, ta, pb, tb, effectiveArea) {
    // Treat machine-scale pressure equality as equilibrium. The analytic
    // unchoked expression loses significance when its pressure ratio rounds
    // around one and can otherwise seed artificial flow in a static shot.
    if (Math.abs(pa - pb) <= 1e-12 * Math.max(pa, pb) || effectiveArea <= 0) return 0;
    const forward = pa > pb, pu = forward ? pa : pb, pd = forward ? pb : pa, temp = forward ? ta : tb;
    const r = pd / pu, critical = (2 / (GAMMA + 1)) ** (GAMMA / (GAMMA - 1));
    const f = r <= critical
      ? Math.sqrt(GAMMA) * (2 / (GAMMA + 1)) ** ((GAMMA + 1) / (2 * (GAMMA - 1)))
      : Math.sqrt(2 * GAMMA / (GAMMA - 1) * (r ** (2 / GAMMA) - r ** ((GAMMA + 1) / GAMMA)));
    return (forward ? 1 : -1) * effectiveArea * pu / Math.sqrt(R * temp) * f;
  }
  function annularPoiseuille(diameterRatio) {
    const r = Math.max(0, Math.min(.999999, diameterRatio));
    if (r < 1e-6) return 64;
    if (1 - r < 1e-3) return 96;
    const r2 = r * r;
    const denominator = 1 - r2 * r2 - (1 - r2) ** 2 / Math.log(1 / r);
    return 64 * (1 - r) ** 2 * (1 - r2) / denominator;
  }
  // Series loss approximation. The actually overlapped pin interval is sliced
  // along its taper, so each axial element uses its local annular clearance.
  // This is still not a resolved nozzle/pressure-wave model: see limitations.
  function passage(p, insertion, pc, tc, pb, tb) {
    const parts = [];
    const bumperLength = p.bumperThickness / 1000, headLength = p.headLength / 1000;
    const pinLength = p.airbrakeLength / 1000, pinTip = insertion, pinBase = pinTip - pinLength;
    const pushOpen = (length, bore) => {
      if (length > 1e-12) parts.push({ a: area(bore), dh: bore / 1000, l: length, annular: false, poiseuille: 64 });
    };
    for (const [start, length, bore] of [[0, bumperLength, p.bumperBore], [bumperLength, headLength, p.headBore], [bumperLength + headLength, p.nozzleLength / 1000, p.nozzleBore]]) {
      if (length <= 0) continue;
      const end = start + length, lo = Math.max(start, pinBase), hi = Math.min(end, pinTip);
      if (!(hi > lo)) { pushOpen(length, bore); continue; }
      pushOpen(lo - start, bore);
      // A 0.25 mm maximum slice resolves the entered taper without making the
      // ODE cost depend excessively on an unusually long passage.
      const count = Math.min(64, Math.max(1, Math.ceil((hi - lo) / .00025)));
      const slice = (hi - lo) / count;
      for (let index = 0; index < count; index++) {
        const axial = lo + (index + .5) * slice;
        const d = pinDiameter(p, pinTip - axial), a = area(bore) - area(d), dh = (bore - d) / 1000;
        parts.push({ a, dh, l: slice, annular: true, poiseuille: annularPoiseuille(d / bore) });
      }
      pushOpen(end - hi, bore);
    }
    const minArea = Math.min(...parts.map(v => v.a));
    const temp = pc >= pb ? tc : tb;
    const mu = 1.716e-5 * (temp / 273.15) ** 1.5 * (273.15 + 111) / (temp + 111);
    const flux = massFlow(pc, tc, pb, tb, 1);
    if (flux === 0) return { mdot: 0, minArea };
    const k0 = 1 / (minArea * p.dischargeCoefficient) ** 2;
    const c = parts.reduce((sum, q) => sum + q.poiseuille * mu * q.l / (q.dh ** 2 * q.a), 0);
    // Stable positive root of k0*m² + c*m = flux² (all-laminar branch).
    const laminarFlow = 2 * flux ** 2 / (c + Math.sqrt(c * c + 4 * k0 * flux ** 2));
    if (parts.every(q => laminarFlow * q.dh / (q.a * mu) <= 2000)) return { mdot: Math.sign(flux) * laminarFlow, minArea };
    let lo = 0, hi = Math.abs(flux) / Math.sqrt(k0);
    for (let j = 0; j < 32; j++) {
      const mdot = (lo + hi) / 2;
      let resistance = k0;
      for (const q of parts) {
        const re = mdot * q.dh / (q.a * mu);
        const laminar = q.poiseuille / re;
        const blend = Math.max(0, Math.min(1, (re - 2000) / 2000));
        const f = laminar * (1 - blend) + Math.max(laminar, .3164 / re ** .25) * blend;
        resistance += f * q.l / q.dh / q.a ** 2;
      }
      if (mdot * mdot * resistance > flux * flux) hi = mdot; else lo = mdot;
    }
    return { mdot: Math.sign(flux) * (lo + hi) / 2, minArea };
  }
  function frictionForce(force, velocity, friction) {
    if (Math.abs(velocity) < STICK_SPEED && Math.abs(force) <= friction) return force;
    return friction * Math.sign(Math.abs(velocity) < STICK_SPEED ? force : velocity);
  }
  function simulate(raw = {}, options = {}) {
    const p = normalize(raw), errors = validate(p);
    if (errors.length) return { version: VERSION, valid: false, errors, frames: [], exitTime: null, pistonHitTime: null };
    const g0 = geometry(p, 0, 0), sg = silencerGeometry(p), pa = p.ambientPressure * 1000, ta = p.airTemperature + 273.15;
    const mp = (p.pistonMass + p.springMass / 3) / 1000, mbb = p.bbMass / 1000, L = p.barrelLength / 1000;
    // x,v,y,w,mc,Uc,mb,Ub, friction dissipation, external enthalpy,
    // wall heat, ambient boundary work, external mass, BB positive/negative net
    // work, energy dissipated by the compliant bumper, silencer gas mass and
    // silencer gas internal energy. Disabled silencers retain zero state.
    let s = [0, 0, 0, 0, pa * g0.vc / (R * ta), pa * g0.vc / (GAMMA - 1), pa * g0.vb / (R * ta), pa * g0.vb / (GAMMA - 1), 0, 0, 0, 0, 0, 0, 0, 0,
      pa * g0.vf / (R * ta), pa * g0.vf / (GAMMA - 1),
      sg.enabled ? pa * sg.freeVolume / (R * ta) : 0, sg.enabled ? pa * sg.freeVolume / (GAMMA - 1) : 0];
    let t = 0, exited = false, hit = false, contactLoss = 0, rigidContactLoss = 0, muzzleMass = 0, peakOutflow = 0, peakMuzzleTransfer = 0, peakPressure = pa, peakFrontPressure = pa, peakSilencerPressure = pa;
    let exitTime = null, exitVelocity = null, exitPressure = null, exitFrontPressure = null, exitGasMass = null, pistonHitTime = null, impactVelocity = null;
    let engageTime = null, decelTime = null, strongBrakeTime = null, momentumAtEngage = null, brakeEnergy = null, reboundTime = null;
    let preContactReversalTime = null, contactReboundTime = null, peakPistonX = 0, maxPistonRetreat = 0, maxPreContactRetreat = 0;
    const pistonImpacts = [];
    let activeContact = null, maxBumperCompression = 0, peakBumperForce = 0;
    let maxBbEnergy = 0, maxBbTime = 0, peakPistonV = 0, peakCylinderPressure = pa, rejectedSteps = 0, steps = 0, nextStore = 0;
    const frames = [], history = [], maxTime = (options.maxTime ?? p.maxTime) / 1000;
    const maxDt = options.dt ?? 1e-5, tolerance = options.tolerance ?? 2e-5;
    let dt = maxDt;
    const initialEnergy = s[5] + s[7] + s[17] + s[19] + springEnergy(p, 0), initialMass = s[4] + s[6] + s[16] + s[18];
    function evaluate(v) {
      const g = geometry(p, v[0], exited ? L : v[2]);
      const pc = (GAMMA - 1) * v[5] / g.vc, pb = (GAMMA - 1) * v[7] / g.vb, pf = (GAMMA - 1) * v[17] / g.vf;
      const tc = v[5] / (v[4] * CV), tb = v[7] / (v[6] * CV), tf = v[17] / (v[16] * CV);
      const ps = sg.enabled ? (GAMMA - 1) * v[19] / sg.freeVolume : pa;
      const ts = sg.enabled ? v[19] / (v[18] * CV) : ta;
      const pass = passage(p, g.insertion, pc, tc, pb, tb);
      const lc = massFlow(pc, tc, pa, ta, p.pistonLeak * 1e-6);
      const gap = Math.max(0, g.ab - area(p.bbDiameter));
      const nozzleLeak = massFlow(pb, tb, pa, ta, p.nozzleLeak * 1e-6);
      const bbBypass = exited ? 0 : massFlow(pb, tb, pf, tf, gap * p.bbLeakCoefficient);
      const downstreamPressure = sg.enabled ? ps : pa, downstreamTemperature = sg.enabled ? ts : ta;
      const behindMuzzle = exited ? massFlow(pb, tb, downstreamPressure, downstreamTemperature, g.ab * p.muzzleDischargeCoefficient) : 0;
      const frontMuzzle = exited ? 0 : massFlow(pf, tf, downstreamPressure, downstreamTemperature, g.ab * p.muzzleDischargeCoefficient);
      const silencerOutflow = sg.enabled ? massFlow(ps, ts, pa, ta, sg.effectiveOutletArea) : 0;
      const hc = lc * CP * (lc >= 0 ? tc : ta);
      const hn = nozzleLeak * CP * (nozzleLeak >= 0 ? tb : ta);
      const hbb = bbBypass * CP * (bbBypass >= 0 ? tb : tf);
      const hbm = behindMuzzle * CP * (behindMuzzle >= 0 ? tb : downstreamTemperature);
      const hfm = frontMuzzle * CP * (frontMuzzle >= 0 ? tf : downstreamTemperature);
      const hso = silencerOutflow * CP * (silencerOutflow >= 0 ? ts : ta);
      const h = pass.mdot * CP * (pass.mdot >= 0 ? tc : tb);
      const fs = springForce(p, v[0]), gasForce = pa * g.ac + pc * g.dvc + pb * g.dvb;
      const rear = p.rearDamping * v[1];
      const bumperCompression = Math.max(0, v[0] - g.stroke);
      const bumperElastic = bumperElasticForce(p, bumperCompression);
      // Kelvin-Voigt damping is capped on unloading so the pad can push but
      // never pull the piston. The corresponding loss term keeps the energy
      // ledger closed while the deformed pad relaxes.
      const bumperEffectiveDamping = bumperCompression <= 0 ? 0 : v[1] >= 0 ? p.bumperDamping : Math.min(p.bumperDamping, bumperElastic / Math.max(1e-12, -v[1]));
      const bumperDampingForce = bumperEffectiveDamping * v[1];
      const bumperForce = bumperElastic + bumperDampingForce;
      const pistonDrive = fs + gasForce - rear - bumperForce;
      const fp = frictionForce(pistonDrive, v[1], p.pistonFriction + p.sealFriction * Math.max(0, pc - pa) * g.ac);
      let ap = (pistonDrive - fp) / mp;
      if (v[0] <= 0 && v[1] <= 0 && ap < 0 || v[0] >= g.hardStop && v[1] >= 0 && ap > 0) ap = 0;
      const thrust = (pb - pf) * g.ab;
      const fb = exited ? 0 : frictionForce(thrust, v[3], v[2] <= 1e-10 ? p.bbBreakaway : p.barrelDrag);
      let ab = exited ? 0 : (thrust - fb) / mbb;
      if (v[2] <= 0 && v[3] <= 0 && ab < 0) ab = 0;
      const vx = v[1], vy = exited ? 0 : v[3];
      const qc = p.heatTransfer * (ta - tc), qb = p.heatTransfer * (ta - tb), qf = p.heatTransfer * (ta - tf);
      const qs = sg.enabled ? p.silencerHeatTransfer * (ta - ts) : 0;
      const power = exited ? 0 : (thrust - fb) * vy;
      return {
        d: [vx, ap, vy, ab, -pass.mdot - lc, -pc * g.dvc * vx - h - hc + qc,
          pass.mdot - nozzleLeak - bbBypass - behindMuzzle, -pb * (g.dvb * vx + g.ab * vy) + h - hn - hbb - hbm + qb,
          fp * vx + rear * vx + fb * vy, -hc - hn - (sg.enabled ? hso : hbm + hfm), qc + qb + qf + qs, pa * g.ac * vx, -lc - nozzleLeak - (sg.enabled ? silencerOutflow : behindMuzzle + frontMuzzle), Math.max(0, power), Math.max(0, -power),
          bumperEffectiveDamping * vx ** 2,
          bbBypass - frontMuzzle, -pf * g.dvf * vy + hbb - hfm + qf,
          sg.enabled ? behindMuzzle + frontMuzzle - silencerOutflow : 0,
          sg.enabled ? hbm + hfm - hso + qs : 0],
        pc, pb, pf, ps, tc, tb, tf, ts, g, fs, ap, ab, bumperCompression, bumperForce,
        flow: pass.mdot, bbBypass, hbb, hfm, qf, qs, frontOutflow: frontMuzzle,
        muzzleTransfer: behindMuzzle + frontMuzzle, silencerOutflow,
        outflow: exited ? (sg.enabled ? silencerOutflow : behindMuzzle + frontMuzzle) : 0, minArea: pass.minArea
      };
    }
    // The small gas pocket in front of the BB becomes numerically stiff near
    // the muzzle. Advance its mass/internal energy with a local implicit solve
    // while the coupled piston/BB states retain the adaptive midpoint method.
    function advanceFront(start, target, h, workPressure) {
      if (exited) return { mass: start[16], energy: start[17], bypassMass: 0, muzzleMass: 0, bypassEnergy: 0, muzzleEnergy: 0, heatEnergy: 0 };
      const gStart = geometry(p, start[0], exited ? L : start[2]);
      const gEnd = geometry(p, target[0], exited ? L : target[2]);
      const pb = (GAMMA - 1) * target[7] / gEnd.vb, tb = target[7] / (target[6] * CV);
      const ps = sg.enabled ? (GAMMA - 1) * target[19] / sg.freeVolume : pa;
      const ts = sg.enabled ? target[19] / (target[18] * CV) : ta;
      const gap = Math.max(0, gEnd.ab - area(p.bbDiameter));
      const dVolume = gEnd.vf - gStart.vf;
      const m0 = start[16], u0 = start[17];
      const transport = (m, u) => {
        const pf = (GAMMA - 1) * u / gEnd.vf, tf = u / (m * CV);
        const bypass = exited ? 0 : massFlow(pb, tb, pf, tf, gap * p.bbLeakCoefficient);
        const muzzle = massFlow(pf, tf, ps, ts, gEnd.ab * p.muzzleDischargeCoefficient);
        const hb = bypass * CP * (bypass >= 0 ? tb : tf);
        const hm = muzzle * CP * (muzzle >= 0 ? tf : ts);
        const q = p.heatTransfer * (ta - tf);
        return { pf, bypass, muzzle, hb, hm, q };
      };
      const residual = (m, u) => {
        const transfer = transport(m, u);
        return [m - m0 - h * (transfer.bypass - transfer.muzzle), u - u0 + workPressure * dVolume - h * (transfer.hb - transfer.hm + transfer.q)];
      };
      let m = Math.max(1e-14, m0), u = Math.max(1e-9, u0 * (gStart.vf / gEnd.vf) ** (GAMMA - 1));
      for (let iteration = 0; iteration < 24; iteration++) {
        const f = residual(m, u), norm = Math.max(Math.abs(f[0]) / Math.max(m0, 1e-12), Math.abs(f[1]) / Math.max(u0, 1e-8));
        if (norm < 1e-9) {
          const transfer = transport(m, u);
          return { mass: m, energy: u, bypassMass: h * transfer.bypass, muzzleMass: h * transfer.muzzle,
            bypassEnergy: h * transfer.hb, muzzleEnergy: h * transfer.hm, heatEnergy: h * transfer.q };
        }
        const dm = Math.max(1e-13, Math.abs(m) * 1e-6), du = Math.max(1e-9, Math.abs(u) * 1e-6);
        const fm = residual(m + dm, u), fu = residual(m, u + du);
        const a = (fm[0] - f[0]) / dm, b = (fu[0] - f[0]) / du;
        const c = (fm[1] - f[1]) / dm, d = (fu[1] - f[1]) / du, det = a * d - b * c;
        if (!Number.isFinite(det) || Math.abs(det) < 1e-24) return null;
        const stepM = (-f[0] * d + b * f[1]) / det, stepU = (c * f[0] - a * f[1]) / det;
        let damping = 1;
        while (damping > 1 / 1024 && (m + damping * stepM <= 1e-14 || u + damping * stepU <= 1e-9)) damping /= 2;
        m += damping * stepM; u += damping * stepU;
        if (!Number.isFinite(m) || !Number.isFinite(u) || m <= 0 || u <= 0) return null;
      }
      const f = residual(m, u);
      if (Math.max(Math.abs(f[0]) / Math.max(m0, 1e-12), Math.abs(f[1]) / Math.max(u0, 1e-8)) >= 1e-9) return null;
      const transfer = transport(m, u);
      return { mass: m, energy: u, bypassMass: h * transfer.bypass, muzzleMass: h * transfer.muzzle,
        bypassEnergy: h * transfer.hb, muzzleEnergy: h * transfer.hm, heatEnergy: h * transfer.q };
    }
    const validState = v => v.every(Number.isFinite) && v[4] > 0 && v[5] > 0 && v[6] > 0 && v[7] > 0 && v[16] > 0 && v[17] > 0 && (!sg.enabled || v[18] > 0 && v[19] > 0) && geometry(p, v[0], exited ? L : v[2]).vc > 0 && geometry(p, v[0], exited ? L : v[2]).vb > 0 && geometry(p, v[0], exited ? L : v[2]).vf > 0;
    const bumperEnergy = v => bumperPotential(p, Math.max(0, v[0] - g0.stroke));
    const totalEnergy = v => v[5] + v[7] + v[17] + v[19] + springEnergy(p, v[0]) + .5 * mp * v[1] ** 2 + .5 * mbb * v[3] ** 2 + bumperEnergy(v);
    function frame(e) {
      return { t, pistonX: s[0], pistonV: s[1], pistonA: e.ap, bbX: s[2], bbV: s[3], bbA: e.ab, pressure: e.pb, frontPressure: e.pf, silencerPressure: e.ps, cylinderPressure: e.pc, cylinderTemperature: e.tc, bbTemperature: e.tb, frontTemperature: e.tf, silencerTemperature: e.ts,
        insertion: e.g.insertion, flow: e.flow, frontOutflow: e.frontOutflow, muzzleTransfer: e.muzzleTransfer, silencerOutflow: e.silencerOutflow, outflow: e.outflow, openArea: e.minArea,
        bumperCompression: e.bumperCompression, bumperForce: e.bumperForce, pistonHit: hit, bbExited: exited,
        energyResidual: totalEnergy(s) + s[8] + contactLoss + s[15] - initialEnergy - s[9] - s[10] - s[11] };
    }
    const compliantBumper = g0.hardStop > g0.stroke + 1e-12;
    function beginContact(contactState, incomingVelocity) {
      if (pistonHitTime === null) { pistonHitTime = t; impactVelocity = incomingVelocity; }
      hit = true;
      const event = { index: pistonImpacts.length + 1, time: t, incomingVelocity, reboundVelocity: null,
        pistonEnergy: .5 * p.pistonMass / 1000 * incomingVelocity ** 2,
        effectiveMovingEnergy: .5 * mp * incomingVelocity ** 2, dissipatedEnergy: 0,
        peakCompression: 0, peakForce: 0, duration: null, bottomedOut: false,
        cylinderPressure: contactState.pc, bbPressure: contactState.pb,
        _dampingStart: s[15], _hardLossStart: rigidContactLoss };
      pistonImpacts.push(event); activeContact = event;
      return event;
    }
    function updateContact(contactState) {
      if (!activeContact) return;
      activeContact.peakCompression = Math.max(activeContact.peakCompression, contactState.bumperCompression);
      activeContact.peakForce = Math.max(activeContact.peakForce, contactState.bumperForce);
      activeContact.dissipatedEnergy = s[15] - activeContact._dampingStart + rigidContactLoss - activeContact._hardLossStart;
      maxBumperCompression = Math.max(maxBumperCompression, contactState.bumperCompression);
      peakBumperForce = Math.max(peakBumperForce, contactState.bumperForce);
    }
    function finishContact(reboundVelocity, endTime = t, settled = false) {
      if (!activeContact) return;
      activeContact.reboundVelocity = reboundVelocity;
      activeContact.duration = Math.max(0, endTime - activeContact.time);
      activeContact.settledInContact = settled;
      activeContact.complete = reboundVelocity !== null || settled;
      activeContact.dissipatedEnergy = s[15] - activeContact._dampingStart + rigidContactLoss - activeContact._hardLossStart;
      delete activeContact._dampingStart; delete activeContact._hardLossStart;
      activeContact = null;
    }
    const maxSteps = options.maxSteps ?? 300000;
    let convergenceFailure = false, terminationReason = "max-time", settledSince = null;
    while (t < maxTime && steps < maxSteps) {
      let e = evaluate(s), h = Math.min(dt, maxTime - t);
      // Limit steps at geometric transitions and approximate event crossings.
      for (const [at, pos, vel] of [[g0.stroke - p.airbrakeLength / 1000, s[0], s[1]], [g0.stroke, s[0], s[1]], [g0.hardStop, s[0], s[1]], [0, s[0], s[1]], [L, s[2], exited ? 0 : s[3]], [0, s[2], exited ? 0 : s[3]]]) {
        const eta = (at - pos) / vel;
        if (eta > 1e-9 && eta < h) h = eta;
      }
      if (t >= nextStore || t === 0) { frames.push(frame(e)); nextStore = t + (options.sampleInterval ?? .00005); }
      const mid = s.map((v, i) => v + e.d[i] * h / 2), frontMid = advanceFront(s, mid, h / 2, e.pf);
      if (frontMid) { mid[16] = frontMid.mass; mid[17] = frontMid.energy; }
      if (!frontMid || !validState(mid)) { dt = h / 2; rejectedSteps++; if (dt < 1e-10) { convergenceFailure = true; terminationReason = "minimum-step"; break; } continue; }
      const em = evaluate(mid), next = s.map((v, i) => v + em.d[i] * h);
      const frontFull = advanceFront(s, next, h, em.pf);
      if (frontFull) {
        // Replace only the stiff front-volume update, then distribute its
        // transport corrections to the actual connected reservoirs. This
        // preserves mass/energy without disguising solver correction as an
        // arbitrary external source.
        next[6] -= frontFull.bypassMass - h * em.bbBypass;
        next[7] -= frontFull.bypassEnergy - h * em.hbb;
        if (sg.enabled) {
          next[18] += frontFull.muzzleMass - h * em.frontOutflow;
          next[19] += frontFull.muzzleEnergy - h * em.hfm;
        } else {
          next[12] -= frontFull.muzzleMass - h * em.frontOutflow;
          next[9] -= frontFull.muzzleEnergy - h * em.hfm;
        }
        next[10] += frontFull.heatEnergy - h * em.qf;
        next[16] = frontFull.mass; next[17] = frontFull.energy;
      }
      const scales = [g0.hardStop, 10, L, 100, initialMass, initialEnergy, initialMass, initialEnergy, 1, 1, 1, 1, initialMass, 1, 1, 1, initialMass, initialEnergy, initialMass, initialEnergy];
      let error = 0;
      for (let i = 0; i < 8; i++) error = Math.max(error, Math.abs((em.d[i] - e.d[i]) * h) / Math.max(scales[i] * .01, Math.abs(s[i]), Math.abs(next[i])));
      if (!frontFull || !validState(next) || error > tolerance && h > 1e-9) { dt = h * Math.max(.15, .8 * Math.sqrt(tolerance / Math.max(error, tolerance))); rejectedSteps++; if (dt < 1e-10) { convergenceFailure = true; terminationReason = "minimum-step"; break; } continue; }
      const prev = s;
      s = next; t += h; steps++;
      dt = Math.min(maxDt, h * Math.max(1.02, Math.min(2, .9 * Math.sqrt(tolerance / Math.max(error, 1e-14)))));
      // Remove infinitesimal friction overshoot at zero speed; this loss is accounted for.
      for (const [pos, vel, mass] of [[0, 1, mp], [2, 3, mbb]]) {
        if (pos === 2 && exited) continue;
        if (prev[vel] * s[vel] < 0 && Math.abs(s[vel]) < .001) { contactLoss += .5 * mass * s[vel] ** 2; s[vel] = 0; }
        if (s[pos] < 0) { s[pos] = 0; contactLoss += .5 * mass * s[vel] ** 2; s[vel] = 0; }
      }
      // Capture the static-friction branch after finite-step roundoff has left
      // an otherwise force-balanced body with a microscopic residual speed.
      const sticking = evaluate(s);
      for (const [vel, mass, acceleration] of [[1, mp, sticking.ap], [3, mbb, exited ? 0 : sticking.ab]]) {
        if (Math.abs(s[vel]) < STICK_SPEED && Math.abs(acceleration) < 1e-12) {
          contactLoss += .5 * mass * s[vel] ** 2; s[vel] = 0;
        }
      }
      // Compliant pads begin a finite contact episode at the undeformed face.
      // A zero-compression pad retains the exact rigid-boundary event model.
      if (compliantBumper && !activeContact && prev[0] < g0.stroke - 1e-11 && s[0] >= g0.stroke - 1e-11 && s[1] > 0) {
        s[0] = g0.stroke;
        const contactState = evaluate(s);
        beginContact(contactState, s[1]); frames.push(frame(contactState));
      }
      if (compliantBumper && activeContact && s[0] >= g0.hardStop - 1e-11 && s[1] > 0) {
        s[0] = g0.hardStop;
        const contactState = evaluate(s), incomingVelocity = s[1];
        frames.push(frame(contactState)); activeContact.bottomedOut = true;
        const hardLoss = .5 * mp * incomingVelocity ** 2 * (1 - p.restitution ** 2);
        contactLoss += hardLoss; rigidContactLoss += hardLoss; s[1] *= -p.restitution;
        if (Math.abs(s[1]) < .005) { const settleLoss = .5 * mp * s[1] ** 2; contactLoss += settleLoss; rigidContactLoss += settleLoss; s[1] = 0; }
        updateContact(evaluate(s)); frames.push(frame(evaluate(s)));
      } else if (!compliantBumper && s[0] >= g0.stroke - 1e-11 && s[1] > 0) {
        s[0] = g0.stroke;
        const contactState = evaluate(s), incomingVelocity = s[1];
        frames.push(frame(contactState)); beginContact(contactState, incomingVelocity);
        const hardLoss = .5 * mp * incomingVelocity ** 2 * (1 - p.restitution ** 2);
        contactLoss += hardLoss; rigidContactLoss += hardLoss; s[1] *= -p.restitution;
        if (Math.abs(s[1]) < .005) { const settleLoss = .5 * mp * s[1] ** 2; contactLoss += settleLoss; rigidContactLoss += settleLoss; s[1] = 0; }
        finishContact(s[1]); frames.push(frame(evaluate(s)));
      }
      e = evaluate(s);
      updateContact(e);
      if (compliantBumper && activeContact && prev[0] > g0.stroke + 1e-11 && s[0] <= g0.stroke + 1e-11 && s[1] < 0) {
        s[0] = g0.stroke; e = evaluate(s); updateContact(e); finishContact(s[1]); frames.push(frame(e));
      }
      if (!exited && s[2] >= L - 1e-11 && s[3] > 0) {
        s[2] = L; exited = true; exitTime = t; exitVelocity = s[3]; exitPressure = e.pb; exitFrontPressure = e.pf; exitGasMass = s[4] + s[6] + s[16];
        // Once the BB clears the crown, the tiny front pocket is no longer a
        // bounded control volume. Replace it with ambient gas and book the
        // exact mass/energy exchange before continuing the post-exit solution.
        const exitGeometry = geometry(p, s[0], L);
        const ambientFrontMass = pa * exitGeometry.vf / (R * ta), ambientFrontEnergy = pa * exitGeometry.vf / (GAMMA - 1);
        if (sg.enabled) {
          s[18] += s[16] - ambientFrontMass; s[19] += s[17] - ambientFrontEnergy;
        } else {
          s[12] += ambientFrontMass - s[16]; s[9] += ambientFrontEnergy - s[17];
        }
        s[16] = ambientFrontMass; s[17] = ambientFrontEnergy;
        e = evaluate(s);
      }
      if (p.airbrakeLength > 0 && engageTime === null && e.g.insertion > 0) { engageTime = t; momentumAtEngage = p.pistonMass / 1000 * s[1]; }
      if (decelTime === null && s[1] > .05 && e.ap < 0) decelTime = t;
      if (strongBrakeTime === null && e.g.insertion > 0 && e.bumperCompression <= 1e-12 && s[1] > .05 && e.ap < -p.decelThreshold) { strongBrakeTime = t; brakeEnergy = .5 * mbb * s[3] ** 2; }
      if (reboundTime === null && s[1] < -.005) reboundTime = t;
      if (!hit && preContactReversalTime === null && s[1] < -.005) preContactReversalTime = t;
      if (hit && contactReboundTime === null && s[1] < -.005) contactReboundTime = t;
      peakPistonX = Math.max(peakPistonX, s[0]);
      maxPistonRetreat = Math.max(maxPistonRetreat, peakPistonX - s[0]);
      if (!hit) maxPreContactRetreat = Math.max(maxPreContactRetreat, peakPistonX - s[0]);
      const ke = .5 * mbb * s[3] ** 2;
      if (!exited || exitTime === t) { history.push([t, ke]); if (ke > maxBbEnergy) { maxBbEnergy = ke; maxBbTime = t; } }
      peakPressure = Math.max(peakPressure, e.pb); peakFrontPressure = Math.max(peakFrontPressure, e.pf); peakSilencerPressure = Math.max(peakSilencerPressure, e.ps); peakCylinderPressure = Math.max(peakCylinderPressure, e.pc); peakPistonV = Math.max(peakPistonV, s[1]);
      peakMuzzleTransfer = Math.max(peakMuzzleTransfer, e.muzzleTransfer);
      peakOutflow = Math.max(peakOutflow, e.outflow); muzzleMass += Math.max(0, em.outflow) * h;
      const quietGas = exited && hit && t > Math.max(exitTime, pistonHitTime) + .004 && Math.abs(e.pc - pa) < .002 * pa && Math.abs(e.pb - pa) < .002 * pa && (!sg.enabled || Math.abs(e.ps - pa) < .002 * pa);
      const stablePiston = Math.abs(s[1]) < .005 && Math.abs(e.ap) < 1;
      if (quietGas && stablePiston) {
        if (settledSince === null) settledSince = t;
        if (t - settledSince >= .00025) { terminationReason = "settled"; break; }
      } else settledSince = null;
    }
    if (steps >= maxSteps && t < maxTime - 1e-12) { convergenceFailure = true; terminationReason = "step-limit"; }
    const final = evaluate(s), pistonSettled = Math.abs(s[1]) < .005 && Math.abs(final.ap) < 1;
    updateContact(final); finishContact(null, t, pistonSettled && terminationReason === "settled"); frames.push(frame(final));
    const numericalFailure = convergenceFailure;
    let usefulTime = null;
    if (exitTime !== null && maxBbEnergy > 1e-9) {
      const i = history.findIndex(v => v[1] >= p.usefulFraction * maxBbEnergy);
      if (i >= 0) {
        const b = history[i], a = history[Math.max(0, i - 1)];
        usefulTime = b[1] === a[1] ? b[0] : a[0] + (b[0] - a[0]) * (p.usefulFraction * maxBbEnergy - a[1]) / (b[1] - a[1]);
      }
    }
    const exitEnergy = exitVelocity === null ? null : .5 * mbb * exitVelocity ** 2;
    const massResidual = s[4] + s[6] + s[16] + s[18] - initialMass - s[12];
    const pulseFrames = exited && peakOutflow > 0 ? frames.filter(value => value.t >= exitTime && value.outflow >= peakOutflow * .1) : [];
    const outflowPulseDuration = pulseFrames.length > 1 ? pulseFrames.at(-1).t - pulseFrames[0].t : null;
    for (const value of frames) { value.waveTransit = 0; value.wavePressureEstimate = value.pressure; }
    const waveFrames = frames.filter(value => exitTime === null || value.t <= exitTime + 1e-12);
    const interpolatePressure = time => {
      if (time <= waveFrames[0].t) return waveFrames[0].pressure;
      let lo = 0, hi = waveFrames.length;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (waveFrames[mid].t <= time) lo = mid + 1; else hi = mid; }
      const a = waveFrames[Math.max(0, lo - 1)], b = waveFrames[Math.min(lo, waveFrames.length - 1)];
      return b.t === a.t ? b.pressure : a.pressure + (b.pressure - a.pressure) * (time - a.t) / (b.t - a.t);
    };
    let maxWaveTransit = 0, maxWavePressureDelta = 0, exitWavePressure = null;
    const breechEquivalentLength = p.breechVolume * 1e-6 / g0.ab;
    for (const value of waveFrames) {
      const soundSpeed = Math.sqrt(GAMMA * R * Math.max(1, value.bbTemperature));
      const transit = Math.min(L, breechEquivalentLength + Math.max(0, value.bbX)) / soundSpeed;
      const delayed = interpolatePressure(Math.max(0, value.t - transit));
      value.waveTransit = transit; value.wavePressureEstimate = delayed;
      maxWaveTransit = Math.max(maxWaveTransit, transit);
      maxWavePressureDelta = Math.max(maxWavePressureDelta, Math.abs(delayed - value.pressure));
    }
    const timingGap = strongBrakeTime !== null && usefulTime !== null ? Math.abs(strongBrakeTime - usefulTime)
      : engageTime !== null && exitTime !== null ? Math.abs(exitTime - engageTime)
        : usefulTime !== null && exitTime !== null ? Math.abs(exitTime - usefulTime) : null;
    if (exitTime !== null && waveFrames.length) {
      const last = waveFrames.at(-1), soundSpeed = Math.sqrt(GAMMA * R * Math.max(1, last.bbTemperature));
      const transit = Math.min(L, breechEquivalentLength + L) / soundSpeed;
      exitWavePressure = interpolatePressure(Math.max(0, exitTime - transit));
    }
    const pressureScale = Math.max(10000, peakPressure - pa);
    const waveDiagnostics = {
      // This is a causal travel-time comparison against the lumped trace. The
      // 24-cell value is only a reference resolution for a future 1D model; it
      // must not be presented as though 24 conservation cells were solved here.
      method: "causal-travel-envelope", referenceCellCount: 24, maxTransit: maxWaveTransit, referenceCellTransit: maxWaveTransit / 24,
      maxPressureDelta: maxWavePressureDelta, relativePressureSpan: maxWavePressureDelta / pressureScale,
      exitPressureEstimate: exitWavePressure, timingGap, timingRatio: timingGap > 0 ? maxWaveTransit / timingGap : null
    };
    waveDiagnostics.risk = waveDiagnostics.relativePressureSpan < .1 && (waveDiagnostics.timingRatio === null || waveDiagnostics.timingRatio < .1) ? "low"
      : waveDiagnostics.relativePressureSpan < .35 && (waveDiagnostics.timingRatio === null || waveDiagnostics.timingRatio < .5) ? "moderate" : "high";
    return { version: VERSION, params: p, valid: !numericalFailure, errors: numericalFailure ? ["solver:convergence"] : [], frames,
      duration: t, stroke: g0.stroke, hardStop: g0.hardStop, nominalStroke: p.strokeLength / 1000, bumperThickness: p.bumperThickness / 1000,
      barrelLength: L, barrelVolume: g0.barrelVolume, cylinderVolume: g0.sweptVolume, ratio: g0.sweptVolume / g0.barrelVolume,
      silencerEnabled: sg.enabled, silencerVolume: sg.freeVolume, silencerExpansionRatio: sg.enabled ? sg.freeVolume / g0.barrelVolume : null,
      ambientPressure: pa, engageTime, decelTime, strongBrakeTime, reboundTime, usefulTime, exitTime, pistonHitTime,
      preContactReversalTime, contactReboundTime, maxPistonRetreat, maxPreContactRetreat,
      pistonImpacts, maxBumperCompression, peakBumperForce, bumperDissipatedEnergy: s[15],
      exitVelocity, exitEnergy, exitPressure, exitFrontPressure, exitGasMass, pistonImpactVelocity: impactVelocity,
      impactEnergy: impactVelocity === null ? null : .5 * p.pistonMass / 1000 * impactVelocity ** 2,
      momentumAtEngage, preBrakeShare: brakeEnergy === null || !exitEnergy ? null : brakeEnergy / exitEnergy,
      maxBbEnergy, maxBbTime, bbEnergyLoss: exitEnergy === null ? null : Math.max(0, maxBbEnergy - exitEnergy),
      positiveBbWork: s[13], negativeBbWork: s[14], peakPressure, peakFrontPressure, peakSilencerPressure, peakCylinderPressure, peakPistonV, peakOutflow, peakMuzzleTransfer, outflowPulseDuration, muzzleMass,
      energyResidual: frame(final).energyResidual, massResidual, releasedSpringEnergy: springEnergy(p, 0) - springEnergy(p, s[0]),
      energyScale: Math.max(.01, springEnergy(p, 0)), steps, rejectedSteps,
      soundCrossingTime: L / Math.sqrt(GAMMA * R * ta), complete: exited && hit,
      terminationReason, pistonSettled, waveDiagnostics,
      dischargeComplete: exited && Math.abs(final.pc - pa) < .01 * pa && Math.abs(final.pb - pa) < .01 * pa && (!sg.enabled || Math.abs(final.ps - pa) < .01 * pa)
    };
  }
  const api = { VERSION, DEFAULTS, R, GAMMA, CV, normalize, validate, contactStroke, bumperLimit, geometry, silencerGeometry, pinVolume, pinDiameter, springState, springForce, springEnergy, bumperElasticForce, bumperPotential, massFlow, passage, simulate };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.PneumaticPhysics = api;
})(typeof globalThis !== "undefined" ? globalThis : this);


(function (root) {
  "use strict";
  const P = typeof module !== "undefined" && module.exports ? require("./physics.js") : root.PneumaticPhysics;
  const SCHEMA = 3, KEY = "ssg10-pneumatic-lab-v3", OLD_KEY = "ssg10-pneumatic-lab-v2";
  const LENGTH_FIELDS = ["springLengthMode", "springFreeLength", "springInstalledLength", "springCutLength", "springActiveCoils", "springRemovedCoils", "springSolidLength"];
  const BUMPER_FIELDS = ["bumperThickness", "bumperBore"];
  const MODEL_34_FIELDS = ["bumperStiffness", "bumperDamping", "bumperMaxCompression", "muzzleDischargeCoefficient"];
  const MODEL_40_FIELDS = ["frontDeadVolume", "bumperCurve"];
  const MODEL_41_FIELDS = ["silencerEnabled", "silencerLength", "silencerInnerDiameter", "silencerBaffleCount", "silencerBaffleThickness", "silencerBaffleBore", "silencerEndCapBore", "silencerPackingFraction", "silencerDischargeCoefficient", "silencerHeatTransfer"];
  const PARAMETER_SPECS = Object.freeze({
    dischargeCoefficient: { min: .1, max: 1 }, muzzleDischargeCoefficient: { min: .1, max: 1 },
    silencerDischargeCoefficient: { min: .1, max: 1 },
    bbLeakCoefficient: { min: 0, max: 1 }, barrelDrag: { min: 0, max: 2 },
    pistonFriction: { min: 0, max: 20 }, sealFriction: { min: 0, max: .2 },
    bumperStiffness: { min: 10, max: 5000 }, bumperDamping: { min: 0, max: 1000 },
    springStiffness: { min: 100, max: 4000 }
  });
  const fps = v => v / .3048;
  const energy = (mass, speed) => .5 * mass / 1000 * (speed * .3048) ** 2;
  function reference() {
    return { id: "supplied-reference", bbMass: .46, fps: 330, sigma: 1, role: "reference", setup: null, confirmed: false, notes: "Supplied measurement; hardware configuration incomplete.", provenance: {}, solverVersion: null };
  }
  function cleanRecord(row, legacy = false) {
    if (!row || typeof row !== "object") return null;
    const mass = Number(row.bbMass ?? row.mass ?? row.setup?.bbMass), speed = Number(row.fps ?? row.velocityFps);
    if (!(mass > 0 && mass <= 2 && speed > 0 && speed <= 2000)) return null;
    const sigma = Number(row.sigma ?? 1);
    // Only fill fields that did not exist in an otherwise complete historical
    // snapshot. v3.2 used headBore as the implicit bumper opening, so preserve
    // that geometry explicitly instead of inventing the new default.
    const missingByVersion = {
      "4.0.0": MODEL_41_FIELDS,
      "3.4.0": [...MODEL_40_FIELDS, ...MODEL_41_FIELDS],
      "3.0.0": [...LENGTH_FIELDS, ...BUMPER_FIELDS, ...MODEL_34_FIELDS, ...MODEL_40_FIELDS, ...MODEL_41_FIELDS],
      "3.1.1": [...BUMPER_FIELDS, ...MODEL_34_FIELDS, ...MODEL_40_FIELDS, ...MODEL_41_FIELDS],
      "3.2.0": ["bumperBore", ...MODEL_34_FIELDS, ...MODEL_40_FIELDS, ...MODEL_41_FIELDS],
      "3.3.0": [...MODEL_34_FIELDS, ...MODEL_40_FIELDS, ...MODEL_41_FIELDS]
    };
    const expectedMissing = missingByVersion[row.solverVersion];
    const previousComplete = row.setup && expectedMissing && expectedMissing.every(k => !Object.hasOwn(row.setup, k)) && Object.keys(P.DEFAULTS).filter(k => !expectedMissing.includes(k)).every(k => Object.hasOwn(row.setup, k));
    const setupComplete = row.setup && (previousComplete || Object.keys(P.DEFAULTS).every(k => Object.hasOwn(row.setup, k)));
    const migratedSetup = previousComplete ? { ...row.setup,
      ...(!Object.hasOwn(row.setup, "bumperThickness") ? { bumperThickness: 0 } : {}),
      ...(!Object.hasOwn(row.setup, "bumperBore") ? { bumperBore: row.setup.headBore } : {}),
      ...Object.fromEntries([...MODEL_34_FIELDS, ...MODEL_40_FIELDS, ...MODEL_41_FIELDS].filter(key => !Object.hasOwn(row.setup, key)).map(key => [key, P.DEFAULTS[key]]))
    } : row.setup;
    const setup = !legacy && setupComplete && P.validate(migratedSetup).length === 0 ? P.normalize(migratedSetup) : null;
    const provenance = Object.fromEntries(Object.entries(row.provenance || {}).filter(([k, v]) => ["geometry", "spring"].includes(k) && ["assumed", "measured"].includes(v)));
    const confirmed = row.confirmed === true && Boolean(setup);
    const role = confirmed && ["train", "validation"].includes(row.role) ? row.role : "reference";
    const optional = (value, low, high) => { if (value === "" || value === null || value === undefined) return null; const number = Number(value); return Number.isFinite(number) && number >= low && number <= high ? number : null; };
    return { id: String(row.id || `measurement-${Math.random().toString(36).slice(2)}`).slice(0, 100), bbMass: mass, fps: speed, sigma: sigma > 0 && sigma <= 100 ? sigma : 1,
      pistonHitMs: optional(row.pistonHitMs, 0, 1000), pistonHitSigmaMs: optional(row.pistonHitSigmaMs, .001, 100) || .1,
      peakCylinderBarG: optional(row.peakCylinderBarG, 0, 100), peakCylinderSigmaBar: optional(row.peakCylinderSigmaBar, .001, 20) || .05,
      peakSilencerBarG: optional(row.peakSilencerBarG, 0, 100), peakSilencerSigmaBar: optional(row.peakSilencerSigmaBar, .001, 20) || .05,
      peakBumperForceN: optional(row.peakBumperForceN, 0, 100000), peakBumperForceSigmaN: optional(row.peakBumperForceSigmaN, .01, 10000) || 5,
      role, setup, confirmed, provenance, notes: String(row.notes || "").slice(0, 2000), solverVersion: legacy ? null : String(row.solverVersion || ""),
      legacySetup: legacy || !setup || previousComplete ? row.setup || row.legacySetup || null : row.legacySetup || null };
  }
  function decode(data) {
    const raw = typeof data === "string" ? JSON.parse(data) : data;
    if (!raw || typeof raw !== "object") throw new Error("dataset:invalid");
    const rows = Array.isArray(raw) ? raw : raw.measurements;
    if (!Array.isArray(rows) || rows.length > 2000) throw new Error("dataset:records");
    const legacy = raw.schemaVersion !== SCHEMA;
    return { schemaVersion: SCHEMA, solverVersion: P.VERSION, measurements: rows.map(r => cleanRecord(r, legacy)).filter(Boolean), migrated: legacy };
  }
  function encode(rows) { return { schemaVersion: SCHEMA, solverVersion: P.VERSION, measurements: rows }; }
  function eligible(row) { return row.confirmed && row.setup && !(row.setup.springLengthMode === 1 && row.setup.springCutLength > 0) && row.solverVersion === P.VERSION && row.provenance?.geometry === "measured" && row.provenance?.spring === "measured" && ["train", "validation"].includes(row.role); }
  function groups(rows, fitted = ["dischargeCoefficient"]) {
    const map = new Map();
    for (const r of rows) {
      const setup = { ...r.setup, bbMass: r.bbMass };
      const identity = Object.fromEntries(Object.entries(setup).filter(([k]) => ![...fitted, "maxTime", "decelThreshold", "usefulFraction", ...LENGTH_FIELDS].includes(k)));
      // Only the force/compression law enters the ODE. Hidden inputs and alternate
      // ways of entering that same law cannot manufacture independent conditions.
      const spring = P.springState(setup);
      identity.springPreload = spring.preload;
      if (setup.springCurve.length) delete identity.springStiffness;
      else if (!fitted.includes("springStiffness")) identity.springStiffness = spring.stiffness;
      const key = JSON.stringify(identity);
      if (!map.has(key)) map.set(key, { setup, rows: [] });
      map.get(key).setup.maxTime = Math.max(map.get(key).setup.maxTime, setup.maxTime);
      map.get(key).rows.push(r);
    }
    return [...map.values()];
  }
  function residualTerms(shot, row) {
    if (!shot.valid || shot.exitVelocity === null) return null;
    const terms = [{ kind: "fps", raw: fps(shot.exitVelocity) - row.fps, sigma: row.sigma }];
    if (Number.isFinite(row.pistonHitMs)) {
      if (shot.pistonHitTime === null) return null;
      terms.push({ kind: "pistonHitMs", raw: shot.pistonHitTime * 1000 - row.pistonHitMs, sigma: row.pistonHitSigmaMs });
    }
    if (Number.isFinite(row.peakCylinderBarG)) terms.push({ kind: "peakCylinderBarG", raw: (shot.peakCylinderPressure - shot.ambientPressure) / 1e5 - row.peakCylinderBarG, sigma: row.peakCylinderSigmaBar });
    if (Number.isFinite(row.peakSilencerBarG)) terms.push({ kind: "peakSilencerBarG", raw: (shot.peakSilencerPressure - shot.ambientPressure) / 1e5 - row.peakSilencerBarG, sigma: row.peakSilencerSigmaBar });
    if (Number.isFinite(row.peakBumperForceN)) {
      if (!Number.isFinite(shot.peakBumperForce)) return null;
      terms.push({ kind: "peakBumperForceN", raw: shot.peakBumperForce - row.peakBumperForceN, sigma: row.peakBumperForceSigmaN });
    }
    return terms;
  }
  async function fitParameters(rows, names = ["dischargeCoefficient"], onProgress = () => {}, simulate = P.simulate) {
    const parameters = [...new Set(names)];
    if (!parameters.length || parameters.length > 3 || parameters.some(name => !PARAMETER_SPECS[name])) throw new Error("fit:parameters");
    const training = groups(rows.filter(r => eligible(r) && r.role === "train"), parameters);
    const validation = groups(rows.filter(r => eligible(r) && r.role === "validation"), parameters);
    if (!training.length) throw new Error("fit:no-eligible-data");
    if (training.length + validation.length > 32) throw new Error("fit:too-many-configurations");
    if (training.length < parameters.length) throw new Error("fit:not-identifiable");
    if (parameters.includes("springStiffness") && training.some(group => group.setup.springCurve.length)) throw new Error("fit:measured-spring");
    if (parameters.includes("bumperStiffness") && training.some(group => group.setup.bumperCurve.length)) throw new Error("fit:measured-bumper");
    if (parameters.includes("silencerDischargeCoefficient") && training.every(group => group.setup.silencerEnabled !== 1)) throw new Error("fit:silencer-disabled");
    const profile = [];
    async function loss(values) {
      let weighted = 0, n = 0;
      for (const group of training) {
        const s = simulate({ ...group.setup, ...values }, { sampleInterval: 1 });
        for (const r of group.rows) {
          const terms = residualTerms(s, r); if (!terms) return Infinity;
          for (const term of terms) { weighted += (term.raw / term.sigma) ** 2; n++; }
        }
        await new Promise(resolve => setTimeout(resolve, 0));
      }
      const value = weighted / n;
      profile.push({ parameters: { ...values }, weightedMSE: value });
      onProgress(profile.length);
      await new Promise(resolve => setTimeout(resolve, 0));
      return value;
    }
    let bestValues = Object.fromEntries(parameters.map(name => [name, training[0].setup[name]]));
    let bestLoss = await loss(bestValues);
    const cycles = parameters.length === 1 ? 1 : 2, iterations = parameters.length === 1 ? 16 : 7;
    for (let cycle = 0; cycle < cycles; cycle++) for (const name of parameters) {
      const spec = PARAMETER_SPECS[name]; let lo = spec.min, hi = spec.max;
      if (cycle > 0) { const radius = (spec.max - spec.min) / 6 ** cycle; lo = Math.max(spec.min, bestValues[name] - radius); hi = Math.min(spec.max, bestValues[name] + radius); }
      for (let iteration = 0; iteration < iterations; iteration++) {
        const a = lo + (hi - lo) / 3, b = hi - (hi - lo) / 3;
        const va = { ...bestValues, [name]: a }, vb = { ...bestValues, [name]: b };
        const la = await loss(va), lb = await loss(vb);
        if (la < lb) { hi = b; if (la < bestLoss) { bestLoss = la; bestValues = va; } }
        else { lo = a; if (lb < bestLoss) { bestLoss = lb; bestValues = vb; } }
      }
    }
    const best = profile.filter(v => Number.isFinite(v.weightedMSE)).sort((a, b) => a.weightedMSE - b.weightedMSE)[0];
    if (!best) throw new Error("fit:no-valid-exit");
    bestValues = best.parameters;
    function report(gs) {
      let squared = 0, count = 0, failures = 0, weightedSquared = 0, observations = 0;
      const residuals = [];
      for (const group of gs) {
        const s = simulate({ ...group.setup, ...bestValues }, { sampleInterval: 1 });
        if (!s.valid || s.exitVelocity === null) { failures += group.rows.length; continue; }
        for (const r of group.rows) {
          const terms = residualTerms(s, r); if (!terms) { failures++; continue; }
          const error = fps(s.exitVelocity) - r.fps; squared += error ** 2; count++;
          for (const term of terms) { weightedSquared += (term.raw / term.sigma) ** 2; observations++; }
          residuals.push({ id: r.id, predictedFps: fps(s.exitVelocity), measuredFps: r.fps, residualFps: error, terms });
        }
      }
      return { rmse: count ? Math.sqrt(squared / count) : null, weightedRMSE: observations ? Math.sqrt(weightedSquared / observations) : null, count, observations, failures, residuals };
    }
    const boundReached = parameters.some(name => { const spec = PARAMETER_SPECS[name], value = bestValues[name]; return value <= spec.min + (spec.max - spec.min) * .002 || value >= spec.max - (spec.max - spec.min) * .002; });
    return { coefficient: bestValues.dischargeCoefficient ?? null, parameters: bestValues, fittedParameters: parameters,
      training: report(training), validation: report(validation), profile, distinctTrainingSetups: training.length,
      boundReached, weaklyConstrained: training.length <= parameters.length || best.weightedMSE > 4,
      identifiability: training.length > parameters.length ? "screened" : "minimum-data" };
  }
  async function fitLoss(rows, onProgress = () => {}) { return fitParameters(rows, ["dischargeCoefficient"], onProgress); }
  const api = { SCHEMA, KEY, OLD_KEY, PARAMETER_SPECS, reference, cleanRecord, decode, encode, eligible, energy, groups, residualTerms, fitParameters, fitLoss };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.PneumaticCalibration = api;
})(typeof globalThis !== "undefined" ? globalThis : this);


/* Bounded hardware-only search. Rankings are engineering preferences, not acoustics. */
(function (root) {
  "use strict";
  const VERSION = "2.1.0";
  const P = typeof module !== "undefined" && module.exports ? require("./physics.js") : root.PneumaticPhysics;
  const GROUPS = Object.freeze({
    cylinder: ["cylinderBore", "strokeLength", "deadVolume"],
    barrel: ["barrelLength", "barrelDiameter", "frontDeadVolume"],
    silencer: ["silencerLength", "silencerInnerDiameter", "silencerBaffleCount", "silencerBaffleThickness", "silencerBaffleBore", "silencerEndCapBore", "silencerPackingFraction"],
    head: ["headBore", "headLength", "nozzleBore", "nozzleLength", "bumperThickness", "bumperBore", "bumperStiffness", "bumperDamping", "bumperMaxCompression", "breechVolume"],
    piston: ["pistonMass"],
    airbrake: ["airbrakeLength", "airbrakeDiameter", "airbrakeTipDiameter", "airbrakeTaper"],
    spring: ["springStiffness", "springPreload", "springMass", "springFreeLength", "springInstalledLength", "springCutLength", "springActiveCoils", "springRemovedCoils"],
    bb: ["bbMass", "bbDiameter"]
  });
  const LIMITS = Object.freeze({ cylinderBore: [15,35], strokeLength: [20,150], deadVolume: [.05,5], barrelLength: [100,800], barrelDiameter: [5.8,6.5], frontDeadVolume: [.001,2], silencerLength: [20,500], silencerInnerDiameter: [7,80], silencerBaffleCount: [0,50], silencerBaffleThickness: [.1,15], silencerBaffleBore: [5.5,30], silencerEndCapBore: [5.5,30], silencerPackingFraction: [0,.89], headBore: [1,10], headLength: [1,40], nozzleBore: [1,10], nozzleLength: [1,50], bumperThickness: [0,20], bumperBore: [.5,30], bumperStiffness: [0,5000], bumperDamping: [0,1000], bumperMaxCompression: [0,10], breechVolume: [.05,5], pistonMass: [5,300], airbrakeLength: [0,40], airbrakeDiameter: [.5,9], airbrakeTipDiameter: [0,9], airbrakeTaper: [0,10], springStiffness: [0,4000], springPreload: [0,150], springMass: [0,100], springFreeLength: [0,500], springInstalledLength: [0,500], springCutLength: [0,400], springActiveCoils: [0,200], springRemovedCoils: [0,200], bbMass: [.1,1], bbDiameter: [5.5,6.4] });
  const WEIGHTS = Object.freeze({ balanced: [.30,.17,.13,.25,.15], quiet: [.38,.20,.17,.10,.15], efficient: [.12,.08,.05,.60,.15] });
  const HORIZON_MS = 250;
  const clone = v => JSON.parse(JSON.stringify(v));
  function fixedReason(p, key) {
    if (GROUPS.silencer.includes(key) && p.silencerEnabled !== 1) return "silencer-disabled";
    if (p.springCurve.length && ["springStiffness", "springMass", "springFreeLength", "springCutLength", "springActiveCoils", "springRemovedCoils", "springSolidLength"].includes(key)) return "measured-spring";
    if (p.bumperCurve.length && key === "bumperStiffness") return "measured-bumper";
    if (p.springLengthMode === 1 && key === "springPreload" || p.springLengthMode !== 1 && ["springFreeLength", "springInstalledLength", "springCutLength", "springActiveCoils", "springRemovedCoils", "springSolidLength"].includes(key)) return "spring-mode";
    return null;
  }
  function parseValues(text) {
    if (typeof text !== "string" || !text.trim()) throw new Error("optimizer:values");
    const tokens = text.trim().split(/[,;\s]+/);
    if (tokens.length > 12 || tokens.some(v => !/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(v))) throw new Error("optimizer:values");
    const values = [...new Set(tokens.map(Number))];
    if (values.some(v => !Number.isFinite(v))) throw new Error("optimizer:values");
    return values;
  }
  function searchSpace(raw, config = {}) {
    const base = P.normalize(raw);
    if (P.validate(base).length) throw new Error("optimizer:baseline-invalid");
    for (const key of Object.keys(config.values || {})) if (!Object.hasOwn(LIMITS, key)) throw new Error("optimizer:forbidden-parameter");
    for (const key of Object.keys(config.locks || {})) if (!Object.hasOwn(GROUPS, key)) throw new Error("optimizer:unknown-group");
    const dimensions = [], locks = {};
    let total = 1;
    for (const [group, keys] of Object.entries(GROUPS)) {
      locks[group] = config.locks?.[group] !== false;
      if (locks[group]) continue;
      for (const key of keys) {
        const entries = config.values?.[key] || [base[key]];
        if (!Array.isArray(entries) || entries.length > 12 || entries.length === 0 || entries.some(v => !Number.isFinite(v) || v < LIMITS[key][0] || v > LIMITS[key][1])) throw new Error(`optimizer:values:${key}`);
        const fixed = fixedReason(base, key);
        if (fixed && entries.some(v => v !== base[key])) throw new Error(`optimizer:${fixed}`);
        const values = [...new Set([base[key], ...entries])];
        if (values.length > 1) { dimensions.push({ key, values }); total *= values.length; }
        if (!Number.isSafeInteger(total)) throw new Error("optimizer:space-too-large");
      }
    }
    return { base: clone(base), dimensions, total, locks };
  }
  function candidateAt(space, index) {
    const p = clone(space.base);
    for (const dimension of space.dimensions) { const at = index % dimension.values.length; index = Math.floor(index / dimension.values.length); p[dimension.key] = dimension.values[at]; }
    return p;
  }
  function sampleIndices(space, budget) {
    const count = Math.min(space.total, budget);
    if (space.total <= budget) return Array.from({ length: count }, (_, i) => i);
    const chosen = new Set([0]);
    // Always try individual changes first, then deterministic multi-part samples.
    let stride = 1;
    for (const d of space.dimensions) {
      for (let i = 1; i < d.values.length && chosen.size < count; i++) chosen.add(i * stride);
      stride *= d.values.length;
    }
    let seed = 0x6d2b79f5;
    while (chosen.size < count) {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      chosen.add(Math.floor(seed / 4294967296 * space.total));
    }
    return [...chosen];
  }
  function assess(params, shot, bounds) {
    if (!shot?.valid) return { reason: "invalid" };
    if (!Number.isFinite(shot.exitEnergy) || !Number.isFinite(shot.exitTime) || !Number.isFinite(shot.exitVelocity)) return { reason: "noExit" };
    if (bounds && (shot.exitEnergy < bounds.min - 1e-10 || shot.exitEnergy > bounds.max + 1e-10)) return { reason: "energy" };
    if (!Number.isFinite(shot.pistonHitTime) || !Number.isFinite(shot.impactEnergy) || shot.dischargeComplete !== true) return { reason: "unfinished" };
    const contacts = Array.isArray(shot.pistonImpacts) ? shot.pistonImpacts : [];
    if (contacts.some(event => event.complete === false)) return { reason: "unfinished" };
    const springWork = P.springEnergy(params, 0);
    if (!(springWork > 0) || !Number.isFinite(shot.peakOutflow) || !Number.isFinite(shot.exitPressure) || !Number.isFinite(shot.energyResidual) || Math.abs(shot.energyResidual) > .001 * springWork) return { reason: "numerical" };
    const efficiency = shot.exitEnergy / springWork;
    if (!(efficiency > 0 && efficiency <= 1.001) || shot.impactEnergy < 0 || shot.peakOutflow < 0) return { reason: "numerical" };
    const contactDissipation = contacts.length ? contacts.reduce((sum, event) => sum + Math.max(0, Number.isFinite(event.dissipatedEnergy) ? event.dissipatedEnergy : event.pistonEnergy || 0), 0) : shot.impactEnergy;
    const timingRisk = shot.waveDiagnostics?.timingRatio === null || shot.waveDiagnostics?.timingRatio === undefined ? 0 : Math.min(2, shot.waveDiagnostics.timingRatio);
    const uncertainty = (shot.waveDiagnostics?.relativePressureSpan || 0) + timingRisk;
    const metrics = { energy: shot.exitEnergy, velocity: shot.exitVelocity, efficiency, springWork,
      impact: contactDissipation, firstImpact: shot.impactEnergy, contactCount: contacts.length || 1,
      outflow: shot.peakOutflow, exitGauge: Math.max(0, shot.exitPressure - shot.ambientPressure), uncertainty,
      timingMargin: shot.strongBrakeTime !== null && shot.usefulTime !== null ? shot.strongBrakeTime - shot.usefulTime : null,
      contactTime: shot.pistonHitTime, duration: shot.duration, energyResidual: shot.energyResidual };
    return { reason: null, metrics, vector: [metrics.impact, metrics.outflow, metrics.exitGauge, -metrics.efficiency, metrics.uncertainty] };
  }
  function dominates(a, b) {
    return a.vector.every((v, i) => v <= b.vector[i]) && a.vector.some((v, i) => v < b.vector[i]);
  }
  function rank(candidates, priority = "balanced") {
    const weights = WEIGHTS[priority];
    if (!weights) throw new Error("optimizer:priority");
    if (!candidates.length) return [];
    const frontier = candidates.filter(a => !candidates.some(b => b !== a && dominates(b, a)));
    const lows = weights.map((_, i) => Math.min(...frontier.map(c => c.vector[i])));
    const highs = weights.map((_, i) => Math.max(...frontier.map(c => c.vector[i])));
    return frontier.map(c => ({ ...c, score: weights.reduce((sum, w, i) => sum + w * (highs[i] === lows[i] ? 0 : (c.vector[i] - lows[i]) / (highs[i] - lows[i])), 0) }))
      .sort((a, b) => a.score - b.score || Object.keys(a.changes).length - Object.keys(b.changes).length || a.index - b.index);
  }
  function changesFrom(base, next) {
    return Object.fromEntries(Object.keys(LIMITS).filter(key => base[key] !== next[key]).map(key => [key, { from: base[key], to: next[key] }]));
  }
  function applyCandidate(current, result, candidate) {
    if (JSON.stringify(P.normalize(current)) !== JSON.stringify(result.base)) throw new Error("optimizer:stale");
    const allowed = new Set(Object.entries(GROUPS).filter(([group]) => result.locks[group] === false).flatMap(([, keys]) => keys));
    const next = clone(P.normalize(current));
    for (const key of Object.keys(P.DEFAULTS)) {
      if (JSON.stringify(candidate.params[key]) !== JSON.stringify(next[key])) {
        if (!allowed.has(key)) throw new Error("optimizer:locked-change");
        if (fixedReason(next, key)) throw new Error("optimizer:fixed-input-law");
        next[key] = clone(candidate.params[key]);
      }
    }
    if (P.validate(next).length) throw new Error("optimizer:candidate-invalid");
    return next;
  }
  async function search(raw, config = {}, callbacks = {}, simulate = P.simulate) {
    const space = searchSpace(raw, config), budget = config.budget ?? 120, priority = config.priority || "balanced";
    if (!Number.isInteger(budget) || budget < 1 || budget > 240 || !WEIGHTS[priority]) throw new Error("optimizer:settings");
    const cancelled = () => Boolean(callbacks.isCancelled?.());
    if (cancelled()) throw new Error("optimizer:cancelled");
    const reference = simulate(space.base, { maxTime: HORIZON_MS, sampleInterval: 1 });
    if (!reference.valid || !Number.isFinite(reference.exitEnergy) || !(reference.exitEnergy > 0) || !Number.isFinite(reference.exitTime)) throw new Error("optimizer:baseline-no-exit");
    const bounds = { min: reference.exitEnergy * .95, max: reference.exitEnergy * 1.05 };
    const indices = sampleIndices(space, budget), candidates = [], rejected = { invalid: 0, noExit: 0, energy: 0, unfinished: 0, numerical: 0 };
    const baseline = assess(space.base, reference, bounds);
    for (let n = 0; n < indices.length; n++) {
      if (cancelled()) throw new Error("optimizer:cancelled");
      const index = indices[n], params = candidateAt(space, index);
      const s = index === 0 ? reference : simulate(params, { maxTime: HORIZON_MS, sampleInterval: 1 });
      const assessed = assess(params, s, bounds);
      if (assessed.reason) rejected[assessed.reason]++;
      else candidates.push({ index, params, metrics: assessed.metrics, vector: assessed.vector, changes: changesFrom(space.base, params) });
      callbacks.onProgress?.({ completed: n + 1, planned: indices.length, eligible: candidates.length });
      await new Promise(resolve => setTimeout(resolve, 0));
    }
    if (cancelled()) throw new Error("optimizer:cancelled");
    return { optimizerVersion: VERSION, solverVersion: P.VERSION, base: space.base, locks: space.locks, dimensions: space.dimensions, bounds, baseline: baseline.metrics || null,
      baselineReason: baseline.reason, priority, weights: WEIGHTS[priority], horizonMs: HORIZON_MS,
      total: space.total, evaluated: indices.length, exhaustive: indices.length === space.total, rejected, eligible: candidates.length,
      frontier: rank(candidates, priority), noVariables: space.dimensions.length === 0 };
  }
  const api = { VERSION, GROUPS, LIMITS, WEIGHTS, HORIZON_MS, fixedReason, parseValues, searchSpace, candidateAt, sampleIndices, assess, dominates, rank, changesFrom, applyCandidate, search };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.PneumaticOptimizer = api;
})(typeof globalThis !== "undefined" ? globalThis : this);


/* Presentation only: never changes solver positions, velocities, events or energy. */
(function (root) {
  "use strict";
  const clamp = v => Math.max(0, Math.min(1, v));
  function timeline(shot, uniform = false) {
    const duration = Math.max(0, shot.duration);
    const focusEnd = Number.isFinite(shot.exitTime) ? Math.min(duration, shot.exitTime + .0015) : duration;
    // Reserve most screen time for firing; still show EVERY later state through
    // the true end of the run. The clock and graphs remain physical milliseconds.
    const split = !uniform && focusEnd > 0 && focusEnd < duration * .8 ? .8 : 1;
    return { duration, focusEnd: split === 1 ? duration : focusEnd, split,
      timeAt(progress) {
        const f = clamp(progress);
        if (split === 1) return f * duration;
        return f <= split ? f / split * focusEnd : focusEnd + (f - split) / (1 - split) * (duration - focusEnd);
      },
      progressAt(time) {
        const value = Math.max(0, Math.min(duration, time));
        if (!duration) return 0;
        if (split === 1) return value / duration;
        return value <= focusEnd ? value / focusEnd * split : split + (value - focusEnd) / (duration - focusEnd) * (1 - split);
      }
    };
  }
  function frameAt(shot, time) {
    const frames = shot.frames, target = Math.max(frames[0].t, Math.min(frames.at(-1).t, time));
    // Last sample at/before target: selects the post-contact side of a duplicate timestamp.
    let lo = 0, hi = frames.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (frames[mid].t <= target) lo = mid + 1; else hi = mid; }
    const a = frames[Math.max(0, lo - 1)], b = frames[Math.min(lo, frames.length - 1)];
    const mix = b.t > a.t ? (target - a.t) / (b.t - a.t) : 0, out = { ...a, t: target };
    for (const key of Object.keys(a)) if (typeof a[key] === "number" && key !== "t") out[key] = a[key] + (b[key] - a[key]) * mix;
    out.bbExited = shot.exitTime !== null && target >= shot.exitTime;
    out.pistonHit = shot.pistonHitTime !== null && target >= shot.pistonHitTime;
    return out;
  }
  function mechanism(p, pistonX) {
    // A shared axial scale for stroke AND head passages prevents the pin from
    // entering a drawn head before the solver's actual geometric entry event.
    const face0 = 110, scale = 430 / (p.strokeLength + p.headLength + p.nozzleLength);
    const contact = face0 + (p.strokeLength - p.bumperThickness) * scale;
    const rigidHead = face0 + p.strokeLength * scale, step = rigidHead + p.headLength * scale;
    const head = contact, passageEnd = step + p.nozzleLength * scale, face = face0 + pistonX * 1000 * scale;
    const barrelStart = passageEnd + 20, outlet = 1040;
    // Preserve one physical axial scale from the BB start plane to the final
    // outlet. With a silencer installed, `end` remains the inner-barrel crown
    // and `silencerEnd` becomes the end-cap outlet.
    const downstreamLength = p.barrelLength + (p.silencerEnabled ? p.silencerLength : 0);
    const barrelScale = (outlet - barrelStart) / Math.max(1, downstreamLength);
    const end = barrelStart + p.barrelLength * barrelScale;
    return { wall: 40, face0, face, contact, rigidHead, bumperWidth: rigidHead - contact, head, step, passageEnd, barrelStart, end,
      silencerEnd: p.silencerEnabled ? outlet : end, barrelScale, pinLength: p.airbrakeLength * scale, pinTip: face + p.airbrakeLength * scale, scale };
  }
  const api = { timeline, frameAt, mechanism };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.PneumaticPlayback = api;
})(typeof globalThis !== "undefined" ? globalThis : this);


/* Small keyed DOM reconciler: retain canvas bitmaps, focus and event handlers.
   Templates are generated locally by app.js; no untrusted HTML is accepted. */
(function (root) {
  "use strict";
  const key = node => node.nodeType === 1 ? node.getAttribute("id") || node.getAttribute("data-view-key") : null;
  const compatible = (a, b) => a && a.nodeType === b.nodeType && a.nodeName === b.nodeName && key(a) === key(b);
  function patchNode(current, next) {
    if (current.nodeType !== 1) {
      if (current.nodeValue !== next.nodeValue) current.nodeValue = next.nodeValue;
      return;
    }
    // data-live leaves belong to the frame renderer, not the shot template.
    if (current.hasAttribute("data-live")) return;
    const preserveOpen = current.nodeName === "DETAILS" && next.hasAttribute("data-preserve-open");
    for (const attribute of Array.from(current.attributes)) {
      if (preserveOpen && attribute.name === "open") continue;
      if (!next.hasAttribute(attribute.name)) current.removeAttribute(attribute.name);
    }
    for (const attribute of Array.from(next.attributes)) {
      if (preserveOpen && attribute.name === "open") continue;
      if (current.getAttribute(attribute.name) !== attribute.value) current.setAttribute(attribute.name, attribute.value);
    }
    patchChildren(current, next);
  }
  function patchChildren(current, next) {
    let cursor = current.firstChild;
    for (const wanted of Array.from(next.childNodes)) {
      let match = compatible(cursor, wanted) ? cursor : null;
      if (!match && key(wanted)) match = Array.from(current.childNodes).find(node => compatible(node, wanted));
      if (!match) {
        match = wanted.cloneNode(true);
        current.insertBefore(match, cursor);
      } else {
        if (match !== cursor) current.insertBefore(match, cursor);
        patchNode(match, wanted);
      }
      cursor = match.nextSibling;
    }
    while (cursor) { const following = cursor.nextSibling; current.removeChild(cursor); cursor = following; }
  }
  const api = { patchChildren };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.PneumaticView = api;
})(typeof globalThis !== "undefined" ? globalThis : this);


/* Layout/navigation only. Reparents existing controls and canvases once; never
   clones them or changes physical inputs. No framework/runtime dependency. */
(function (root) {
  "use strict";
  const CATEGORIES = [
    ["geometry", "Cylinder & barrel", "Cilindar i cijev"], ["silencer", "Silencer", "Prigušivač"], ["masses", "Piston & BB", "Piston i BB"],
    ["airbrake", "Airbrake, bumper & head", "Zračna kočnica, gumica i glava"], ["spring", "Spring", "Opruga"],
    ["losses", "Losses & environment", "Gubici i okoliš"], ["rifle", "Rifle presets", "Predlošci replika"],
    ["solver", "Timing & solver", "Vrijeme i rješavač"]
  ];
  const VIEWS = [["shot", "Shot", "Hitac"], ["parts", "Parts", "Dijelovi"], ["graphs", "Graphs", "Grafovi"], ["details", "Results", "Rezultati"], ["optimizer", "Optimize", "Optimizacija"], ["calibration", "Chrono", "Kronograf"]];
  function mount(doc, state, t, onView) {
    const $ = id => doc.getElementById(id);
    const aside = doc.querySelector(".controls-panel"), main = doc.querySelector(".main");
    aside.id = "settingsPanel"; main.id = "previewPanel";
    const members = {
      rifle: [$("platformPreset").closest("section")], geometry: [$("cylinderBore").closest("section"), $("shortStrokeDynamic")], silencer: [$("silencerDetails")].filter(Boolean),
      masses: [$("pistonMass").closest("section"), aside.querySelector(".preset-row")], airbrake: [$("pinLabel").closest("details")],
      spring: [$("springDetails")], losses: [$("dischargeCoefficient").closest("details")], solver: [$("usefulFraction").closest("details")]
    };
    const picker = doc.createElement("label"); picker.className = "settings-picker";
    picker.innerHTML = `${t("Adjust", "Podesi")}<select id="settingsCategory" aria-controls="settingsPages">${CATEGORIES.map(([id, en, hr]) => `<option value="${id}">${t(en, hr)}</option>`).join("")}</select>`;
    const pages = doc.createElement("div"); pages.id = "settingsPages"; pages.className = "settings-pages";
    for (const [id, en, hr] of CATEGORIES) {
      const page = doc.createElement("section"); page.id = "settings-" + id; page.dataset.settingsPage = id; page.className = "settings-page"; page.setAttribute("aria-label", t(en, hr));
      for (const element of members[id]) { if (element.tagName === "DETAILS") { element.open = true; element.classList.add("settings-section"); } page.append(element); }
      pages.append(page);
    }
    aside.append(picker, pages);
    // Keep explanations available without making people pass them to reach inputs.
    const helpGroups = new Map();
    pages.querySelectorAll("p.field-help, p.evidence").forEach(note => {
      const notes = helpGroups.get(note.parentElement) || []; notes.push(note); helpGroups.set(note.parentElement, notes);
    });
    for (const [parent, notes] of helpGroups) {
      const help = doc.createElement("details"); help.className = "inline-help";
      const summary = doc.createElement("summary"); summary.textContent = t("Help & assumptions", "Objašnjenja i pretpostavke"); help.append(summary, ...notes); parent.append(help);
    }
    const body = doc.createElement("div"); body.id = "workspaceBody"; body.className = "workspace-body";
    const optimizer = main.querySelector(".optimizer"), calibration = $("calibrationPanel");
    optimizer.id = "workspace-optimizer"; optimizer.dataset.workspacePanel = "optimizer";
    calibration.dataset.workspacePanel = "calibration"; calibration.open = true;
    body.append($("results"), optimizer, calibration);
    const nav = doc.createElement("nav"); nav.className = "workspace-nav"; nav.setAttribute("aria-label", t("Lab views", "Prikazi laboratorija"));
    nav.innerHTML = VIEWS.map(([id, en, hr]) => `<button type="button" data-workspace-view="${id}" aria-controls="${id === "calibration" ? "calibrationPanel" : "workspace-" + id}" aria-pressed="false">${t(en, hr)}</button>`).join("");
    main.append(nav, body);
    const jump = doc.createElement("nav"); jump.className = "mobile-workspace-jumps"; jump.setAttribute("aria-label", t("Workspace shortcuts", "Prečaci radnog prostora"));
    jump.innerHTML = `<button type="button" data-jump="settings">${t("Settings", "Postavke")}</button><button type="button" data-jump="preview">${t("Preview", "Prikaz")}</button>`;
    main.closest(".app").append(jump);
    function sync() {
      for (const panel of pages.children) panel.hidden = panel.dataset.settingsPage !== state.category;
      $("settingsCategory").value = state.category;
      main.querySelectorAll("[data-workspace-panel]").forEach(panel => { panel.hidden = panel.dataset.workspacePanel !== state.view; });
      // Pending/invalid status remains visible even in Optimize or Chrono.
      if ($("resultContent")) $("resultContent").hidden = !["shot", "parts", "graphs", "details"].includes(state.view);
      nav.querySelectorAll("button").forEach(button => button.setAttribute("aria-pressed", String(button.dataset.workspaceView === state.view)));
    }
    function selectCategory(value) {
      if (!CATEGORIES.some(([id]) => id === value)) return;
      state.categoryScroll[state.category] = pages.scrollTop; state.category = value;
      sync(); pages.scrollTop = state.categoryScroll[value] || 0;
    }
    function selectView(value) {
      if (!VIEWS.some(([id]) => id === value)) return;
      state.viewScroll[state.view] = body.scrollTop; state.view = value;
      sync(); body.scrollTop = state.viewScroll[value] || 0; onView(value);
    }
    $("settingsCategory").addEventListener("change", event => selectCategory(event.target.value));
    nav.addEventListener("click", event => { const button = event.target.closest("[data-workspace-view]"); if (button && !button.disabled) selectView(button.dataset.workspaceView); });
    jump.addEventListener("click", event => {
      const button = event.target.closest("[data-jump]"); if (!button || button.disabled) return;
      if (button.dataset.jump === "settings") {
        aside.classList.remove("is-collapsed"); $("toggleControls").setAttribute("aria-expanded", "true");
        aside.scrollIntoView({ block: "start" }); $("settingsCategory").focus({ preventScroll: true });
      } else {
        selectView("shot"); body.scrollTop = 0;
        main.scrollIntoView({ block: "start" }); nav.querySelector("button").focus({ preventScroll: true });
      }
    });
    sync();
    return { sync, selectView, selectCategory,
      rememberScroll() { state.categoryScroll[state.category] = pages.scrollTop; state.viewScroll[state.view] = body.scrollTop; },
      restoreScroll() { pages.scrollTop = state.categoryScroll[state.category] || 0; body.scrollTop = state.viewScroll[state.view] || 0; }
    };
  }
  function prepareResults(next, summaryHTML, caption, incomplete) {
    const doc = next.ownerDocument, stage = next.querySelector(".stage"), parts = next.querySelector(".parts-atlas"), graphs = next.querySelector(".graphs");
    const transport = stage.querySelector(".stage-toolbar"); transport.id = "workspace-transport"; transport.remove();
    const disclosure = (id, label) => {
      const details = doc.createElement("details"); details.id = id; details.className = "stage-disclosure"; details.setAttribute("data-preserve-open", "");
      const summary = doc.createElement("summary"); summary.textContent = label; details.append(summary); return details;
    };
    const live = disclosure("liveValuesDetails", caption.live), help = disclosure("playbackDetails", caption.help);
    live.append(stage.querySelector("#liveStrip"));
    for (const element of Array.from(stage.children)) {
      if (element.matches(".playback-reference, .playback-options, .results-note, p.small-note")) help.append(element);
    }
    const glance = doc.createElement("div"); glance.className = "tuning-summary"; glance.innerHTML = summaryHTML;
    const flag = doc.createElement("p"); flag.className = "shot-caption"; flag.textContent = caption.flag;
    stage.prepend(flag);
    if (incomplete) {
      const warning = doc.createElement("p"); warning.className = "shot-incomplete"; warning.setAttribute("role", "status"); warning.textContent = incomplete; stage.insertBefore(warning, flag.nextSibling);
    }
    if (caption.timingHTML) {
      const wrapper = doc.createElement("div"); wrapper.innerHTML = caption.timingHTML;
      stage.insertBefore(wrapper.children[0], stage.querySelector("#phaseText"));
    }
    stage.append(glance);
    if (caption.explainSound) {
      const explain = doc.createElement("button"); explain.id = "explainSound"; explain.type = "button"; explain.className = "sound-explain-link"; explain.textContent = caption.explainSound; stage.append(explain);
    }
    if (caption.explainFeedback) {
      const explain = doc.createElement("button"); explain.id = "explainFeedback"; explain.type = "button"; explain.className = "feedback-explain-link"; explain.textContent = caption.explainFeedback; stage.append(explain);
    }
    stage.append(live, help);
    stage.id = "workspace-shot"; stage.dataset.workspacePanel = "shot";
    parts.id = "workspace-parts"; parts.dataset.workspacePanel = "parts";
    graphs.id = "workspace-graphs"; graphs.dataset.workspacePanel = "graphs";
    const details = doc.createElement("section"); details.id = "workspace-details"; details.dataset.workspacePanel = "details";
    for (const child of Array.from(next.childNodes)) if (child !== stage && child !== parts && child !== graphs) details.append(child);
    const sound = details.querySelector("#soundExplanations"); if (sound) details.prepend(sound);
    next.append(transport, stage, parts, graphs, details);
  }
  const api = { mount, prepareResults, CATEGORIES, VIEWS };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.PneumaticWorkspace = api;
})(typeof globalThis !== "undefined" ? globalThis : this);


/* Presentation of solver quantities, never an acoustic model or a power fit. */
(function (root) {
  "use strict";
  const finite = Number.isFinite;
  const thresholdPercent = fraction => Number((fraction * 100).toPrecision(12));
  const eventTime = (s, key) => finite(s[key]) && s[key] >= 0 && s[key] <= s.duration ? s[key] : null;
  function timing(s, p) {
    const events = ["usefulTime", "exitTime", "strongBrakeTime"].map(key => ({ key, time: eventTime(s, key) }));
    const [useful, exit, brake] = events.map(event => event.time);
    // A linear event window, not the phase-paced playback timeline. Missing
    // exit uses the full observation interval rather than inventing an exit.
    const lastEvent = Math.max(0, ...events.map(event => event.time ?? 0));
    const end = exit === null ? s.duration : Math.min(s.duration, Math.max(.001, lastEvent * 1.12));
    for (const event of events) event.percent = event.time === null || !(end > 0) ? null : event.time / end * 100;
    let verdict = "unavailable";
    if (exit === null) verdict = "no-exit";
    else if (p.airbrakeLength === 0) verdict = "no-pin";
    else if (brake === null) verdict = "no-slowing";
    else if (useful !== null) {
      if (brake === useful) verdict = "same-threshold";
      else if (brake === exit) verdict = "same-exit";
      else if (brake > exit) verdict = "after-exit";
      else verdict = brake > useful ? "after-threshold" : "early";
    }
    return { events, end, verdict, marginMs: useful !== null && brake !== null ? (brake - useful) * 1000 : null };
  }
  function verdictText(value, t) {
    const text = {
      "no-exit": ["BB exit not reached · timing unresolved", "BB nije izašao · vremenski odnos nije riješen"],
      "no-pin": ["Airbrake off · no braking comparison", "Kočnica isključena · nema usporedbe kočenja"],
      "no-slowing": ["Slowing threshold not reached in this run", "Prag usporavanja nije dosegnut u ovoj simulaciji"],
      "same-threshold": ["Energy threshold and slowing coincide", "Prag energije i usporavanje se podudaraju"],
      "same-exit": ["Substantial slowing coincides with BB exit", "Značajno usporavanje podudara se s izlaskom BB-a"],
      "after-exit": ["Substantial slowing begins after BB exit", "Značajno usporavanje počinje nakon izlaska BB-a"],
      "after-threshold": ["Energy threshold first · BB still in barrel when slowing starts", "Prag energije prvi · BB je još u cijevi pri početku usporavanja"],
      early: ["Substantial slowing begins before the energy threshold", "Značajno usporavanje počinje prije praga energije"],
      unavailable: ["Timing comparison unavailable", "Vremenska usporedba nije dostupna"]
    };
    return t(...(text[value] || text.unavailable));
  }
  function timingMarkup(s, p, t, fmt, stamp) {
    const model = timing(s, p), labels = [
      `${thresholdPercent(p.usefulFraction)}% ${t("peak BB energy", "vršne energije BB-a")}`,
      t("BB exit", "Izlazak BB-a"), t("Strong slowing after entry", "Snažno usporavanje nakon ulaska")
    ];
    const colors = ["useful", "exit", "brake"], exit = model.events[1];
    const missing = key => key === "strongBrakeTime" && p.airbrakeLength === 0 ? t("airbrake off", "kočnica isključena") : t("not reached", "nije dosegnuto");
    return `<section id="shotTiming" class="shot-timing" data-verdict="${model.verdict}" aria-label="${t("Pneumatic timing target", "Cilj pneumatskog vremenskog odnosa")}">
      <div class="shot-timing-heading"><strong>${t("Tuning target: energy before strong slowing", "Cilj: energija prije snažnog usporavanja")}</strong><span>${verdictText(model.verdict, t)}</span></div>
      <div class="event-track" aria-hidden="true">${exit.percent === null ? "" : `<div class="event-fill" style="width:${exit.percent.toFixed(5)}%"></div>`}${model.events.map((event, i) => event.percent === null ? "" : `<i class="event-tick ${colors[i]}" style="left:${event.percent.toFixed(5)}%;--lane:${i}"></i>`).join("")}</div>
      <div class="event-scale"><span>0 ms</span><span>${t("Linear event window", "Linearni prozor događaja")} · ${stamp(model.end)}</span></div>
      <div class="event-key">${model.events.map((event, i) => `<button type="button" class="${colors[i]}" data-event="${event.key}" ${event.time === null ? "disabled" : ""}><span>${labels[i]}</span><strong>${event.time === null ? missing(event.key) : stamp(event.time)}</strong></button>`).join("")}</div>
      <details id="timingReadingHelp" class="timing-reading-help" data-preserve-open><summary>${t("How to read this", "Kako čitati prikaz")}</summary><p class="timing-caveat">${t("Tinted area: before BB exit. Green is an energy threshold, not acceleration ending. Amber marks modeled slowing—not proof that the airbrake alone caused it. Click an event to seek its actual model time.", "Obojeno područje: prije izlaska BB-a. Zelena je prag energije, ne kraj ubrzavanja. Jantarna označuje modelirano usporavanje — ne dokazuje da ga uzrokuje samo zračna kočnica. Klikom na događaj prikažite stvarno vrijeme modela.")}</p></details>
    </section>`;
  }
  function compare(value, reference) {
    if (!finite(value) || value < 0) return { status: "unknown", percent: null, width: 0 };
    if (!finite(reference) || reference < 0) return { status: "no-reference", percent: null, width: 0 };
    if (reference === 0) return { status: "zero-reference", percent: null, width: 0 };
    const percent = value / reference * 100;
    if (!finite(percent)) return { status: "no-reference", percent: null, width: 0 };
    return { status: percent < 100 ? "lower" : percent > 100 ? "higher" : "same", percent, width: Math.min(percent, 200) / 2 };
  }
  function soundQuantities(s, baseline, unsilencedReference = null) {
    const impact = s.valid && eventTime(s, "pistonHitTime") !== null ? s.impactEnergy : null;
    const flow = s.valid && eventTime(s, "exitTime") !== null ? s.peakOutflow : null;
    const referenceImpact = baseline?.valid && eventTime(baseline, "pistonHitTime") !== null ? baseline.impactEnergy : null;
    const flowReference = s?.params?.silencerEnabled ? unsilencedReference : baseline;
    const referenceFlow = flowReference?.valid && eventTime(flowReference, "exitTime") !== null ? flowReference.peakOutflow : null;
    return { impact, flow, referenceImpact, referenceFlow, flowReferenceKind: s?.params?.silencerEnabled ? "unsilenced" : "no-airbrake",
      impactComparison: compare(impact, referenceImpact), flowComparison: compare(flow, referenceFlow) };
  }
  function impactSummary(s) {
    let impacts = Array.isArray(s?.pistonImpacts) ? s.pistonImpacts.filter(event => finite(event?.time) && finite(event?.incomingVelocity) && finite(event?.pistonEnergy) && event.time >= 0 && event.time <= s.duration && event.incomingVelocity > 0 && event.pistonEnergy >= 0) : [];
    // Backward-compatible display fallback for older exported solver results.
    if (!impacts.length && eventTime(s, "pistonHitTime") !== null && finite(s.pistonImpactVelocity) && finite(s.impactEnergy)) impacts = [{ index: 1, time: s.pistonHitTime, incomingVelocity: s.pistonImpactVelocity, reboundVelocity: null, pistonEnergy: s.impactEnergy }];
    const totalEnergy = impacts.reduce((sum, event) => sum + event.pistonEnergy, 0);
    const laterEnergy = impacts.slice(1).reduce((sum, event) => sum + event.pistonEnergy, 0);
    const strongest = impacts.reduce((best, event) => !best || event.pistonEnergy > best.pistonEnergy ? event : best, null);
    return { impacts, count: impacts.length, first: impacts[0] || null, last: impacts.at(-1) || null, strongest, totalEnergy, laterEnergy };
  }
  function impactMarkup(s, canvasId, placement, t, fmt) {
    const summary = impactSummary(s), shown = summary.impacts.slice(0, 8), hidden = Math.max(0, summary.count - shown.length);
    const compliant = s?.params?.bumperThickness > 0 && s?.params?.bumperMaxCompression > 0;
    const outerClass = placement === "results" ? "panel impact-analysis impact-analysis-results" : "impact-analysis impact-analysis-graphs";
    const titleId = `${canvasId}Title`, contactWord = summary.count === 1 ? t("contact", "kontakt") : t("contacts", "kontakata");
    const cards = [
      [t("Recorded head contacts", "Zabilježeni kontakti s glavom"), summary.count ? `${summary.count} ${contactWord}` : t("None", "Nema"), t("Resolved contact episodes", "Razriješene epizode kontakta")],
      [t("First contact", "Prvi kontakt"), summary.first ? fmt(summary.first.pistonEnergy * 1000, 3, "mJ") : "—", summary.first ? `${fmt(summary.first.incomingVelocity, 3, "m/s")} · ${fmt(summary.first.time * 1000, 3, "ms")}` : t("Not reached", "Nije dosegnut")],
      [t("Peak bumper force", "Vršna sila gumice"), compliant && finite(summary.first?.peakForce) ? fmt(summary.first.peakForce, 1, "N") : "—", compliant && finite(summary.first?.peakCompression) ? `${fmt(summary.first.peakCompression * 1000, 3, "mm")} · ${summary.first.bottomedOut ? t("bottom-out reached", "dosegnut kruti graničnik") : fmt(summary.first.duration * 1000, 3, "ms")}` : t("Rigid event or unavailable", "Kruti događaj ili nedostupno")],
      [t("Later contacts combined", "Zbroj kasnijih kontakata"), summary.count > 1 ? fmt(summary.laterEnergy * 1000, 3, "mJ") : "—", summary.count > 1 ? t("Recontacts only; not sound energy", "Samo ponovni kontakti; nije zvučna energija") : t("No modeled recontact", "Nema modeliranog ponovnog kontakta")]
    ];
    const list = shown.map((event, index) => {
      const end = event.reboundVelocity === null ? t("settled in contact / run ended", "ostao u kontaktu / kraj simulacije") : fmt(event.reboundVelocity, 3, "m/s");
      const contact = finite(event.peakCompression) && event.peakCompression > 0 ? ` · ${fmt(event.peakCompression * 1000, 3, "mm")} · ${fmt(event.peakForce, 1, "N")} · ${t("loss", "gubitak")} ${fmt(event.dissipatedEnergy * 1000, 2, "mJ")}${event.bottomedOut ? ` · ${t("bottom-out", "kruti graničnik")}` : ""}` : "";
      return `<button type="button" data-impact-time="${event.time}" aria-label="${t(`Seek to piston contact ${index + 1}`, `Prikaži kontakt pistona ${index + 1}`)}"><span><b>#${index + 1}</b>${index === 0 ? t("First contact", "Prvi kontakt") : t("Recontact", "Ponovni kontakt")}</span><strong>${fmt(event.pistonEnergy * 1000, 3, "mJ")}</strong><small>${fmt(event.time * 1000, 3, "ms")} · ${fmt(event.incomingVelocity, 3, "m/s")} → ${end}${contact}</small></button>`;
    }).join("");
    return `<section class="${outerClass}" aria-labelledby="${titleId}"><div class="impact-analysis-heading"><div><h2 id="${titleId}">${t("Piston contact sequence", "Slijed kontakata pistona")}</h2><p>${t("Every stem is a separate modeled contact episode with the bumper/head. A pressure-driven reversal before contact is not counted as an impact.", "Svaka oznaka predstavlja zasebnu modeliranu epizodu kontakta s gumicom/glavom. Povrat zbog tlaka prije kontakta ne broji se kao udar.")}</p></div><span class="tag heuristic">${summary.count} ${contactWord}</span></div><div class="impact-summary">${cards.map(([name, value, note]) => `<div><span>${name}</span><strong>${value}</strong><small>${note}</small></div>`).join("")}</div><div class="impact-chart-labels"><span>${t("Piston kinetic energy immediately before contact (mJ)", "Kinetička energija pistona neposredno prije kontakta (mJ)")}</span><span>${t("Expanded contact-time window", "Prošireni vremenski prozor kontakata")}</span></div><canvas id="${canvasId}" class="impact-chart" role="img" aria-label="${t("Piston contact energy versus model time; exact events listed below", "Energija kontakta pistona prema modeliranom vremenu; točni događaji navedeni su ispod")}"></canvas><div class="impact-event-list">${list || `<p>${t("No piston contact occurred during the modeled interval.", "Tijekom modeliranog intervala nije došlo do kontakta pistona.")}</p>`}</div>${hidden ? `<p class="impact-overflow">+${hidden} ${t("additional settling contacts are plotted; inspect the exported run for every value.", "dodatnih kontakata smirivanja prikazano je na grafu; sve vrijednosti dostupne su u izvozu simulacije.")}</p>` : ""}<p class="impact-caveat">${t("Energy is ½ × entered piston mass × incoming speed². With a bumper, peak force, compression and duration come from the entered lumped stiffness/damping model; bottom-out uses the separate rigid restitution. These are conditional mechanics—not measured loudness, rubber stress, durability or dB.", "Energija je ½ × unesena masa pistona × ulazna brzina². Uz gumicu, vršna sila, stlačenje i trajanje proizlaze iz unesenog koncentriranog modela krutosti/prigušenja; udar u graničnik koristi zaseban koeficijent krutog odskoka. To je uvjetna mehanika — ne izmjerena glasnoća, naprezanje gume, trajnost ni dB.")}</p></section>`;
  }
  function comparisonMarkup(comparison, reference, unit, kind, t, fmt, referenceLabel = null) {
    const { status, percent, width } = comparison;
    const names = kind === "impact" ? {
      lower: ["Less contact energy than reference", "Manje energije kontakta od reference"],
      higher: ["More contact energy than reference", "Više energije kontakta od reference"],
      same: ["Same contact energy as reference", "Jednaka energija kontakta kao referenca"]
    } : {
      lower: ["Lower observed outflow than reference", "Manji opaženi protok od reference"],
      higher: ["Higher observed outflow than reference", "Veći opaženi protok od reference"],
      same: ["Same observed outflow as reference", "Jednak opaženi protok kao referenca"]
    };
    const unknown = status === "unknown" ? t("Event missing · quantity unknown, not zero", "Događaj nedostaje · veličina nepoznata, nije nula") : status === "zero-reference" ? t("Zero reference · percentage undefined", "Nulta referenca · postotak nije definiran") : t("Reference unavailable · no relative comparison", "Referenca nije dostupna · nema relativne usporedbe");
    return `<div class="sound-comparison" data-comparison="${status}"><div class="comparison-heading"><span>${referenceLabel || t("Against the no-airbrake reference", "Usporedba s referencom bez kočnice")}</span><strong>${percent === null ? "—" : fmt(percent, 1, "%")}</strong></div>
      <div class="comparison-track" aria-hidden="true">${percent === null ? "" : `<div class="comparison-fill" style="width:${width.toFixed(5)}%"></div><i class="comparison-reference"></i>`}</div>
      <div class="comparison-scale" aria-hidden="true"><span>0%</span><span>100%</span><span>200%</span></div>
      <span class="comparison-meaning">${names[status] ? t(...names[status]) : unknown}</span>
      <p class="comparison-note">${t("Reference", "Referenca")}: ${fmt(reference, 3, unit)}. ${percent > 200 ? t("Bar capped at 200%; the number above is uncapped. ", "Traka je ograničena na 200%; broj iznad nije. ") : ""}${t("This compares the modeled quantity—not sound reduction.", "Uspoređuje se modelirana veličina — ne smanjenje zvuka.")}</p></div>`;
  }
  function soundMarkup(s, baseline, unsilencedReference, t, fmt) {
    // Keep direct module consumers compatible with the previous four-argument
    // form while the app supplies a separate same-setup/no-silencer reference.
    if (typeof unsilencedReference === "function") { fmt = t; t = unsilencedReference; unsilencedReference = null; }
    const q = soundQuantities(s, baseline, unsilencedReference);
    const impact = finite(q.impact) ? q.impact * 1000 : null, referenceImpact = finite(q.referenceImpact) ? q.referenceImpact * 1000 : null;
    const flow = finite(q.flow) ? q.flow * 1000 : null, referenceFlow = finite(q.referenceFlow) ? q.referenceFlow * 1000 : null;
    const silenced = s?.params?.silencerEnabled === 1;
    const flowReferenceLabel = silenced ? t("Against this setup without the silencer", "Usporedba s ovom konfiguracijom bez prigušivača") : t("Against the no-airbrake reference", "Usporedba s referencom bez kočnice");
    const dischargeName = silenced ? t("Silencer outlet pulse — escaping air", "Izlazni impuls prigušivača — izlazak zraka") : t("Muzzle blast — escaping air", "Prasak na ustima — izlazak zraka");
    return `<section id="soundExplanations" class="sound-explanations" tabindex="-1" aria-label="${t("Piston impact and muzzle blast explained", "Objašnjenje udara pistona i praska na ustima")}">
      <div class="sound-heading"><div><strong>${t("Two different sound contributors", "Dva različita doprinosa zvuku")}</strong><p>${t("The piston makes a mechanical strike; escaping air makes a discharge pulse. Impact is compared with zero airbrake projection. When a silencer is installed, outlet flow is compared with the identical setup without it. These are modeled mechanics and gas flow—not measured loudness.", "Piston stvara mehanički udarac, a izlazak zraka impuls pražnjenja. Udar se uspoređuje s nultim izbočenjem zračne kočnice. Kada je ugrađen prigušivač, izlazni protok uspoređuje se s identičnom konfiguracijom bez njega. To su modelirana mehanika i protok plina — ne izmjerena glasnoća.")}</p></div><span class="tag unknown">${t("not dB", "nisu dB")}</span></div>
      <div class="intensity-grid">
      <article class="intensity sound-explainer impact-primary" data-comparison="${q.impactComparison.status}"><div class="intensity-head"><strong>${t("Piston impact — mechanical strike", "Udar pistona — mehanički udarac")}</strong><output>${fmt(impact, 2, "mJ")}</output></div>
      <p class="sound-quantity">${t("Modeled energy at first contact · ½mv²", "Modelirana energija pri prvom kontaktu · ½mv²")}</p>
      ${comparisonMarkup(q.impactComparison, referenceImpact, "mJ", "impact", t, fmt)}
      <p><strong>${t("What it means:", "Što to znači:")}</strong> ${t("This is the piston energy that reaches the cylinder head—the source of the mechanical thump. More energy can feed a stronger strike, but the bumper determines how quickly it is absorbed. Energy alone does not give peak force or loudness.", "To je energija kojom piston dolazi do glave cilindra — izvor mehaničkog udarca. Više energije može doprinijeti jačem udaru, ali odbojnik određuje koliko se brzo apsorbira. Sama energija ne određuje vršnu silu ni glasnoću.")}</p>
      <p>${t("The model now resolves a lumped elastic/damped contact, but actual sound still depends on rubber geometry, frequency-dependent material behavior, spring vibration and receiver/stock resonance. Entered peak force is not dB or a durability rating.", "Model sada razrješava koncentrirani elastično-prigušeni kontakt, ali stvarni zvuk i dalje ovisi o geometriji gume, ponašanju materijala ovisnom o frekvenciji, vibraciji opruge te rezonanciji kućišta i kundaka. Unesena vršna sila nije dB ni ocjena trajnosti.")}</p>
      <p class="sound-measured">${t("First-contact speed", "Brzina pri prvom kontaktu")}: <strong>${fmt(q.impact === null ? null : s.pistonImpactVelocity, 2, "m/s")}</strong> · ${t("Peak force / compression", "Vršna sila / stlačenje")}: <strong>${fmt(s.params?.bumperThickness > 0 ? s.peakBumperForce : null, 1, "N")} / ${fmt(s.params?.bumperThickness > 0 ? s.maxBumperCompression * 1000 : null, 3, "mm")}</strong> · ${t("bumper k / c", "gumica k / c")}: <strong>${fmt(s.params?.bumperThickness > 0 ? s.params.bumperStiffness : null, 0, "N/mm")} / ${fmt(s.params?.bumperThickness > 0 ? s.params.bumperDamping : null, 0, "N·s/m")}</strong></p></article>
      <article class="intensity sound-explainer muzzle-primary" data-comparison="${q.flowComparison.status}"><div class="intensity-head"><strong>${dischargeName}</strong><output>${fmt(flow, 2, "g/s")}</output></div>
      <p class="sound-quantity">${silenced ? t("Peak modeled flow to atmosphere through the end cap", "Vršni modelirani protok u atmosferu kroz završnu kapu") : t("Peak modeled flow to atmosphere through the muzzle", "Vršni modelirani protok u atmosferu kroz usta cijevi")}</p>
      ${comparisonMarkup(q.flowComparison, referenceFlow, "g/s", "flow", t, fmt, flowReferenceLabel)}
      <p><strong>${t("What it means:", "Što to znači:")}</strong> ${silenced ? t("Gas ahead of the BB vents into the silencer before inner-barrel exit. At exit, the remaining barrel charge expands into the entered free silencer volume, then leaves through the modeled baffle/end-cap restriction. The chamber can reduce and spread peak outlet flow while raising its own transient pressure.", "Zrak ispred BB-a odzračuje se u prigušivač prije izlaska iz unutarnje cijevi. Pri izlasku se preostali naboj iz cijevi širi u uneseni slobodni volumen prigušivača, zatim izlazi kroz modelirano ograničenje pregrada i završne kape. Komora može smanjiti i vremenski rastegnuti vršni izlazni protok uz porast vlastitog prijelaznog tlaka.") : t("After the BB exits, compressed air escapes from the barrel and contributes a separate air blast. Pressure, gas inventory and discharge rate describe that release. A higher outflow is not the same as a measured increase in sound.", "Nakon izlaska BB-a stlačeni zrak izlazi iz cijevi i doprinosi zasebnom zračnom prasku. Tlak, masa plina i brzina istjecanja opisuju to pražnjenje. Veći protok nije isto što i izmjeren porast glasnoće.")}</p>
      <p>${silenced ? t("What is calculated: free chamber volume, its transient pressure, barrel-to-silencer transfer and final outlet flow. What is heuristic or unknown: the lumped baffle/fill loss factor, outlet Cd and heat transfer. The solver does not resolve individual jets, acoustic frequency response, foam absorption, structural vibration or dB attenuation.", "Što se računa: slobodni volumen komore, njezin prijelazni tlak, prijenos iz cijevi u prigušivač i konačni izlazni protok. Što je heurističko ili nepoznato: koncentrirani faktor gubitaka pregrada/ispune, izlazni Cd i izmjena topline. Solver ne razrješava pojedinačne mlazove, frekvencijski akustički odziv, apsorpciju pjene, strukturne vibracije ni prigušenje u dB.") : t("This is separate from the piston strike—not dB. The muzzle Cd is an independent unknown: before BB exit it controls venting of the air ahead of the BB; after exit it controls discharge from the barrel.", "To je odvojeno od udara pistona — nisu dB. Cd usta cijevi zasebna je nepoznanica: prije izlaska BB-a određuje odzračivanje zraka ispred BB-a, a nakon izlaska pražnjenje cijevi.")}</p>
      <p class="sound-measured">${t("Pressure at inner-barrel exit", "Tlak pri izlasku iz unutarnje cijevi")}: <strong>${fmt(s.exitTime === null ? null : (s.exitPressure - s.ambientPressure) / 1e5, 2, "bar(g)")}</strong> · ${silenced ? `${t("Silencer free volume / peak pressure", "Slobodni volumen / vršni tlak prigušivača")}: <strong>${fmt(s.silencerVolume * 1e6, 2, "cm³")} / ${fmt((s.peakSilencerPressure - s.ambientPressure) / 1e5, 2, "bar(g)")}</strong> · ${t("barrel transfer / outlet peak", "vršni prijenos iz cijevi / izlaz")}: <strong>${fmt(s.peakMuzzleTransfer * 1000, 2, "g/s")} / ${fmt(s.peakOutflow * 1000, 2, "g/s")}</strong> · ${t("outlet pulse >10% peak", "izlazni impuls >10% vrha")}: <strong>${fmt(s.outflowPulseDuration * 1000, 2, "ms")}</strong> · ` : ""}${t("Gas at BB exit", "Plin pri izlasku BB-a")}: <strong>${fmt(s.exitGasMass === null ? null : s.exitGasMass * 1e6, 1, "mg")}</strong> · ${t("Discharged in run", "Ispušteno tijekom simulacije")}: <strong>${fmt(s.exitTime === null ? null : s.muzzleMass * 1e6, 1, "mg")}</strong>.</p>
      <p>${s.dischargeComplete && (silenced ? unsilencedReference?.dischargeComplete : baseline?.dischargeComplete) ? t("Both compared runs relaxed to within 1% of atmospheric pressure.", "Obje uspoređene simulacije približile su se atmosferskom tlaku unutar 1%.") : t("Discharge remains unresolved in one or both compared runs. Later outflow may change the observed comparison; unfinished discharge is not silence.", "Pražnjenje nije završeno u jednoj ili obje uspoređene simulacije. Kasniji protok može promijeniti opaženu usporedbu; nezavršeno pražnjenje ne znači tišinu.")}</p></article>
      </div></section>`;
  }
  function parameterChanges(before = {}, after = {}) {
    const keys = new Set([...Object.keys(before || {}), ...Object.keys(after || {})]);
    return [...keys].filter(key => JSON.stringify(before?.[key]) !== JSON.stringify(after?.[key]))
      .map(key => ({ key, before: before?.[key], after: after?.[key] }));
  }
  const relativeDelta = (before, after) => {
    const delta = finite(before) && finite(after) ? after - before : null;
    const percent = finite(delta) && before !== 0 ? delta / Math.abs(before) * 100 : null;
    return { before: finite(before) ? before : null, after: finite(after) ? after : null,
      delta: finite(delta) ? delta : null, percent: finite(percent) ? percent : null };
  };
  function comparisonSnapshot(before, after) {
    if (!before?.valid || !after?.valid) return null;
    const margin = shot => finite(shot.strongBrakeTime) && finite(shot.usefulTime) ? (shot.strongBrakeTime - shot.usefulTime) * 1000 : null;
    const gauge = shot => finite(shot.exitPressure) && finite(shot.ambientPressure) ? (shot.exitPressure - shot.ambientPressure) / 1e5 : null;
    return { changes: parameterChanges(before.params, after.params), metrics: {
      energy: relativeDelta(before.exitEnergy, after.exitEnergy),
      velocity: relativeDelta(finite(before.exitVelocity) ? before.exitVelocity / .3048 : null, finite(after.exitVelocity) ? after.exitVelocity / .3048 : null),
      impact: relativeDelta(finite(before.impactEnergy) ? before.impactEnergy * 1000 : null, finite(after.impactEnergy) ? after.impactEnergy * 1000 : null),
      flow: relativeDelta(finite(before.peakOutflow) ? before.peakOutflow * 1000 : null, finite(after.peakOutflow) ? after.peakOutflow * 1000 : null),
      exitGauge: relativeDelta(gauge(before), gauge(after)), timingMargin: relativeDelta(margin(before), margin(after))
    } };
  }
  function actionPlan(s, baseline, p, provenance = {}) {
    const actions = [], timingResult = timing(s, p), sound = soundQuantities(s, baseline);
    const timingCodes = { early: ["delay-braking", "warning", "airbrake"], "same-threshold": ["timing-edge", "caution", "airbrake"],
      "after-threshold": ["timing-useful-first", "good", "airbrake"], "same-exit": ["timing-useful-first", "good", "airbrake"],
      "after-exit": ["timing-after-exit", "good", "airbrake"], "no-slowing": ["strengthen-cushion", "caution", "airbrake"],
      "no-pin": ["measure-pin", "unknown", "airbrake"], "no-exit": ["resolve-exit", "warning", "solver"], unavailable: ["timing-unknown", "unknown", "solver"] };
    const timingAction = timingCodes[timingResult.verdict] || timingCodes.unavailable;
    actions.push({ code: timingAction[0], tone: timingAction[1], category: timingAction[2] });
    if (sound.impactComparison.percent === null) actions.push({ code: "impact-unknown", tone: "unknown", category: "airbrake" });
    else if (sound.impactComparison.percent < 85) actions.push({ code: "impact-lower", tone: "good", category: "airbrake", percent: sound.impactComparison.percent });
    else if (sound.impactComparison.percent > 110) actions.push({ code: "impact-higher", tone: "warning", category: "airbrake", percent: sound.impactComparison.percent });
    else actions.push({ code: "impact-similar", tone: "caution", category: "airbrake", percent: sound.impactComparison.percent });
    if (sound.flowComparison.percent === null) actions.push({ code: "muzzle-unknown", tone: "unknown", category: "geometry" });
    else if (sound.flowComparison.percent < 85) actions.push({ code: "muzzle-lower", tone: "good", category: "geometry", percent: sound.flowComparison.percent });
    else if (sound.flowComparison.percent > 110) actions.push({ code: "muzzle-higher", tone: "warning", category: "geometry", percent: sound.flowComparison.percent });
    else actions.push({ code: "muzzle-similar", tone: "caution", category: "geometry", percent: sound.flowComparison.percent });
    if (provenance.geometry !== "measured" || provenance.spring !== "measured") actions.push({ code: "measure-first", tone: "unknown", view: "calibration" });
    return actions;
  }
  function feedbackMarkup(snapshot, s, baseline, p, provenance, fieldLabels, t, fmt) {
    const signed = (value, digits, unit) => finite(value) ? `${value > 0 ? "+" : ""}${fmt(value, digits, unit)}` : "—";
    const valueText = (change, side) => {
      const meta = fieldLabels?.[change.key], value = change[side];
      if (change.key === "springLengthMode") return value ? t("length mode", "način duljina") : t("direct preload", "izravno prednaprezanje");
      if (Array.isArray(value)) return t("curve updated", "krivulja izmijenjena");
      return finite(value) ? fmt(value, meta?.[2] === "turns" ? 2 : 3, meta?.[2] === "turns" ? t("turns", "zavoja") : meta?.[2] || "") : String(value ?? "—");
    };
    const changeName = change => fieldLabels?.[change.key] ? t(fieldLabels[change.key][0], fieldLabels[change.key][1]) : change.key === "springLengthMode" ? t("Spring input mode", "Način unosa opruge") : change.key === "springCurve" ? t("Measured spring curve", "Izmjerena krivulja opruge") : change.key;
    const shownChanges = snapshot?.changes?.slice(0, 4) || [], extra = Math.max(0, (snapshot?.changes?.length || 0) - shownChanges.length);
    const metricInfo = [
      ["energy", t("BB exit energy", "Izlazna energija BB-a"), 3, "J", "context"],
      ["velocity", t("Muzzle velocity", "Izlazna brzina"), 1, "fps", "context"],
      ["impact", t("Piston contact energy", "Energija kontakta pistona"), 2, "mJ", "lower"],
      ["flow", t("Peak muzzle flow", "Vršni protok na ustima"), 2, "g/s", "lower"],
      ["exitGauge", t("Pressure at BB exit", "Tlak pri izlasku BB-a"), 2, "bar(g)", "lower"],
      ["timingMargin", t("Useful energy → slowing", "Korisna energija → usporavanje"), 2, "ms", "higher"]
    ];
    const metricTone = (metric, goal) => !finite(metric?.delta) ? "unknown" : Math.abs(metric.delta) < 1e-12 ? "same" : goal === "context" ? "context" : goal === "lower" ? metric.delta < 0 ? "good" : "warning" : metric.delta > 0 ? "good" : "warning";
    const metrics = snapshot ? metricInfo.map(([key, label, digits, unit, goal]) => {
      const metric = snapshot.metrics[key];
      return `<div class="change-metric" data-tone="${metricTone(metric, goal)}"><span>${label}</span><strong>${fmt(metric.after, digits, unit)}</strong><small>${t("Before", "Prije")}: ${fmt(metric.before, digits, unit)} · Δ ${signed(metric.delta, digits, unit)}${finite(metric.percent) ? ` (${signed(metric.percent, 1, "%")})` : ""}</small></div>`;
    }).join("") : "";
    const actionCopy = {
      "delay-braking": ["Delay strong braking", "Odgodi snažno kočenje", "The piston slows strongly before the selected BB-energy threshold. Try a slightly shorter pin, smaller pin diameter, or larger local bore—one change at a time. Recheck contact energy because reducing restriction can increase piston strike.", "Piston snažno usporava prije odabranog praga energije BB-a. Probajte malo kraći pin, manji promjer pina ili veći lokalni otvor — jednu promjenu odjednom. Ponovno provjerite energiju kontakta jer manji otpor može pojačati udar pistona."],
      "timing-edge": ["Create a little more timing margin", "Stvori malo veći vremenski razmak", "Useful BB energy and strong slowing nearly coincide. Make only a small reduction in restriction, then confirm that the useful-energy event remains first.", "Korisna energija BB-a i snažno usporavanje gotovo se podudaraju. Samo malo smanjite ograničenje protoka pa potvrdite da događaj korisne energije ostaje prvi."],
      "timing-useful-first": ["Useful acceleration comes first", "Korisno ubrzavanje dolazi prvo", "The selected BB-energy threshold is reached before strong piston slowing. Fine-tune only if piston contact or muzzle discharge still needs improvement.", "Odabrani prag energije BB-a dosegnut je prije snažnog usporavanja pistona. Dodatno podešavajte samo ako još treba smanjiti kontakt pistona ili pražnjenje na ustima."],
      "timing-after-exit": ["Timing target achieved in the model", "Vremenski cilj ostvaren je u modelu", "Strong slowing starts after BB exit. If contact energy remains high, increase cushioning in very small steps and stop before the timing margin becomes negative.", "Snažno usporavanje počinje nakon izlaska BB-a. Ako je energija kontakta još visoka, povećavajte ublažavanje u vrlo malim koracima i stanite prije nego vremenski razmak postane negativan."],
      "strengthen-cushion": ["No strong cushion event detected", "Nije prepoznato snažno pneumatsko ublažavanje", "If piston contact is still too energetic, test a slightly longer pin or smaller measured clearance. Do not treat a missing event as a soft landing.", "Ako je kontakt pistona još prejak, isprobajte malo dulji pin ili manji izmjereni zazor. Izostanak događaja ne smatrajte mekanim zaustavljanjem."],
      "measure-pin": ["Establish an airbrake reference", "Postavi referencu zračne kočnice", "The airbrake is off. Enter measured pin, bumper, head and nozzle geometry before judging pneumatic cushioning.", "Zračna kočnica je isključena. Unesite izmjerenu geometriju pina, gumice, glave i mlaznice prije procjene pneumatskog ublažavanja."],
      "resolve-exit": ["Resolve BB exit first", "Prvo riješi izlazak BB-a", "The model did not record BB exit, so timing and muzzle recommendations are incomplete. Check spring force, hop resistance, barrel drag and observation time.", "Model nije zabilježio izlazak BB-a pa preporuke za vremenski odnos i usta cijevi nisu potpune. Provjerite silu opruge, otpor hopa, otpor cijevi i vrijeme promatranja."],
      "timing-unknown": ["Timing is unresolved", "Vremenski odnos nije riješen", "Required events are missing. Inspect the event list and input validity before tuning the airbrake.", "Nedostaju potrebni događaji. Prije podešavanja zračne kočnice provjerite popis događaja i valjanost ulaza."],
      "impact-lower": ["Mechanical strike contributor is lower", "Doprinos mehaničkog udara je niži", "Modeled contact energy is lower than the no-airbrake reference. Keep this gain only if BB energy and timing remain acceptable; actual sound still depends on the bumper and rifle structure.", "Modelirana energija kontakta niža je od reference bez zračne kočnice. Zadržite dobitak samo ako su energija BB-a i vremenski odnos prihvatljivi; stvarni zvuk i dalje ovisi o gumici i konstrukciji replike."],
      "impact-higher": ["Mechanical strike moved the wrong way", "Mehanički udar krenuo je u pogrešnom smjeru", "Contact energy is higher than the no-airbrake reference. Check for poorly timed restriction or reversal before adding more airbrake.", "Energija kontakta viša je od reference bez zračne kočnice. Prije jačanja zračne kočnice provjerite loše tempirano ograničenje ili povratno gibanje."],
      "impact-similar": ["Contact energy is broadly similar", "Energija kontakta je približno slična", "The modeled airbrake has not materially changed first-contact energy. Use measured bumper behavior and chrono data before interpreting sound.", "Modelirana zračna kočnica nije bitno promijenila energiju prvog kontakta. Prije zaključivanja o zvuku koristite izmjereno ponašanje gumice i podatke kronografa."],
      "impact-unknown": ["Piston contact is unknown", "Kontakt pistona je nepoznat", "No first contact was recorded. This is not evidence of silence or a soft landing; extend the run or inspect a pressure-driven reversal.", "Prvi kontakt nije zabilježen. To nije dokaz tišine ni mekanog zaustavljanja; produljite simulaciju ili provjerite povrat uzrokovan tlakom."],
      "muzzle-lower": ["Escaping-air contributor is lower", "Doprinos izlaznog zraka je niži", "Peak modeled muzzle flow is lower than the no-airbrake reference. Confirm exit energy before keeping the change; this is not a dB prediction.", "Vršni modelirani protok na ustima niži je od reference bez zračne kočnice. Prije zadržavanja promjene potvrdite izlaznu energiju; ovo nije predviđanje dB."],
      "muzzle-higher": ["More compressed air remains at the muzzle", "Više stlačenog zraka ostaje na ustima", "Peak muzzle flow is higher than the reference. Explore cylinder/barrel volume matching or a longer barrel while preserving the required BB energy.", "Vršni protok na ustima viši je od reference. Istražite usklađivanje volumena cilindra i cijevi ili dulju cijev uz očuvanje potrebne energije BB-a."],
      "muzzle-similar": ["Muzzle discharge is broadly similar", "Pražnjenje na ustima je približno slično", "The current airbrake has not materially changed peak outflow. Volume matching and exit pressure are the more relevant next checks.", "Trenutačna zračna kočnica nije bitno promijenila vršni protok. Usklađivanje volumena i izlazni tlak važnije su sljedeće provjere."],
      "muzzle-unknown": ["Muzzle discharge is unknown", "Pražnjenje na ustima je nepoznato", "Without a recorded BB exit, the model cannot compare muzzle flow.", "Bez zabilježenog izlaska BB-a model ne može usporediti protok na ustima."],
      "measure-first": ["Replace assumptions with measurements", "Zamijeni pretpostavke mjerenjima", "Geometry or spring data are still marked assumed. Measure the hardware and add confirmed chrono shots before treating small model differences as meaningful.", "Geometrija ili podaci opruge još su označeni kao pretpostavke. Izmjerite dijelove i dodajte potvrđene kronografske hitce prije nego male razlike modela smatrate značajnima."]
    };
    const actions = actionPlan(s, baseline, p, provenance).map((action, index) => {
      const copy = actionCopy[action.code], target = action.view ? `data-feedback-view="${action.view}"` : `data-feedback-category="${action.category}"`;
      return `<article class="action-step" data-tone="${action.tone}"><span class="action-number">${index + 1}</span><div><strong>${t(copy[0], copy[1])}</strong>${finite(action.percent) ? `<small>${fmt(action.percent, 1, "%")} · ${t("of no-airbrake reference", "reference bez zračne kočnice")}</small>` : ""}<p>${t(copy[2], copy[3])}</p><button type="button" class="secondary-button" ${target}>${action.view === "calibration" ? t("Open chrono calibration", "Otvori kalibraciju kronografom") : action.category === "geometry" ? t("Open cylinder & barrel", "Otvori cilindar i cijev") : action.category === "solver" ? t("Open timing & solver", "Otvori vrijeme i rješavač") : t("Open airbrake settings", "Otvori postavke zračne kočnice")}</button></div></article>`;
    }).join("");
    const comparison = snapshot?.changes?.length ? `<div class="change-summary"><div class="change-copy"><strong>${snapshot.changes.length === 1 ? t("One modeled input changed", "Promijenjen je jedan modelirani ulaz") : t(`${snapshot.changes.length} modeled inputs changed together`, `${snapshot.changes.length} modelirana ulaza promijenjena su zajedno`)}</strong><p>${snapshot.changes.length === 1 ? t("This is a direct before/after model comparison. It is still not experimental proof.", "Ovo je izravna usporedba modela prije i poslije. Još uvijek nije eksperimentalni dokaz.") : t("The outcome is combined; it cannot be assigned to one input without changing them separately.", "Rezultat je zajednički; ne može se pripisati jednom ulazu bez odvojenih promjena.")}</p></div><div class="change-chips">${shownChanges.map(change => `<span><b>${changeName(change)}</b>${valueText(change, "before")} → ${valueText(change, "after")}</span>`).join("")}${extra ? `<span>+${extra} ${t("more", "više")}</span>` : ""}</div></div><div class="change-metrics">${metrics}</div>` : `<div class="change-empty"><strong>${t("Make one change to create an A/B comparison", "Napravite jednu promjenu za A/B usporedbu")}</strong><p>${t("The next valid calculation will compare every key outcome with this setup.", "Sljedeći valjani izračun usporedit će sve ključne rezultate s ovom konfiguracijom.")}</p></div>`;
    return `<section id="setupFeedback" class="panel setup-feedback" tabindex="-1"><div class="feedback-heading"><div><h2>${t("What changed & what to try next", "Što se promijenilo i što probati dalje")}</h2><p>${t("Model-guided feedback from the last valid setup, followed by prioritized tuning hypotheses.", "Povratne informacije modela prema zadnjoj valjanoj konfiguraciji, zatim prioritetne hipoteze za podešavanje.")}</p></div><span class="tag unknown">${t("not guaranteed", "nije jamstvo")}</span></div>${comparison}<h3>${t("Action steps", "Sljedeći koraci")}</h3><div class="action-steps">${actions}</div><div class="feedback-footer"><p>${t("Change one hardware input at a time, preserve the energy you need, and verify with chrono measurements. “Similar” means 85–110% of the no-airbrake reference. These steps optimize model quantities—not real dB.", "Mijenjajte po jedan dio, očuvajte potrebnu energiju i provjerite kronografom. „Slično” znači 85–110% reference bez zračne kočnice. Ovi koraci optimiziraju veličine modela — ne stvarne dB.")}</p><button type="button" class="primary-button" data-feedback-view="optimizer">${t("Compare combinations at 95–105% energy", "Usporedi kombinacije uz 95–105% energije")}</button></div></section>`;
  }
  const api = { thresholdPercent, timing, verdictText, timingMarkup, compare, soundQuantities, soundMarkup, impactSummary, impactMarkup, parameterChanges, comparisonSnapshot, actionPlan, feedbackMarkup };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.PneumaticInsights = api;
})(typeof globalThis !== "undefined" ? globalThis : this);


/* Dynamic bilingual measurement atlas for the configured hardware. The SVGs
   are explanatory cutaways: numeric labels are inputs, not metrology-grade CAD. */
(function (root) {
  "use strict";
  const P = typeof module !== "undefined" && module.exports ? require("./physics.js") : root.PneumaticPhysics;
  const esc = value => String(value ?? "").replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[character]));
  const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
  const number = value => Number.isFinite(value) ? value : 0;
  const label = (pair, t) => t(pair[0], pair[1]);

  const UNITS = {
    cylinderBore: "mm", strokeLength: "mm", pistonMass: "g", deadVolume: "cm³",
    bumperThickness: "mm", bumperBore: "mm", airbrakeLength: "mm", airbrakeDiameter: "mm",
    airbrakeTipDiameter: "mm", airbrakeTaper: "mm", headBore: "mm", headLength: "mm",
    nozzleBore: "mm", nozzleLength: "mm", breechVolume: "cm³", frontDeadVolume: "cm³", barrelLength: "mm",
    silencerEnabled: "", silencerLength: "mm", silencerInnerDiameter: "mm", silencerBaffleCount: "",
    silencerBaffleThickness: "mm", silencerBaffleBore: "mm", silencerEndCapBore: "mm", silencerPackingFraction: "",
    silencerDischargeCoefficient: "", silencerHeatTransfer: "W/K",
    barrelDiameter: "mm", bbDiameter: "mm", bbMass: "g", springFreeLength: "mm",
    springInstalledLength: "mm", springCutLength: "mm", springActiveCoils: "turns",
    springRemovedCoils: "turns", springSolidLength: "mm", springStiffness: "N/m",
    springPreload: "mm", springMass: "g", pistonFriction: "N", sealFriction: "",
    rearDamping: "N·s/m", bumperStiffness: "N/mm", bumperDamping: "N·s/m", bumperMaxCompression: "mm",
    restitution: "", dischargeCoefficient: "", muzzleDischargeCoefficient: "", pistonLeak: "mm²",
    nozzleLeak: "mm²", bbLeakCoefficient: "", bbBreakaway: "N", barrelDrag: "N",
    heatTransfer: "W/K", ambientPressure: "kPa abs", airTemperature: "°C",
    usefulFraction: "", decelThreshold: "m/s²", maxTime: "ms"
  };
  const DIGITS = {
    cylinderBore: 2, barrelDiameter: 2, bbDiameter: 2, bumperBore: 2,
    airbrakeDiameter: 2, airbrakeTipDiameter: 2, headBore: 2, nozzleBore: 2,
    deadVolume: 2, breechVolume: 2, frontDeadVolume: 3, pistonLeak: 3, nozzleLeak: 3,
    sealFriction: 3, bbLeakCoefficient: 2, restitution: 2, dischargeCoefficient: 2, muzzleDischargeCoefficient: 2,
    heatTransfer: 3, silencerInnerDiameter: 2, silencerBaffleThickness: 2, silencerBaffleBore: 2, silencerEndCapBore: 2,
    silencerPackingFraction: 2, silencerDischargeCoefficient: 2, silencerHeatTransfer: 3, usefulFraction: 3
  };
  const UNKNOWN_ZERO = new Set(["springFreeLength", "springInstalledLength", "springActiveCoils", "springSolidLength", "springMass"]);

  const GROUPS = [
    {
      title: ["Cylinder & piston", "Cilindar i piston"],
      note: ["Measure the working bore, the two contact planes and the complete moving piston assembly.", "Izmjerite radni provrt, dvije dodirne ravnine i cijeli pokretni sklop pistona."],
      rows: [
        ["cylinderBore", ["Cylinder internal diameter", "Unutarnji promjer cilindra"], ["Bore gauge", "Mjerač provrta"], ["Measure the swept working bore at several depths and directions; ordinary caliper jaws are not reliable inside a long bore.", "Izmjerite radni provrt na više dubina i smjerova; obične čeljusti pomičnog mjerila nisu pouzdane u dugom provrtu."]],
        ["strokeLength", ["Nominal piston stroke", "Nominalni hod pistona"], ["Depth rod", "Dubinomjer"], ["Axial distance from the cocked piston-face position to the rigid cylinder-head contact plane, before adding the bumper.", "Uzdužna udaljenost od položaja čela zapetog pistona do ravnine dodira krute glave, prije dodavanja gumice."]],
        ["pistonMass", ["Assembled moving piston mass", "Masa sastavljenog pokretnog pistona"], ["Digital scale", "Digitalna vaga"], ["Weigh the exact moving assembly: body, cup/seal, airbrake pin and fitted weights. Do not add the stationary bumper.", "Izvažite točan pokretni sklop: tijelo, čašicu/brtvu, pin zračne kočnice i utege. Ne dodajte nepomičnu gumicu."]],
        ["deadVolume", ["Cylinder-side residual cavity", "Preostala šupljina na strani cilindra"], ["Derived volume", "Izvedeni volumen"], ["Derive from the cavity geometry at piston contact, including recesses. This is not the swept cylinder volume.", "Izvedite iz geometrije šupljine pri dodiru pistona, uključujući udubljenja. To nije radni volumen cilindra."]]
      ]
    },
    {
      title: ["Airbrake, bumper & head", "Zračna kočnica, gumica i glava"],
      note: ["These dimensions decide where the pin tip is when the piston face first touches the bumper or head.", "Ove dimenzije određuju gdje se vrh pina nalazi kada čelo pistona prvi put dodirne gumicu ili glavu."],
      rows: [
        ["airbrakeLength", ["Pin projection", "Izbočenje pina"], ["Depth caliper", "Dubinsko mjerilo"], ["From the piston contact face to the farthest point of the airbrake tip, parallel to the piston axis.", "Od dodirnog čela pistona do najudaljenije točke vrha pina, paralelno s osi pistona."]],
        ["airbrakeDiameter", ["Airbrake shaft diameter", "Promjer tijela pina"], ["Micrometer", "Mikrometar"], ["Measure the full-diameter cylindrical section, not the tapered tip.", "Mjerite cilindrični dio punog promjera, ne konusni vrh."]],
        ["airbrakeTipDiameter", ["Airbrake tip diameter", "Promjer vrha pina"], ["Micrometer", "Mikrometar"], ["Measure at the forward end. Enter zero only for a genuinely sharp mathematical-tip approximation.", "Mjerite na prednjem kraju. Nulu unesite samo kao aproksimaciju stvarno oštrog matematičkog vrha."]],
        ["airbrakeTaper", ["Taper length", "Duljina konusa"], ["Caliper", "Pomično mjerilo"], ["Axial length from where the shaft begins narrowing to the end of the tip.", "Uzdužna duljina od mjesta gdje se tijelo počinje sužavati do kraja vrha."]],
        ["bumperThickness", ["Added bumper thickness", "Debljina dodatne gumice"], ["Caliper, light load", "Pomično mjerilo, mala sila"], ["Uncompressed axial thickness. Soft rubber changes under clamp force; record the measurement method.", "Nestlačena uzdužna debljina. Meka guma mijenja se pod silom čeljusti; zabilježite način mjerenja."]],
        ["bumperBore", ["Bumper inner diameter", "Unutarnji promjer gumice"], ["Pin gauges", "Mjerni trnovi"], ["Measure the smallest free opening through the bumper. Do not assume it equals the metal receiving bore.", "Izmjerite najmanji slobodni otvor kroz gumicu. Ne pretpostavljajte da je jednak metalnom ulaznom provrtu."]],
        ["headBore", ["Head receiving-bore diameter", "Promjer ulaznog provrta glave"], ["Pin gauges", "Mjerni trnovi"], ["The metal bore the airbrake enters after any bumper—not the nozzle outlet diameter.", "Metalni provrt u koji pin ulazi nakon gumice — nije promjer izlaznog kanala mlaznice."]],
        ["headLength", ["Receiving-passage length", "Duljina ulaznog provrta"], ["Depth rod", "Dubinomjer"], ["Axial length of the receiving bore before the passage changes into the downstream nozzle section.", "Uzdužna duljina ulaznog provrta prije prijelaza u izlazni kanal mlaznice."]],
        ["nozzleBore", ["Downstream nozzle diameter", "Promjer izlaznog kanala mlaznice"], ["Pin gauges", "Mjerni trnovi"], ["Smallest effective internal diameter after the receiving passage and before the hop chamber.", "Najmanji efektivni unutarnji promjer nakon ulaznog provrta i prije hop komore."]],
        ["nozzleLength", ["Downstream nozzle length", "Duljina izlaznog kanala mlaznice"], ["Depth rod", "Dubinomjer"], ["Axial length assigned to the smaller downstream passage.", "Uzdužna duljina pripisana manjem izlaznom kanalu."]],
        ["breechVolume", ["Head / nozzle / breech storage", "Volumen glave, mlaznice i komore"], ["Derived volume", "Izvedeni volumen"], ["Derive from the connected cavity geometry behind the seated BB. Keep it separate from cylinder-side dead volume.", "Izvedite iz spojene geometrije šupljine iza postavljenog BB-a. Držite ga odvojeno od preostalog volumena cilindra."]],
        ["frontDeadVolume", ["Front-gas terminal volume", "Završni volumen zraka ispred BB-a"], ["Muzzle geometry / model input", "Geometrija usta / ulaz modela"], ["Small residual volume retained when the BB reaches the crown so the front-gas control volume never becomes mathematically zero. It is not the complete barrel volume.", "Mali preostali volumen kada BB dosegne usta kako prednji plinski volumen ne bi matematički postao nula. To nije cijeli volumen cijevi."]]
      ]
    },
    {
      title: ["Inner barrel & BB", "Unutarnja cijev i BB"],
      note: ["The barrel diameter and actual BB diameter are separate inputs; their difference controls the model's annular leakage path.", "Promjer cijevi i stvarni promjer BB-a odvojeni su ulazi; njihova razlika određuje prstenasti put curenja u modelu."],
      rows: [
        ["barrelLength", ["Inner-barrel length", "Duljina unutarnje cijevi"], ["Rule / caliper", "Ravnalo / pomično mjerilo"], ["From the BB start plane used by the model to the muzzle crown along the bore axis.", "Od početne ravnine BB-a koju koristi model do krune cijevi duž osi provrta."]],
        ["barrelDiameter", ["Inner-barrel diameter", "Promjer unutarnje cijevi"], ["Certified plug gauges", "Umjereni mjerni trnovi"], ["Measure the bore rather than relying only on the nominal 6.01/6.03/6.05 marking; check more than one location when possible.", "Mjerite provrt umjesto oslanjanja samo na oznaku 6,01/6,03/6,05; po mogućnosti provjerite više mjesta."]],
        ["bbDiameter", ["Actual BB diameter", "Stvarni promjer BB-a"], ["Micrometer", "Mikrometar"], ["Measure several BBs in multiple orientations with low force and use a representative mean.", "Izmjerite više BB-a u više smjerova uz malu silu i koristite reprezentativni prosjek."]],
        ["bbMass", ["BB mass", "Masa BB-a"], ["0.001 g scale", "Vaga 0,001 g"], ["Weigh a batch and divide by the count; packet labels are useful provenance but not a measurement.", "Izvažite skupinu i podijelite s brojem kuglica; oznaka na pakiranju korisna je kao izvor, ali nije mjerenje."]]
      ]
    },
    {
      title: ["Silencer / suppressor", "Prigušivač"],
      note: ["Measure the internal gas space and every minimum bore along the BB path. Exterior length or diameter alone does not define the expansion volume.", "Izmjerite unutarnji prostor plina i svaki najmanji provrt na putu BB-a. Sama vanjska duljina ili promjer ne određuju ekspanzijski volumen."],
      rows: [
        ["silencerEnabled", ["Installed for this shot", "Ugrađen za ovaj hitac"], ["Assembly record", "Zapis sklopa"], ["Enable only when this exact silencer was mounted. Disabled geometry is retained for later comparison but does not enter the shot model.", "Uključite samo kada je ovaj prigušivač stvarno ugrađen. Isključena geometrija ostaje za kasniju usporedbu, ali ne ulazi u model hica."]],
        ["silencerLength", ["Internal expansion length", "Unutarnja ekspanzijska duljina"], ["Depth rod", "Dubinomjer"], ["Usable axial chamber length from the inner-barrel crown/entrance plane to the inside of the end cap—not the complete exterior length including threads.", "Uporabljiva uzdužna duljina komore od krune unutarnje cijevi/ulazne ravnine do unutarnje strane završne kape — ne ukupna vanjska duljina s navojem."]],
        ["silencerInnerDiameter", ["Internal chamber diameter", "Unutarnji promjer komore"], ["Bore gauge / derived", "Mjerač provrta / izvedeno"], ["Diameter of the main expansion cavity. Together with internal length it sets gross volume and pressure rise.", "Promjer glavne ekspanzijske šupljine. Zajedno s unutarnjom duljinom određuje bruto volumen i porast tlaka."]],
        ["silencerBaffleCount", ["Baffle count", "Broj pregrada"], ["Count", "Brojanje"], ["Count plates/cones that materially interrupt the axial flow. More entered baffles displace gas volume and increase the conditional lumped flow-loss factor.", "Brojite ploče/konuse koji bitno prekidaju uzdužni protok. Više unesenih pregrada oduzima volumen plina i povećava uvjetni koncentrirani faktor gubitka protoka."]],
        ["silencerBaffleThickness", ["Average baffle thickness", "Prosječna debljina pregrade"], ["Caliper", "Pomično mjerilo"], ["Representative axial solid thickness per baffle. The model subtracts its annular solid volume and adds a finite-thickness loss term.", "Reprezentativna uzdužna debljina pune pregrade. Model oduzima njezin puni prstenasti volumen i dodaje član gubitka zbog konačne debljine."]],
        ["silencerBaffleBore", ["Smallest baffle/core bore", "Najmanji provrt pregrade/jezgre"], ["Pin gauges", "Mjerni trnovi"], ["Smallest clear diameter repeated through the baffle stack. It must exceed the actual BB diameter with real alignment clearance; the model does not certify strike safety.", "Najmanji slobodni promjer koji se ponavlja kroz sklop pregrada. Mora biti veći od stvarnog BB-a uz stvarni zazor poravnanja; model ne potvrđuje sigurnost od udara BB-a."]],
        ["silencerEndCapBore", ["Exit end-cap bore", "Provrt izlazne završne kape"], ["Pin gauges", "Mjerni trnovi"], ["Smallest clear exit diameter. Along with the baffle bore and conditional Cd, it controls the modeled final atmospheric outflow.", "Najmanji slobodni izlazni promjer. Zajedno s provrtom pregrada i uvjetnim Cd-om određuje modelirani konačni protok u atmosferu."]],
        ["silencerPackingFraction", ["Solid fill fraction", "Udio punog volumena ispune"], ["Volume / mass estimate", "Procjena volumena / mase"], ["Estimated fraction of otherwise open chamber volume occupied by foam, mesh or other solid fill. It reduces free gas volume and increases the heuristic flow loss; it is not porosity measured by this app.", "Procijenjeni udio inače otvorenog volumena komore koji zauzima pjena, mrežica ili druga čvrsta ispuna. Smanjuje slobodni volumen plina i povećava heuristički gubitak protoka; aplikacija ne mjeri poroznost."]]
      ]
    },
    {
      title: ["Spring & seats", "Opruga i oslonci"],
      note: ["Length mode and direct-compression mode describe the same installed spring in different ways; do not mix their reference planes.", "Način s duljinama i način s izravnim stlačenjem opisuju istu ugrađenu oprugu na različite načine; nemojte miješati njihove referentne ravnine."],
      rows: [
        ["springFreeLength", ["Unloaded spring length", "Slobodna duljina opruge"], ["Rule / caliper", "Ravnalo / pomično mjerilo"], ["Axial end-to-end length before the simulated cut, with no load on the spring.", "Uzdužna duljina od kraja do kraja prije simuliranog reza, bez opterećenja opruge."]],
        ["springInstalledLength", ["Front seat distance", "Prednji razmak oslonaca"], ["Depth measurement", "Mjerenje dubine"], ["Spring-seat distance at the rigid-head plane before an added bumper. The model subtracts bumper thickness once.", "Razmak oslonaca opruge na ravnini krute glave prije dodatne gumice. Model jednom oduzima debljinu gumice."]],
        ["springCutLength", ["Free length removed", "Uklonjena slobodna duljina"], ["Before / after", "Prije / poslije"], ["Difference in unloaded axial length, not the wire length that was cut away.", "Razlika nestlačene uzdužne duljine, ne duljina uklonjene žice."]],
        ["springActiveCoils", ["Active coils before cutting", "Aktivni zavoji prije rezanja"], ["Count", "Brojanje"], ["Count coils that deflect under load; inactive closed end turns are not active coils.", "Brojite zavoje koji se deformiraju pod opterećenjem; zatvoreni krajnji zavoji nisu aktivni."]],
        ["springRemovedCoils", ["Removed active coils", "Uklonjeni aktivni zavoji"], ["Count", "Brojanje"], ["Count only active turns removed. This is used for the uniform-coil stiffness estimate.", "Brojite samo uklonjene aktivne zavoje. To se koristi za procjenu krutosti jednolike opruge."]],
        ["springSolidLength", ["Remaining solid height", "Preostala potpuno stisnuta duljina"], ["Bench measurement", "Mjerenje na stolu"], ["End-to-end height of the remaining spring at coil bind. Use a safe fixture; never measure inside a cocked assembly.", "Duljina preostale opruge od kraja do kraja pri potpunom stiskanju. Koristite siguran prihvat; nikada ne mjerite u zapetom sklopu."]],
        ["springStiffness", ["Spring stiffness", "Krutost opruge"], ["Force curve", "Krivulja sile"], ["Fit the slope of measured force versus compression over the installed range. An M-rating is not a force curve.", "Prilagodite nagib izmjerene sile prema stlačenju u ugrađenom rasponu. Oznaka M nije krivulja sile."]],
        ["springPreload", ["Front-contact compression", "Stlačenje pri prednjem kontaktu"], ["Geometry / force", "Geometrija / sila"], ["Direct-mode compression at the rigid-head plane before adding the bumper; length mode calculates it instead.", "Stlačenje u izravnom načinu na ravnini krute glave prije dodavanja gumice; način s duljinama ga računa."]],
        ["springMass", ["Installed spring mass", "Masa ugrađene opruge"], ["Digital scale", "Digitalna vaga"], ["Weigh the remaining installed spring after any physical cut. Length alone does not determine its mass.", "Izvažite preostalu ugrađenu oprugu nakon fizičkog rezanja. Sama duljina ne određuje masu."]]
      ]
    }
  ];

  const MODEL_ROWS = [
    ["pistonFriction", ["Piston sliding friction", "Klizno trenje pistona"], ["Bench force test", "Ispitivanje sile na stolu"], ["Approximately constant resisting force from the piston guides and seal while the piston moves. Establish it with a safe bench pull/push test; it is not piston mass.", "Približno stalna sila otpora vodilica i brtve dok se piston giba. Odredite je sigurnim stolnim mjerenjem povlačenja/guranja; nije masa pistona."]],
    ["sealFriction", ["Pressure-dependent seal friction", "Trenje brtve ovisno o tlaku"], ["Fit / instrumented test", "Prilagodba / instrumentirano ispitivanje"], ["Additional seal drag that grows with cylinder gauge pressure in this model. It is a fitted factor, not a directly measured force or an O-ring hardness value.", "Dodatni otpor brtve koji u ovom modelu raste s relativnim tlakom u cilindru. To je prilagodbeni faktor, ne izravno izmjerena sila ni tvrdoća O-prstena."]],
    ["rearDamping", ["Rear vent / mechanical drag", "Stražnji otvor / mehanički otpor"], ["Fit / coast-down evidence", "Prilagodba / mjerenje usporavanja"], ["Velocity-proportional resistance representing air displaced behind the piston and other distributed mechanical losses. It is expressed in N·s/m and needs dynamic evidence.", "Otpor razmjeran brzini koji predstavlja zrak istisnut iza pistona i druge raspodijeljene mehaničke gubitke. Izražen je u N·s/m i traži dinamičku potvrdu."]],
    ["bumperStiffness", ["Bumper compression stiffness", "Krutost stlačivanja gumice"], ["Force–deflection bench test", "Stolno mjerenje sile i deformacije"], ["Slope of bumper force versus axial compression. Higher values make the pad resist compression more strongly; this is N/mm, not Shore hardness.", "Nagib sile gumice prema uzdužnom stlačenju. Veća vrijednost znači da se gumica jače opire stlačivanju; jedinica je N/mm, a ne Shore tvrdoća."]],
    ["bumperCurve", ["Measured bumper force curve", "Izmjerena krivulja sile gumice"], ["Force–deflection bench test", "Stolno mjerenje sile i deformacije"], ["Optional compression-versus-force points for nonlinear rubber behavior. When present, this curve replaces the single linear stiffness while damping remains a separate dynamic input.", "Neobavezne točke stlačenja i sile za nelinearni odziv gume. Kada je unesena, krivulja zamjenjuje jednu linearnu krutost, dok prigušenje ostaje zaseban dinamički ulaz."]],
    ["bumperDamping", ["Bumper viscous damping", "Viskozno prigušenje gumice"], ["Dynamic contact fit", "Prilagodba dinamičkog kontakta"], ["Velocity-dependent force used to dissipate energy while the bumper is being compressed or released. It changes rebound in the conditional contact model and is not a dB value.", "Sila ovisna o brzini kojom se rasipa energija dok se gumica stišće ili vraća. Mijenja odskok u uvjetnom modelu kontakta i nije vrijednost u dB."]],
    ["bumperMaxCompression", ["Bumper compression cap", "Granica stlačenja gumice"], ["Geometry plus force test", "Geometrija i ispitivanje sile"], ["Largest allowed axial deformation before the model treats the pad as bottomed out against a rigid stop. The effective cap can never exceed the entered physical thickness.", "Najveća dopuštena uzdužna deformacija prije nego što model smatra da je gumica potpuno stisnuta na kruti graničnik. Efektivna granica nikad ne može biti veća od unesene fizičke debljine."]],
    ["restitution", ["Rigid / bottom-out restitution", "Odskok krutog graničnika"], ["High-speed contact measurement", "Brzo mjerenje kontakta"], ["Fraction controlling velocity reversal only when a rigid head is struck or the bumper reaches its compression cap. Zero means no idealized rigid rebound; it does not control the pneumatic cushion.", "Faktor koji određuje promjenu smjera brzine samo pri udaru u krutu glavu ili dosezanju granice stlačenja gumice. Nula znači bez idealiziranog krutog odskoka; ne upravlja pneumatskim jastukom."]],
    ["dischargeCoefficient", ["Head discharge coefficient Cd", "Koeficijent protoka glave Cd"], ["Flow bench or chrono fit", "Protočna klupa ili chrono prilagodba"], ["Effective loss coefficient for mass flow through the bumper opening, receiving bore and downstream nozzle. It combines contraction and turbulence losses; it is not an efficiency percentage.", "Efektivni koeficijent gubitaka masenog protoka kroz otvor gumice, ulazni provrt i izlazni kanal mlaznice. Vrijednost 1 i dalje nije postotak učinkovitosti; koeficijent sažima suženje i turbulentne gubitke."]],
    ["muzzleDischargeCoefficient", ["Muzzle discharge coefficient Cd", "Koeficijent protoka na ustima Cd"], ["Transient muzzle-flow test", "Mjerenje prijelaznog protoka na ustima"], ["Effective coefficient for front-gas venting before BB exit and compressed-gas discharge after exit. It can influence both exit speed and the modeled muzzle-flow contributor.", "Efektivni koeficijent odzračivanja zraka ispred BB-a prije izlaska i pražnjenja stlačenog plina nakon izlaska. Može utjecati i na izlaznu brzinu i na modelirani doprinos protoka na ustima."]],
    ["silencerDischargeCoefficient", ["Silencer outlet discharge Cd", "Koeficijent protoka izlaza prigušivača Cd"], ["Pressure/flow transient fit", "Prilagodba prijelaza tlaka/protoka"], ["Effective contraction/turbulence coefficient applied after the measured baffle/end-cap geometry. It strongly affects peak outlet flow and decay time but is not an acoustic attenuation rating.", "Efektivni koeficijent suženja/turbulencije nakon izmjerene geometrije pregrada i završne kape. Snažno utječe na vršni izlazni protok i vrijeme pada, ali nije ocjena akustičkog prigušenja."]],
    ["silencerHeatTransfer", ["Silencer heat conductance", "Toplinska vodljivost prigušivača"], ["Instrumented transient fit", "Instrumentirana prilagodba prijelaza"], ["Lumped heat exchange between silencer gas and its internals/wall. More conductance removes gas energy faster in the model; material, surface area and shot cadence are not separately resolved.", "Koncentrirana izmjena topline između plina te unutrašnjosti/stijenke prigušivača. Veća vodljivost brže oduzima energiju plinu u modelu; materijal, površina i ritam pucanja nisu zasebno razriješeni."]],
    ["pistonLeak", ["Piston-seal leak area", "Površina curenja brtve pistona"], ["Leak-down fit", "Prilagodba pada tlaka"], ["Equivalent area for air bypassing the piston seal from the compressed cylinder side. It already represents an effective leak path and is not a visible geometric hole that must have this shape.", "Ekvivalentna površina zraka koji zaobilazi brtvu pistona sa stlačene strane cilindra. Već predstavlja efektivni put curenja i nije nužno vidljiva rupa toga oblika."]],
    ["nozzleLeak", ["Nozzle / hop leak area", "Površina curenja mlaznice / hopa"], ["Leak-down fit", "Prilagodba pada tlaka"], ["Equivalent leak area from the downstream head/nozzle/hop system to atmosphere, separate from controlled flow into the barrel. Use leak-down evidence or calibration.", "Ekvivalentna površina curenja iz izlaznog sklopa glave, mlaznice i hopa prema atmosferi, odvojena od kontroliranog protoka u cijev. Koristite mjerenje pada tlaka ili kalibraciju."]],
    ["bbLeakCoefficient", ["BB-clearance leak coefficient", "Koeficijent curenja oko BB-a"], ["Calibration parameter", "Kalibracijski parametar"], ["Multiplier for air bypass through the annular clearance between the measured BB and barrel diameters. Zero disables that modeled path; one applies the full effective-clearance estimate.", "Množitelj protoka zraka kroz prstenasti zazor između izmjerenog BB-a i promjera cijevi. Nula isključuje taj modelirani put; jedan primjenjuje puni procijenjeni efektivni zazor."]],
    ["bbBreakaway", ["Hop breakaway force", "Sila pokretanja kroz hop"], ["Force gauge", "Mjerač sile"], ["Forward pressure force that must be exceeded before the seated BB starts moving through the hop rubber. Once moving, the separate barrel-drag input applies.", "Sila tlaka prema naprijed koju treba nadmašiti prije nego što postavljeni BB krene kroz hop gumicu. Nakon pokretanja primjenjuje se zaseban unos otpora u cijevi."]],
    ["barrelDrag", ["Moving BB resistance", "Otpor gibanja BB-a"], ["Force / velocity experiment", "Pokus sile / brzine"], ["Approximately constant resisting force on a BB that is already moving through the barrel, including effective hop and contact losses. It is not the initial breakaway force.", "Približno stalna sila otpora na BB koji se već giba kroz cijev, uključujući efektivne gubitke hopa i dodira. Nije početna sila pokretanja."]],
    ["heatTransfer", ["Gas heat conductance", "Toplinska vodljivost plina"], ["Transient fit", "Prilagodba prijelaznog procesa"], ["Lumped heat-flow conductance between each modeled gas volume and the wall at the entered air/wall temperature. Zero approaches adiabatic behavior over the short shot interval.", "Koncentrirana toplinska vodljivost između svakog modeliranog plinskog volumena i stijenke na unesenoj temperaturi zraka/stijenke. Nula se tijekom kratkog hica približava adijabatskom ponašanju."]],
    ["ambientPressure", ["Atmospheric pressure", "Atmosferski tlak"], ["Barometer", "Barometar"], ["Absolute pressure outside the rifle before firing and ahead of the BB. Enter station pressure, not weather-service pressure corrected to sea level.", "Apsolutni tlak izvan replike prije opaljenja i ispred BB-a. Unesite lokalni stvarni tlak, ne meteorološki tlak preračunat na razinu mora."]],
    ["airTemperature", ["Air / wall temperature", "Temperatura zraka / stijenke"], ["Thermometer", "Termometar"], ["Starting temperature assigned to the air and chamber walls. It affects gas density and sound speed; the model does not separately resolve warmed spring or seal materials.", "Početna temperatura dodijeljena zraku i stijenkama komore. Utječe na gustoću plina i brzinu zvuka; model zasebno ne razrješava zagrijanu oprugu ni materijale brtve."]],
    ["usefulFraction", ["Useful-energy threshold", "Prag korisne energije"], ["Analysis convention", "Dogovor analize"], ["Chosen fraction of the shot's maximum BB kinetic energy used to mark when useful acceleration is nearly complete. It is an analysis marker, not a physical switch or efficiency.", "Odabrani udio najveće kinetičke energije BB-a u tom hicu kojim se označuje kada je korisno ubrzavanje gotovo dovršeno. To je oznaka analize, ne fizikalna sklopka ni učinkovitost."]],
    ["decelThreshold", ["Strong-deceleration threshold", "Prag snažnog usporavanja"], ["Analysis convention", "Dogovor analize"], ["Magnitude of negative piston acceleration used to label the start of substantial slowing after airbrake entry. It changes the event marker, not the simulated forces or motion.", "Iznos negativnog ubrzanja pistona kojim se nakon ulaska pina označuje početak značajnog usporavanja. Mijenja oznaku događaja, ne simulirane sile ni gibanje."]],
    ["maxTime", ["Maximum modeled time", "Najdulje modelirano vrijeme"], ["Solver limit", "Granica rješavača"], ["Time limit at which numerical integration stops if later events or pressure settling have not completed. Increasing it observes a longer tail; it does not slow the firing physics.", "Vremenska granica na kojoj numerička integracija staje ako kasniji događaji ili smirivanje tlaka nisu završili. Povećanje prati dulji završetak; ne usporava fiziku opaljenja."]]
  ];

  const PART_FIELDS = GROUPS.flatMap(group => group.rows.map(row => row[0]));
  const FIELD_HELP = Object.fromEntries([...GROUPS.flatMap(group => group.rows), ...MODEL_ROWS].map(row => [row[0], row[3]]));

  function help(key, t = (en => en)) {
    const pair = FIELD_HELP[key];
    return pair ? label(pair, t) : "";
  }

  function fieldValue(p, key, t) {
    const value = p[key];
    if (key === "bumperCurve") return Array.isArray(value) && value.length ? t(`${value.length} measured points`, `${value.length} izmjerenih točaka`) : t("Not entered", "Nije uneseno");
    if (key === "silencerEnabled") return value === 1 ? t("Installed", "Ugrađen") : t("Not installed", "Nije ugrađen");
    if (key === "silencerPackingFraction" && Number.isFinite(value)) return `${(value * 100).toFixed(1)}%`;
    if (!Number.isFinite(value)) return "—";
    if (UNKNOWN_ZERO.has(key) && value === 0) return t("Unknown / not entered", "Nepoznato / nije uneseno");
    const digits = DIGITS[key] ?? (Math.abs(value) < 1 && value !== 0 ? 2 : 1);
    const shown = value.toFixed(digits);
    const unit = UNITS[key];
    if (unit === "turns") return `${shown} ${t("turns", "zavoja")}`;
    return `${shown}${unit ? ` ${unit}` : ""}`;
  }

  function defs(id) {
    return `<defs>
      <linearGradient id="steel-${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--line-bright)"/><stop offset=".48" stop-color="var(--text)"/><stop offset=".55" stop-color="var(--muted)"/><stop offset="1" stop-color="var(--line)"/></linearGradient>
      <linearGradient id="dark-steel-${id}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="var(--panel-2)"/><stop offset=".5" stop-color="var(--line-bright)"/><stop offset="1" stop-color="var(--panel-2)"/></linearGradient>
      <pattern id="rubber-${id}" width="8" height="8" patternUnits="userSpaceOnUse"><rect width="8" height="8" fill="color-mix(in srgb,var(--green) 20%,var(--panel))"/><path d="M-2 2L2-2M0 8L8 0M6 10L10 6" stroke="var(--green)" stroke-opacity=".32"/></pattern>
      <marker id="arrow-${id}" markerWidth="7" markerHeight="7" refX="3.5" refY="3.5" orient="auto-start-reverse"><path d="M0 0L7 3.5L0 7Z" fill="var(--cyan)"/></marker>
    </defs>`;
  }
  function dimH(id, x1, x2, y, text) {
    const mid = (x1 + x2) / 2;
    return `<g class="parts-dimension"><line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}" marker-start="url(#arrow-${id})" marker-end="url(#arrow-${id})"/><text x="${mid}" y="${y - 7}" text-anchor="middle">${esc(text)}</text></g>`;
  }
  function dimV(id, x, y1, y2, text, anchor = "start") {
    const tx = anchor === "end" ? x - 10 : x + 10;
    return `<g class="parts-dimension"><line x1="${x}" y1="${y1}" x2="${x}" y2="${y2}" marker-start="url(#arrow-${id})" marker-end="url(#arrow-${id})"/><text x="${tx}" y="${(y1 + y2) / 2 + 4}" text-anchor="${anchor}">${esc(text)}</text></g>`;
  }

  function airPathSvg(p, t) {
    const id = "airpath", scale = 6.2, center = 205, face = 320;
    const bumperWidth = number(p.bumperThickness) * scale;
    const headWidth = number(p.headLength) * scale;
    const nozzleWidth = number(p.nozzleLength) * scale;
    const bumperEnd = face + bumperWidth, headEnd = bumperEnd + headWidth, nozzleEnd = headEnd + nozzleWidth;
    const pinEnd = face + number(p.airbrakeLength) * scale;
    const taperStart = Math.max(face, pinEnd - number(p.airbrakeTaper) * scale);
    const shaftHeight = clamp(number(p.airbrakeDiameter) * 10, 8, 76);
    const tipHeight = clamp(number(p.airbrakeTipDiameter) * 10, 2, shaftHeight);
    const bumperHole = clamp(number(p.bumperBore) * 10, 14, 100);
    const headHole = clamp(number(p.headBore) * 10, 14, 100);
    const nozzleHole = clamp(number(p.nozzleBore) * 10, 14, 100);
    const cylinderHalf = clamp(number(p.cylinderBore) * 3.8, 72, 105);
    let zone;
    if (!(p.airbrakeLength > 0)) zone = t("No airbrake pin enabled", "Pin zračne kočnice nije uključen");
    else if (p.airbrakeLength <= p.bumperThickness) zone = t("Pin tip ends inside the bumper", "Vrh pina završava unutar gumice");
    else if (p.airbrakeLength <= p.bumperThickness + p.headLength) zone = t("Pin tip ends in the metal receiving bore", "Vrh pina završava u metalnom ulaznom provrtu");
    else if (p.airbrakeLength <= p.bumperThickness + p.headLength + p.nozzleLength) zone = t("Pin tip reaches the downstream nozzle", "Vrh pina doseže izlazni kanal mlaznice");
    else zone = t("Pin extends beyond the entered head/nozzle stack", "Pin se proteže izvan unesenog sklopa glave/mlaznice");
    const pin = p.airbrakeLength > 0 ? `<path class="parts-pin" d="M${face} ${center - shaftHeight / 2}H${taperStart}L${pinEnd} ${center - tipHeight / 2}V${center + tipHeight / 2}L${taperStart} ${center + shaftHeight / 2}H${face}Z"/>` : "";
    const bumper = p.bumperThickness > 0 ? `<path class="parts-rubber" d="M${face} 125H${bumperEnd}V${center - bumperHole / 2}H${face}ZM${face} ${center + bumperHole / 2}H${bumperEnd}V285H${face}Z"/>` : `<line class="parts-absent" x1="${face}" y1="125" x2="${face}" y2="285"/>`;
    return `<div class="parts-figure parts-figure-wide">
      <div class="parts-figure-heading"><div><h3>${t("Airbrake-to-head fit at first contact", "Odnos pina i glave pri prvom kontaktu")}</h3><p>${t("This contact-state cutaway shows whether the entered pin stops in the bumper, receiving bore or nozzle.", "Ovaj presjek u stanju kontakta pokazuje završava li uneseni pin u gumici, ulaznom provrtu ili mlaznici.")}</p></div><strong>${esc(zone)}</strong></div>
      <svg class="parts-svg" viewBox="0 0 1160 425" role="img" aria-label="${esc(t("Cutaway of piston, airbrake, bumper, cylinder head, nozzle and barrel with current dimensions", "Presjek pistona, pina, gumice, glave cilindra, mlaznice i cijevi s trenutačnim dimenzijama"))}">
        <title>${esc(zone)}</title>${defs(id)}
        <line class="parts-centerline" x1="34" y1="${center}" x2="1130" y2="${center}"/>
        <path class="parts-cylinder-wall" d="M45 ${center - cylinderHalf - 16}H${face}V${center - cylinderHalf}H45ZM45 ${center + cylinderHalf + 16}H${face}V${center + cylinderHalf}H45Z"/>
        <rect class="parts-piston" x="100" y="${center - cylinderHalf + 8}" width="220" height="${2 * cylinderHalf - 16}" rx="11"/>
        <rect class="parts-piston-face" x="302" y="${center - cylinderHalf + 2}" width="18" height="${2 * cylinderHalf - 4}" rx="4"/>
        ${bumper}
        <path class="parts-head" d="M${bumperEnd} 112H${headEnd}V${center - headHole / 2}H${bumperEnd}ZM${bumperEnd} ${center + headHole / 2}H${headEnd}V298H${bumperEnd}Z"/>
        <path class="parts-nozzle" d="M${headEnd} 151H${nozzleEnd}V${center - nozzleHole / 2}H${headEnd}ZM${headEnd} ${center + nozzleHole / 2}H${nozzleEnd}V259H${headEnd}Z"/>
        <path class="parts-barrel" d="M${nozzleEnd} 169H1130V${center - clamp(number(p.barrelDiameter) * 6, 18, 58) / 2}H${nozzleEnd}ZM${nozzleEnd} ${center + clamp(number(p.barrelDiameter) * 6, 18, 58) / 2}H1130V241H${nozzleEnd}Z"/>
        ${pin}
        <g class="parts-component-labels"><text x="190" y="99">${esc(t("PISTON", "PISTON"))}</text><text x="${face + Math.max(4, bumperWidth) / 2}" y="101" text-anchor="middle">${esc(t("BUMPER", "GUMICA"))}</text><text x="${(bumperEnd + headEnd) / 2}" y="88" text-anchor="middle">${esc(t("RECEIVING BORE", "ULAZNI PROVRT"))}</text><text x="${(headEnd + nozzleEnd) / 2}" y="139" text-anchor="middle">${esc(t("NOZZLE", "MLAZNICA"))}</text><text x="${Math.min(1110, nozzleEnd + 95)}" y="158">${esc(t("BARREL", "CIJEV"))}</text></g>
        ${p.airbrakeLength > 0 ? dimH(id, face, pinEnd, 61, `${t("pin projection", "izbočenje pina")} ${fieldValue(p, "airbrakeLength", t)}`) : ""}
        ${p.bumperThickness > 0 ? dimH(id, face, bumperEnd, 327, `${t("bumper", "gumica")} ${fieldValue(p, "bumperThickness", t)}`) : ""}
        ${dimH(id, bumperEnd, headEnd, 354, `${t("receiving length", "duljina provrta")} ${fieldValue(p, "headLength", t)}`)}
        ${dimH(id, headEnd, nozzleEnd, 381, `${t("nozzle length", "duljina mlaznice")} ${fieldValue(p, "nozzleLength", t)}`)}
        ${dimV(id, 68, center - cylinderHalf, center + cylinderHalf, `Ø ${fieldValue(p, "cylinderBore", t)}`)}
        ${dimV(id, bumperEnd + headWidth * .48, center - headHole / 2, center + headHole / 2, `${t("head", "glava")} Ø ${fieldValue(p, "headBore", t)}`)}
        ${p.bumperThickness > 0 ? `<g class="parts-leader"><path d="M${face + Math.max(3, bumperWidth / 2)} ${center - bumperHole / 2}L${face + 38} 118"/><text x="${face + 43}" y="113">${esc(`${t("bumper ID", "ID gumice")} Ø ${fieldValue(p, "bumperBore", t)}`)}</text></g>` : ""}
        ${p.airbrakeLength > 0 ? `<g class="parts-leader"><path d="M${face + Math.min(70, number(p.airbrakeLength) * scale * .35)} ${center + shaftHeight / 2}L${face + 85} 306"/><text x="${face + 91}" y="311">${esc(`${t("shaft", "tijelo")} Ø ${fieldValue(p, "airbrakeDiameter", t)} · ${t("tip", "vrh")} Ø ${fieldValue(p, "airbrakeTipDiameter", t)}`)}</text></g>` : ""}
      </svg>
      <p class="parts-scale-note">${t("Axial lengths in the head stack share one scale. Bore diameters and small clearances are enlarged independently so they remain visible; the numeric labels are the exact current inputs.", "Uzdužne duljine u sklopu glave imaju zajedničko mjerilo. Promjeri provrta i mali zazori zasebno su uvećani radi vidljivosti; brojčane oznake točni su trenutačni ulazi.")}</p>
    </div>`;
  }

  function cylinderSvg(p, t) {
    const id = "cylinder", left = 76, right = 486, center = 134;
    const contact = right - clamp(number(p.bumperThickness) / Math.max(1, number(p.strokeLength)) * (right - left), 0, 100);
    const boreHalf = clamp(number(p.cylinderBore) * 2.1, 42, 64);
    const g = P.geometry(p, 0, 0);
    return `<div class="parts-figure"><div class="parts-figure-heading"><div><h3>${t("Cylinder, piston & travel", "Cilindar, piston i hod")}</h3><p>${t("Nominal stroke ends at the rigid head plane; an added bumper moves first contact rearward.", "Nominalni hod završava na ravnini krute glave; dodatna gumica pomiče prvi kontakt unatrag.")}</p></div></div>
      <svg class="parts-svg" viewBox="0 0 560 285" role="img" aria-label="${esc(t("Cylinder cutaway with bore, nominal stroke and effective contact travel", "Presjek cilindra s provrtom, nominalnim hodom i efektivnim hodom do kontakta"))}">${defs(id)}
        <line class="parts-centerline" x1="35" y1="${center}" x2="520" y2="${center}"/>
        <path class="parts-cylinder-wall" d="M35 ${center - boreHalf - 14}H505V${center - boreHalf}H35ZM35 ${center + boreHalf + 14}H505V${center + boreHalf}H35Z"/>
        <rect class="parts-piston" x="43" y="${center - boreHalf + 7}" width="${left - 43 + 18}" height="${2 * boreHalf - 14}" rx="8"/><rect class="parts-piston-face" x="${left}" y="${center - boreHalf + 2}" width="14" height="${2 * boreHalf - 4}" rx="3"/>
        ${p.bumperThickness > 0 ? `<rect class="parts-rubber" x="${contact}" y="${center - boreHalf}" width="${right - contact}" height="${2 * boreHalf}"/>` : ""}<line class="parts-contact-plane" x1="${contact}" y1="${center - boreHalf - 8}" x2="${contact}" y2="${center + boreHalf + 8}"/><line class="parts-rigid-plane" x1="${right}" y1="${center - boreHalf - 8}" x2="${right}" y2="${center + boreHalf + 8}"/>
        <text class="parts-part-label" x="56" y="${center + 5}">${esc(fieldValue(p, "pistonMass", t))}</text>
        <text class="parts-caption" x="${contact - 8}" y="57" text-anchor="end">${esc(t("first contact", "prvi kontakt"))}</text><text class="parts-caption" x="${right}" y="76" text-anchor="end">${esc(t("rigid head plane", "ravnina krute glave"))}</text>
        ${dimH(id, left, contact, 35, `${t("effective travel", "efektivni hod")} ${(p.strokeLength - p.bumperThickness).toFixed(1)} mm`)}
        ${dimH(id, left, right, 243, `${t("nominal stroke", "nominalni hod")} ${fieldValue(p, "strokeLength", t)}`)}
        ${dimV(id, 523, center - boreHalf, center + boreHalf, `Ø ${fieldValue(p, "cylinderBore", t)}`, "end")}
      </svg><p class="parts-scale-note">${t("Current effective swept volume", "Trenutačni efektivni radni volumen")}: <strong>${(g.sweptVolume * 1e6).toFixed(2)} cm³</strong>. ${t("Undeformed bumper shown; modeled compression cap / force law", "Prikazana je nestlačena gumica; modelirana granica stlačenja / zakon sile")}: <strong>${Math.min(p.bumperThickness, p.bumperMaxCompression).toFixed(2)} mm / ${p.bumperCurve.length ? t(`${p.bumperCurve.length}-point measured curve`, `izmjerena krivulja s ${p.bumperCurve.length} točaka`) : `${p.bumperStiffness.toFixed(0)} N/mm`}</strong>. ${t("Exact deformed shape is unknown.", "Točan deformirani oblik nije poznat.")}</p></div>`;
  }

  function barrelSvg(p, t) {
    const id = "barrel", center = 137, bore = clamp(number(p.barrelDiameter) * 4, 18, 34), bb = clamp(number(p.bbDiameter) / Math.max(number(p.barrelDiameter), .1) * bore, 12, bore - 1);
    const radial = Math.max(0, (p.barrelDiameter - p.bbDiameter) / 2);
    return `<div class="parts-figure"><div class="parts-figure-heading"><div><h3>${t("Inner barrel & BB clearance", "Unutarnja cijev i zazor BB-a")}</h3><p>${t("The end view enlarges the very small annular gap so the two diameters are distinguishable.", "Pogled s kraja uvećava vrlo mali prstenasti zazor kako bi se dva promjera mogla razlikovati.")}</p></div></div>
      <svg class="parts-svg" viewBox="0 0 560 285" role="img" aria-label="${esc(t("Inner barrel with length, bore diameter, BB diameter and radial clearance", "Unutarnja cijev s duljinom, promjerom provrta, promjerom BB-a i radijalnim zazorom"))}">${defs(id)}
        <path class="parts-barrel" d="M45 102H515V${center - bore / 2}H45ZM45 ${center + bore / 2}H515V172H45Z"/><line class="parts-centerline" x1="30" y1="${center}" x2="530" y2="${center}"/>
        <circle class="parts-bb" cx="87" cy="${center}" r="${bb / 2}"/><path class="parts-motion" d="M113 ${center}H190" marker-end="url(#arrow-${id})"/>
        ${dimH(id, 45, 515, 225, `${t("barrel length", "duljina cijevi")} ${fieldValue(p, "barrelLength", t)}`)}
        <circle class="parts-endview-outer" cx="428" cy="61" r="40"/><circle class="parts-endview-bore" cx="428" cy="61" r="27"/><circle class="parts-bb" cx="428" cy="61" r="${clamp(number(p.bbDiameter) / Math.max(number(p.barrelDiameter), .1) * 24, 15, 23.5)}"/>
        <g class="parts-leader"><path d="M428 34L470 17"/><text x="474" y="20">${esc(`Ø ${fieldValue(p, "barrelDiameter", t)}`)}</text><path d="M428 61L472 77"/><text x="476" y="82">${esc(`BB Ø ${fieldValue(p, "bbDiameter", t)}`)}</text></g>
        <text class="parts-part-label" x="87" y="${center + 5}" text-anchor="middle">BB</text>
      </svg><p class="parts-scale-note">${t("Entered radial clearance", "Uneseni radijalni zazor")}: <strong>${radial.toFixed(3)} mm</strong> · ${t("diametral difference", "razlika promjera")}: <strong>${Math.max(0, p.barrelDiameter - p.bbDiameter).toFixed(3)} mm</strong>. ${t("This is geometry, not a measured leakage rate.", "To je geometrija, ne izmjerena stopa curenja.")}</p></div>`;
  }

  function silencerSvg(p, t) {
    const id = "silencer", center = 137, left = 46, right = 514;
    const geometry = P.silencerGeometry(p);
    const chamberHalf = 47;
    const coreHalf = clamp(p.silencerBaffleBore / Math.max(p.silencerInnerDiameter, .1) * chamberHalf, 7, 30);
    const outletHalf = clamp(p.silencerEndCapBore / Math.max(p.silencerInnerDiameter, .1) * chamberHalf, 7, 30);
    const count = Math.min(12, Math.max(0, Math.round(p.silencerBaffleCount)));
    const baffles = Array.from({ length: count }, (_, index) => {
      const x = left + (index + 1) / (count + 1) * (right - left - 12);
      const width = clamp(p.silencerBaffleThickness / Math.max(p.silencerLength, 1) * (right - left), 2, 9);
      return `<path class="parts-silencer-baffle" d="M${x - width / 2} ${center - chamberHalf}H${x + width / 2}V${center - coreHalf}H${x - width / 2}ZM${x - width / 2} ${center + coreHalf}H${x + width / 2}V${center + chamberHalf}H${x - width / 2}Z"/>`;
    }).join("");
    const packing = p.silencerPackingFraction > 0 ? `<g class="parts-silencer-packing">${Array.from({ length: 28 }, (_, index) => {
      const x = left + 8 + index * (right - left - 26) / 27;
      return `<path d="M${x} ${center - chamberHalf + 6}l6 10M${x} ${center + chamberHalf - 6}l6 -10"/>`;
    }).join("")}</g>` : "";
    const state = p.silencerEnabled ? t("installed in shot model", "ugrađen u modelu hica") : t("stored geometry · inactive", "spremljena geometrija · neaktivno");
    return `<div class="parts-figure"><div class="parts-figure-heading"><div><h3>${t("Silencer expansion chamber", "Ekspanzijska komora prigušivača")}</h3><p>${t("Sectioned schematic locates every requested internal measurement; baffle profile is representative, not manufacturing CAD.", "Presjek označuje svaku traženu unutarnju mjeru; oblik pregrada je reprezentativan, nije proizvodni CAD.")}</p></div><span class="tag ${p.silencerEnabled ? "measured" : "unknown"}">${state}</span></div>
      <svg class="parts-svg" viewBox="0 0 560 285" role="img" aria-label="${esc(t("Silencer cutaway with internal length, chamber diameter, baffle bore, end-cap bore and packing", "Presjek prigušivača s unutarnjom duljinom, promjerom komore, provrtom pregrada, provrtom završne kape i ispunom"))}">${defs(id)}
        <line class="parts-centerline" x1="28" y1="${center}" x2="535" y2="${center}"/>
        <path class="parts-silencer-shell" d="M${left - 8} ${center - chamberHalf - 12}H${right + 7}V${center - chamberHalf}H${left}V${center + chamberHalf}H${right + 7}V${center + chamberHalf + 12}H${left - 8}Z"/>
        <rect class="parts-silencer-chamber" x="${left}" y="${center - chamberHalf}" width="${right - left}" height="${2 * chamberHalf}"/>
        ${packing}${baffles}
        <path class="parts-silencer-endcap" d="M${right - 5} ${center - chamberHalf}H${right + 7}V${center - outletHalf}H${right - 5}ZM${right - 5} ${center + outletHalf}H${right + 7}V${center + chamberHalf}H${right - 5}Z"/>
        <path class="parts-motion" d="M58 ${center}H132" marker-end="url(#arrow-${id})"/><circle class="parts-bb" cx="74" cy="${center}" r="7"/><text class="parts-part-label" x="74" y="${center + 4}" text-anchor="middle">BB</text>
        ${dimH(id, left, right, 247, `${t("internal expansion length", "unutarnja ekspanzijska duljina")} ${fieldValue(p, "silencerLength", t)}`)}
        ${dimV(id, 27, center - chamberHalf, center + chamberHalf, `Ø ${fieldValue(p, "silencerInnerDiameter", t)}`)}
        <g class="parts-leader"><path d="M${left + (right - left) * .55} ${center - coreHalf}L355 48"/><text x="360" y="46">${esc(`${t("baffle bore", "provrt pregrade")} Ø ${fieldValue(p, "silencerBaffleBore", t)}`)}</text><path d="M${right} ${center + outletHalf}L455 218"/><text x="450" y="232" text-anchor="end">${esc(`${t("end cap", "završna kapa")} Ø ${fieldValue(p, "silencerEndCapBore", t)}`)}</text></g>
        <text class="parts-caption" x="280" y="78" text-anchor="middle">${esc(`${p.silencerBaffleCount} × ${fieldValue(p, "silencerBaffleThickness", t)} · ${t("fill", "ispuna")} ${(p.silencerPackingFraction * 100).toFixed(1)}%`)}</text>
      </svg><p class="parts-scale-note">${t("Calculated free gas volume", "Izračunati slobodni volumen plina")}: <strong>${(geometry.freeVolume * 1e6).toFixed(2)} cm³</strong> · ${t("gross / baffle solid / packing solid", "bruto / pregrade / puna ispuna")}: <strong>${(geometry.grossVolume * 1e6).toFixed(2)} / ${(geometry.baffleSolidVolume * 1e6).toFixed(2)} / ${(geometry.packingSolidVolume * 1e6).toFixed(2)} cm³</strong> · ${t("conditional equivalent outlet", "uvjetni ekvivalentni izlaz")}: <strong>${(geometry.effectiveOutletArea * 1e6).toFixed(2)} mm²</strong>. ${t("The drawing does not certify BB-strike clearance or predict dB.", "Crtež ne potvrđuje sigurnost zazora od udara BB-a niti predviđa dB.")}</p></div>`;
  }

  function springPath(x1, x2, center, amplitude, turns) {
    const count = Math.max(5, Math.min(18, Math.round(turns || 11))), step = (x2 - x1) / count;
    let path = `M${x1} ${center}`;
    for (let index = 0; index < count; index++) {
      const x = x1 + index * step;
      path += `C${x + step * .22} ${center - amplitude},${x + step * .28} ${center - amplitude},${x + step * .5} ${center}C${x + step * .72} ${center + amplitude},${x + step * .78} ${center + amplitude},${x + step} ${center}`;
    }
    return path;
  }

  function springSvg(p, t) {
    const id = "spring", spring = P.springState(p), lengthMode = p.springLengthMode === 1;
    const coils = p.springActiveCoils > 0 ? p.springActiveCoils - p.springRemovedCoils : 11;
    const activeText = lengthMode ? t("Length mode active", "Aktivan način s duljinama") : t("Direct compression mode", "Izravni način stlačenja");
    const currentFree = spring.freeLength === null ? null : spring.freeLength;
    return `<div class="parts-figure"><div class="parts-figure-heading"><div><h3>${t("Spring, seats & cut reference", "Opruga, oslonci i referenca reza")}</h3><p>${esc(activeText)}. ${t("The drawing identifies reference lengths; coil geometry itself is not modeled.", "Crtež označuje referentne duljine; sama geometrija zavoja nije modelirana.")}</p></div></div>
      <svg class="parts-svg" viewBox="0 0 560 285" role="img" aria-label="${esc(t("Spring between rear and front seats with current free length, compression and cut values", "Opruga između stražnjeg i prednjeg oslonca s trenutačnom slobodnom duljinom, stlačenjem i vrijednostima reza"))}">${defs(id)}
        <line class="parts-spring-seat" x1="42" y1="57" x2="42" y2="210"/><line class="parts-spring-seat" x1="515" y1="57" x2="515" y2="210"/>
        <path class="parts-spring" d="${springPath(52, 505, 133, 42, coils)}"/><line class="parts-centerline" x1="30" y1="133" x2="527" y2="133"/>
        <text class="parts-caption" x="42" y="43" text-anchor="middle">${esc(t("rear seat", "stražnji oslonac"))}</text><text class="parts-caption" x="515" y="43" text-anchor="middle">${esc(t("front seat", "prednji oslonac"))}</text>
        ${dimH(id, 42, 515, 236, lengthMode ? `${t("entered seat distance", "uneseni razmak oslonaca")} ${fieldValue(p, "springInstalledLength", t)}` : `${t("front compression", "prednje stlačenje")} ${spring.preload.toFixed(1)} mm`)}
        ${p.springCutLength > 0 ? `<g class="parts-cut"><line x1="430" y1="76" x2="430" y2="190"/><text x="422" y="69" text-anchor="end">${esc(`${t("simulated cut", "simulirani rez")} ${fieldValue(p, "springCutLength", t)}`)}</text></g>` : ""}
        <text class="parts-part-label" x="278" y="138" text-anchor="middle">${esc(`${spring.stiffness.toFixed(1)} N/m`)}</text>
      </svg><p class="parts-scale-note">${lengthMode ? `${t("Resulting free length", "Dobivena slobodna duljina")}: <strong>${currentFree === null ? "—" : currentFree.toFixed(1) + " mm"}</strong> · ${t("contact / cocked compression", "stlačenje pri kontaktu / zapeto")}: <strong>${spring.preload.toFixed(1)} / ${spring.cockedCompression.toFixed(1)} mm</strong>.` : `${t("Length fields are inactive; the model uses the entered direct compression", "Polja duljina nisu aktivna; model koristi uneseno izravno stlačenje")}: <strong>${fieldValue(p, "springPreload", t)}</strong>.`} ${t("Do not infer force from the drawing; use a measured force curve when available.", "Ne izvodite silu iz crteža; koristite izmjerenu krivulju sile kada je dostupna.")}</p></div>`;
  }

  function measurementGroup(group, p, t) {
    return `<section class="parts-measure-group"><div class="parts-measure-heading"><h3>${label(group.title, t)}</h3><p>${label(group.note, t)}</p></div><div class="parts-measure-list">${group.rows.map(([key, names, method, help]) => `<article class="parts-measurement" data-field="${key}"><div class="parts-measure-name"><strong>${label(names, t)}</strong><output>${esc(fieldValue(p, key, t))}</output></div><span class="parts-method">${label(method, t)}</span><p>${label(help, t)}</p></article>`).join("")}</div></section>`;
  }

  function modelRows(p, t) {
    return MODEL_ROWS.map(([key, names, method]) => `<tr data-field="${key}"><th scope="row">${label(names, t)}</th><td class="mono">${esc(fieldValue(p, key, t))}</td><td>${label(method, t)}</td></tr>`).join("");
  }

  function markup(raw, t = (en => en)) {
    const p = P.normalize(raw);
    return `<section class="panel parts-atlas" aria-labelledby="partsAtlasTitle">
      <div class="parts-atlas-heading"><div><span class="parts-eyebrow">${t("Dynamic measurement atlas", "Dinamički mjerni atlas")}</span><h2 id="partsAtlasTitle">${t("Parts & measurement references", "Dijelovi i reference mjerenja")}</h2><p>${t("Every number and diagram below follows the current setup. Use the drawings to identify the intended feature, then record the real measurement—not a value estimated from the illustration.", "Svaki broj i dijagram u nastavku prati trenutačnu konfiguraciju. Crtež koristite za prepoznavanje tražene značajke, a zatim zabilježite stvarno mjerenje — ne vrijednost procijenjenu sa slike.")}</p></div><span class="tag geometry">${t("current setup", "trenutačna konfiguracija")}</span></div>
      <div class="parts-safety" role="note"><strong>${t("Before measuring", "Prije mjerenja")}</strong><span>${t("Unload and fully decock the replica. Remove spring load and disassemble according to the manufacturer before placing tools inside the cylinder or spring assembly.", "Ispraznite i potpuno otpustite repliku. Uklonite opterećenje opruge i rastavite prema uputama proizvođača prije stavljanja alata u cilindar ili sklop opruge.")}</span></div>
      <div class="parts-diagrams">${airPathSvg(p, t)}<div class="parts-figure-grid">${cylinderSvg(p, t)}${barrelSvg(p, t)}${silencerSvg(p, t)}${springSvg(p, t)}</div></div>
      <div class="parts-measurement-intro"><h2>${t("What each setup value means", "Što znači svaka vrijednost konfiguracije")}</h2><p>${t("The method labels distinguish dimensions you can measure directly from quantities that need a fixture, calculation or calibration.", "Oznake metoda razlikuju dimenzije koje možete izravno izmjeriti od veličina koje traže prihvat, izračun ili kalibraciju.")}</p></div>
      <div class="parts-measure-groups">${GROUPS.map(group => measurementGroup(group, p, t)).join("")}</div>
      <details class="parts-model-parameters" data-preserve-open><summary>${t("Model, bench-test and environmental inputs — not ordinary part dimensions", "Ulazi modela, ispitivanja i okoliša — nisu obične dimenzije dijelova")}</summary><p>${t("These inputs still affect the simulation, but a caliper cannot establish them. Treat unmeasured values as assumptions and use the stated evidence route or chrono calibration where applicable.", "Ovi ulazi i dalje utječu na simulaciju, ali ih pomično mjerilo ne može odrediti. Neizmjerene vrijednosti tretirajte kao pretpostavke i koristite navedeni način provjere ili chrono kalibraciju gdje je primjenjivo.")}</p><div class="table-wrap"><table class="parts-parameter-table"><thead><tr><th>${t("Parameter", "Parametar")}</th><th>${t("Current input", "Trenutačni ulaz")}</th><th>${t("How to establish it", "Kako ga odrediti")}</th></tr></thead><tbody>${modelRows(p, t)}</tbody></table></div></details>
      <p class="parts-cavity-note">${t("For dead and breech volumes, prefer dimensions from a disassembled dry component or a safe bench displacement method. Do not introduce liquid into an assembled replica, cylinder, hop unit or barrel.", "Za preostali volumen i volumen komore prednost dajte dimenzijama rastavljene suhe komponente ili sigurnoj metodi istiskivanja na stolu. Ne unosite tekućinu u sastavljenu repliku, cilindar, hop jedinicu ili cijev.")}</p>
    </section>`;
  }

  const api = { markup, fieldValue, help, PART_FIELDS, MODEL_FIELDS: MODEL_ROWS.map(row => row[0]), HELP_FIELDS: Object.keys(FIELD_HELP) };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.PneumaticParts = api;
})(typeof globalThis !== "undefined" ? globalThis : this);


/* Presentation only. Geometry and timing come from the solver/playback modules.
   Light, particles and trails are schematic cues, not a fluid/acoustic solution. */
(function (root) {
  "use strict";
  const B = typeof module !== "undefined" && module.exports ? require("./playback.js") : root.PneumaticPlayback;
  const clamp = (v, low = 0, high = 1) => Math.max(low, Math.min(high, v));
  function draw(ctx, w, h, p, shot, f, t, fmt) {
    const { wall, head, rigidHead, bumperWidth, face, step, passageEnd, barrelStart, end, silencerEnd, barrelScale, pinLength, scale } = B.mechanism(p, f.pistonX);
    const axis = 156, top = 100, bottom = 212;
    const bb = f.bbExited ? end + (f.t - shot.exitTime) * shot.exitVelocity * 1000 * barrelScale : barrelStart + f.bbX / shot.barrelLength * (end - barrelStart);
    const radial = 26 / Math.max(p.bumperBore, p.headBore, p.nozzleBore, p.airbrakeDiameter);
    const peak = Math.max(1, shot.peakCylinderPressure - shot.ambientPressure, shot.peakPressure - shot.ambientPressure, shot.peakFrontPressure - shot.ambientPressure, (shot.peakSilencerPressure || shot.ambientPressure) - shot.ambientPressure);
    const cylinderGlow = clamp((f.cylinderPressure - shot.ambientPressure) / peak);
    const barrelGlow = clamp((f.pressure - shot.ambientPressure) / peak);
    const frontGlow = clamp((f.frontPressure - shot.ambientPressure) / peak);
    const silencerGlow = clamp(((f.silencerPressure || shot.ambientPressure) - shot.ambientPressure) / peak);
    const amber = "#ffbf69", cyan = "#5de4e7", violet = "#b99cff", green = "#6ee7a8";
    const gradient = (x1, y1, x2, y2, stops) => {
      const g = ctx.createLinearGradient(x1, y1, x2, y2);
      stops.forEach(([at, color]) => g.addColorStop(at, color)); return g;
    };
    const rect = (x, y, width, height, fill, stroke) => {
      ctx.fillStyle = fill; ctx.fillRect(x, y, Math.max(0, width), height);
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.strokeRect(x, y, Math.max(0, width), height); }
    };
    const line = (x1, y1, x2, y2, color, width = 1) => {
      ctx.strokeStyle = color; ctx.lineWidth = width; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    };
    const dot = (x, y, radius, color) => { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2); ctx.fill(); };
    const clip = (x, y, width, height, body) => {
      if (width <= 0) return;
      ctx.save(); ctx.beginPath(); ctx.rect(x, y, width, height); ctx.clip(); body(); ctx.restore();
    };
    const arrow = (x, y, delta, color) => {
      if (Math.abs(delta) < 1) return;
      line(x, y, x + delta, y, color, 2);
      line(x + delta, y, x + delta - Math.sign(delta) * 7, y - 4, color, 2);
      line(x + delta, y, x + delta - Math.sign(delta) * 7, y + 4, color, 2);
    };
    // Symbols compress with their gas region. Drift indicates signed flow only;
    // it is intentionally not a particle-speed or density measurement.
    const gas = (x, y, width, height, level, color, count, flow) => {
      clip(x, y, width, height, () => {
        rect(x, y, width, height, gradient(0, y, 0, y + height, [[0, `${color}12`], [.5, `${color}${Math.round(22 + level * 82).toString(16).padStart(2, "0")}`], [1, `${color}12`]]));
        for (let i = 0; i < count; i++) {
          const phase = ((i * .61803398875 + f.t * 90 * Math.sign(flow)) % 1 + 1) % 1;
          const px = x + phase * width, py = y + 5 + ((i * .41421356237) % 1) * Math.max(1, height - 10);
          ctx.globalAlpha = .2 + level * .6;
          if (Math.abs(flow) > 1e-8) line(px - Math.sign(flow) * (2 + level * 5), py, px, py, color, 1.4);
          else dot(px, py, 1.2, color);
        }
      });
    };
    ctx.save(); ctx.scale(w / 1100, h / 330);
    ctx.lineCap = "round"; ctx.lineJoin = "round";
    // Subtle drafting grid and centerline give the cutaway a stable reference.
    for (let x = 20; x < 1100; x += 30) line(x, 62, x, 227, "rgba(154,187,204,.035)");
    ctx.setLineDash([3, 6]); line(30, axis, 1080, axis, "#36505b"); ctx.setLineDash([]);
    const steel = gradient(0, top, 0, bottom, [[0, "#80949f"], [.07, "#384955"], [.45, "#18272f"], [.9, "#455b67"], [1, "#9eafb4"]]);
    rect(wall - 6, top - 5, rigidHead - wall + 12, bottom - top + 10, steel, "#597480");
    rect(wall, top + 5, head - wall, bottom - top - 10, "#0b141c", "#202f39");
    line(wall, top - 2, rigidHead, top - 2, "#afccd266");
    rect(wall - 9, top + 10, 12, 92, "#516670", "#8ba0aa");
    gas(face, top + 6, head - face, 100, cylinderGlow, amber, 34, f.flow);
    // Spring's dark/back and illuminated/front halves share the actual endpoints.
    const springLeft = wall + 9, springRight = face - 32, pitch = Math.max(1, springRight - springLeft) / 13;
    line(springLeft, axis, springRight, axis, "#73848d", 4);
    for (let pass = 0; pass < 2; pass++) {
      ctx.strokeStyle = pass ? gradient(0, axis - 25, 0, axis + 25, [[0, "#ffe1a8"], [.35, amber], [1, "#96612f"]]) : "#604932";
      ctx.lineWidth = pass ? 3.3 : 3.8;
      ctx.beginPath();
      for (let i = 0; i < 13; i++) {
        const x = springLeft + pitch * i;
        ctx.moveTo(x, axis + (pass ? 23 : -23));
        ctx.bezierCurveTo(x + pitch * .35, axis + (pass ? 28 : -28), x + pitch * .65, axis + (pass ? -28 : 28), x + pitch, axis + (pass ? -23 : 23));
      }
      ctx.stroke();
    }
    // Machined piston body, guide rod and seal. Front face stays at solver x.
    const pistonMetal = gradient(face - 30, top, face, bottom, [[0, "#c3d6df"], [.25, "#5d7583"], [.48, "#d6e5e9"], [.72, "#657c89"], [1, "#30444f"]]);
    rect(face - 32, top + 7, 32, 98, pistonMetal, "#bbd0d8");
    rect(face - 7, top + 6, 5, 100, "#182e31", "#78c6bd");
    for (let i = 0; i < 3; i++) line(face - 26 + i * 5, top + 16, face - 26 + i * 5, bottom - 16, "#142a394d");
    // The bumper, rigid head and nozzle are three distinct axial passages.
    rect(rigidHead, axis - 35, passageEnd - rigidHead, 70, gradient(0, axis - 35, 0, axis + 35, [[0, "#abbbc3"], [.1, "#526675"], [.55, "#273d49"], [1, "#758d9a"]]), "#8199a5");
    for (let x = rigidHead + 5; x < passageEnd; x += 7) line(x, axis - 34, x, axis - 26, "#a9bbc544");
    if (bumperWidth > 0) {
      const compression = Math.max(0, f.bumperCompression || 0) * 1000 * scale;
      const padFace = Math.min(rigidHead, head + compression), padWidth = Math.max(0, rigidHead - padFace);
      const limit = Math.max(.001, Math.min(p.bumperThickness, p.bumperMaxCompression));
      const compressionShare = clamp((f.bumperCompression || 0) * 1000 / limit);
      const hole = p.bumperBore * radial, touching = compressionShare > 1e-5;
      const bulge = touching ? Math.min(8, 1 + compressionShare * 7) : 0;
      const rubber = gradient(padFace, 0, rigidHead, 0, [[0, touching ? "#7ff4ce" : "#42bca0"], [.48, "#173f3b"], [1, "#0d2828"]]);
      rect(padFace, top + 5 - bulge, padWidth, axis - hole / 2 - (top + 5) + bulge, rubber, "#72d7c3");
      rect(padFace, axis + hole / 2, padWidth, bottom - 5 - (axis + hole / 2) + bulge, rubber, "#72d7c3");
      if (touching) {
        line(padFace + Math.min(padWidth * .35, 3), top + 9, padFace + Math.min(padWidth * .35, 3), axis - hole / 2 - 3, "#c7fff0", 2);
        line(padFace + Math.min(padWidth * .35, 3), axis + hole / 2 + 3, padFace + Math.min(padWidth * .35, 3), bottom - 9, "#c7fff0", 2);
      }
    }
    for (const [x, width, height] of [[head, rigidHead - head, p.bumperBore * radial], [rigidHead, step - rigidHead, p.headBore * radial], [step, passageEnd - step, p.nozzleBore * radial]]) {
      rect(x, axis - height / 2, width, height, "#081119", "#738b97");
      gas(x, axis - height / 2, width, height, barrelGlow, cyan, 8, f.flow);
    }
    // The pneumatic cushion is pressure, not contact or an artificial rebound.
    if (f.insertion > 0 && f.cylinderPressure > f.pressure) {
      clip(face, top + 6, head - face, 100, () => {
        const glow = ctx.createRadialGradient(head, axis, 1, head, axis, 60);
        glow.addColorStop(0, `rgba(255,190,89,${clamp((f.cylinderPressure - f.pressure) / peak) * .85})`); glow.addColorStop(1, "rgba(255,190,89,0)");
        rect(head - 60, axis - 55, 60, 110, glow);
        for (const y of [axis - 32, axis + 32]) arrow(head - 3, y, -Math.min(28, (head - face) * .65), amber);
      });
    }
    if (p.airbrakeLength > 0) {
      const thickness = p.airbrakeDiameter * radial, tip = Math.min(pinLength, p.airbrakeTaper * scale), tipHalf = p.airbrakeTipDiameter * radial / 2;
      ctx.fillStyle = gradient(0, axis - thickness / 2, 0, axis + thickness / 2, [[0, "#eff8fb"], [.4, "#a9c0cb"], [1, "#516a77"]]);
      ctx.strokeStyle = "#d3e4e9"; ctx.lineWidth = .7;
      ctx.beginPath(); ctx.moveTo(face, axis - thickness / 2); ctx.lineTo(face + pinLength - tip, axis - thickness / 2); ctx.lineTo(face + pinLength, axis - tipHalf); ctx.lineTo(face + pinLength, axis + tipHalf); ctx.lineTo(face + pinLength - tip, axis + thickness / 2); ctx.lineTo(face, axis + thickness / 2); ctx.closePath(); ctx.fill(); ctx.stroke();
    }
    // Barrel cutaway and breech connector; BB never jumps or is held at the muzzle.
    ctx.setLineDash([3, 3]); ctx.strokeStyle = "#7a949e"; ctx.strokeRect(passageEnd, axis - 13, barrelStart - passageEnd, 26); ctx.setLineDash([]);
    rect(barrelStart, axis - 22, end - barrelStart, 44, gradient(0, axis - 22, 0, axis + 22, [[0, "#a08c69"], [.12, "#544d40"], [.5, "#182830"], [1, "#a69067"]]), "#998667");
    rect(barrelStart, axis - 13, end - barrelStart, 26, "#09141c", "#526a72");
    gas(barrelStart, axis - 12, Math.max(0, Math.min(bb, end) - barrelStart), 24, barrelGlow, cyan, 30, f.flow);
    if (!f.bbExited) gas(Math.max(barrelStart, bb), axis - 12, Math.max(0, end - Math.max(barrelStart, bb)), 24, frontGlow, violet, 24, f.frontOutflow);
    line(end, axis - 23, end, axis + 23, "#c8d9dd", 3);
    if (p.silencerEnabled) {
      const chamberTop = axis - 37, chamberBottom = axis + 37;
      const boreHeight = clamp(p.silencerBaffleBore / Math.max(p.silencerInnerDiameter, .1) * 68, 9, 30);
      const endBoreHeight = clamp(p.silencerEndCapBore / Math.max(p.silencerInnerDiameter, .1) * 68, 9, 30);
      rect(end - 5, chamberTop - 7, silencerEnd - end + 7, chamberBottom - chamberTop + 14,
        gradient(0, chamberTop, 0, chamberBottom, [[0, "#71848d"], [.1, "#293b44"], [.48, "#0e191e"], [.9, "#334951"], [1, "#83959c"]]), "#70868e");
      rect(end, chamberTop, silencerEnd - end, chamberBottom - chamberTop, "#071510", "#527066");
      gas(end, chamberTop + 1, silencerEnd - end - 2, chamberBottom - chamberTop - 2, silencerGlow, green, 28, f.silencerOutflow);
      const visibleBaffles = Math.min(12, Math.max(0, Math.round(p.silencerBaffleCount)));
      for (let index = 0; index < visibleBaffles; index++) {
        const x = end + (index + 1) / (visibleBaffles + 1) * (silencerEnd - end);
        const thickness = clamp(p.silencerBaffleThickness * barrelScale, 1.5, 5);
        rect(x - thickness / 2, chamberTop, thickness, (chamberBottom - chamberTop - boreHeight) / 2, "#617780", "#9fb1b5");
        rect(x - thickness / 2, axis + boreHeight / 2, thickness, (chamberBottom - chamberTop - boreHeight) / 2, "#617780", "#9fb1b5");
      }
      rect(silencerEnd - 4, chamberTop - 1, 5, (chamberBottom - chamberTop - endBoreHeight) / 2 + 1, "#84979d", "#bed0d3");
      rect(silencerEnd - 4, axis + endBoreHeight / 2, 5, (chamberBottom - chamberTop - endBoreHeight) / 2 + 1, "#84979d", "#bed0d3");
      if (p.silencerPackingFraction > 0) {
        ctx.save(); ctx.globalAlpha = clamp(.12 + p.silencerPackingFraction * .45, .12, .5);
        for (let x = end + 8; x < silencerEnd - 6; x += 9) {
          line(x, chamberTop + 4, x + 5, chamberTop + 13, "#9bf4c0", 1);
          line(x, chamberBottom - 4, x + 5, chamberBottom - 13, "#9bf4c0", 1);
        }
        ctx.restore();
      }
    }
    const plume = f.bbExited ? clamp(f.outflow / Math.max(shot.peakOutflow, 1e-10)) : 0;
    if (plume > .001) {
      ctx.save(); ctx.globalAlpha = plume;
      for (let i = 0; i < 5; i++) {
        const radius = 9 + i * 4, x = silencerEnd + 6 + i * 10;
        const glow = ctx.createRadialGradient(x, axis, 1, x, axis, radius);
        glow.addColorStop(0, "#5de4e73d"); glow.addColorStop(1, "#5de4e700");
        dot(x, axis, radius, glow);
      }
      for (let i = 0; i < 15; i++) {
        const progress = ((f.t - shot.exitTime) * 220 + i / 15) % 1;
        const x = silencerEnd + 4 + progress * 54, y = axis + (i % 5 - 2) * (2 + progress * 7);
        line(x - 3, y, x, y, "#a0fbf3", 1);
      }
      ctx.restore();
    }
    if (bb >= barrelStart && bb < 1110) {
      const direction = Math.sign(f.bbV), trail = Math.max(0, Math.min(70, Math.abs(f.bbV) * .5, direction < 0 ? silencerEnd - bb : bb - barrelStart));
      const tail = bb - direction * trail;
      if (trail > 0) rect(Math.min(tail, bb), axis - 3, trail, 6, gradient(tail, 0, bb, 0, [[0, "#5de4e700"], [1, "#b8ffffbb"]]));
      const sphere = ctx.createRadialGradient(bb - 2, axis - 3, 1, bb, axis, 8);
      sphere.addColorStop(0, "#ffffff"); sphere.addColorStop(.55, "#e1f4f1"); sphere.addColorStop(1, "#68878d");
      ctx.save(); ctx.shadowColor = cyan; ctx.shadowBlur = Math.min(12, Math.abs(f.bbV) * .12); dot(bb, axis, 8, sphere); ctx.restore();
    }
    arrow(face - 22, 80, Math.sign(f.pistonV) * Math.min(60, Math.abs(f.pistonV) * 10), amber);
    if (bb < 1080) arrow(bb, 117, Math.sign(f.bbV) * Math.min(50, Math.abs(f.bbV)), cyan);
    arrow(head + (passageEnd - head) * .25, 232, Math.sign(f.flow) * Math.min(55, Math.abs(f.flow) * 25000), cyan);
    // Labels remain outside the moving machinery. Readouts below stay accessible.
    ctx.font = `${Math.max(14, 12 * 1100 / w)}px system-ui`; ctx.fillStyle = "#bdced6";
    if (w >= 650) {
      ctx.fillText(t("SPRING / PISTON", "OPRUGA / PISTON"), 40, 36);
      ctx.fillText(p.bumperThickness > 0 ? t("BUMPER / HEAD / NOZZLE", "ODBOJNIK / GLAVA / MLAZNICA") : t("HEAD / NOZZLE", "GLAVA / MLAZNICA"), 425, 36);
      ctx.fillText(p.silencerEnabled ? t("INNER BARREL / SILENCER", "UNUTARNJA CIJEV / PRIGUŠIVAČ") : t("INNER BARREL", "UNUTARNJA CIJEV"), 760, 36);
      ctx.fillStyle = amber; ctx.fillText(`${t("Cylinder", "Cilindar")}  ${fmt((f.cylinderPressure - shot.ambientPressure) / 1e5, 2)} bar(g)`, 40, 266);
      ctx.fillStyle = cyan; ctx.fillText(`${t("Behind / ahead BB", "Iza / ispred BB-a")}  ${fmt((f.pressure - shot.ambientPressure) / 1e5, 2)} / ${fmt((f.frontPressure - shot.ambientPressure) / 1e5, 2)} bar(g)`, 620, 266);
      rect(40, 279, 270, 3, "#2c363b"); rect(40, 279, cylinderGlow * 270, 3, amber);
      rect(620, 279, 390, 3, "#2c363b"); rect(620, 279, barrelGlow * 390, 3, cyan); rect(620, 284, frontGlow * 390, 2, violet);
      ctx.fillStyle = "#99aeb9";
      const silencerReadout = p.silencerEnabled ? `  ·  ${t("Silencer", "Prigušivač")} ${fmt((f.silencerPressure - shot.ambientPressure) / 1e5, 2)} bar(g)` : "";
      ctx.fillText(`${t("Pin overlap", "Preklapanje pina")} ${fmt(f.insertion * 1000, 2)} mm  ·  ${t("Open area", "Otvor")} ${fmt(f.openArea * 1e6, 3)} mm²${silencerReadout}`, 40, 311);
    } else {
      ctx.fillText(p.bumperThickness > 0 ? t("PISTON → BUMPER → BB", "PISTON → GUMICA → BB") : t("PISTON → HEAD → BB", "PISTON → GLAVA → BB"), 40, 36);
      ctx.fillText(`${t("Pin overlap", "Preklapanje pina")}: ${fmt(f.insertion * 1000, 2)} mm`, 40, 266);
      ctx.fillText(`${t("Open area", "Otvor")}: ${fmt(f.openArea * 1e6, 3)} mm²`, 40, 308);
    }
    ctx.restore();
  }
  const api = { draw };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.PneumaticAnimation = api;
})(typeof globalThis !== "undefined" ? globalThis : this);


/* UI shared by the generated standalone file and Cloudflare build. */
(() => {
  "use strict";
  const P = globalThis.PneumaticPhysics, C = globalThis.PneumaticCalibration, O = globalThis.PneumaticOptimizer, B = globalThis.PneumaticPlayback;
  const I = globalThis.PneumaticInsights, Parts = globalThis.PneumaticParts;
  const $ = id => document.getElementById(id), finite = Number.isFinite;
  const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  let language = "en";
  try { language = localStorage.getItem("ssg10-pneumatic-lab-language") === "hr" ? "hr" : "en"; } catch (_) { /* local files may disallow storage */ }
  const t = (en, hr) => language === "hr" ? hr : en;
  const fmt = (v, digits = 2, unit = "") => finite(v) ? `${v.toFixed(digits)}${unit ? " " + unit : ""}` : "—";
  const fps = v => v === null ? null : v / .3048;
  const stamp = v => fmt(v === null ? null : v * 1000, 2, "ms");
  const clone = v => JSON.parse(JSON.stringify(v));
  const parseCurveText = value => value.trim() ? value.trim().split(/\n+/).map(line => line.trim().split(/[,;\s]+/).map(Number)) : [];
  let p = P.normalize(), selectedPlatform = "ssg10", component = "amp", springLabel = "unspecified", pinLabel = "plug";
  let provenance = { geometry: "assumed", spring: "assumed" }, shot = null, baseline = null, unsilencedReference = null, fraction = 0, playing = false, animation = 0;
  let measurements = [], fit = null, fitSelection = ["dischargeCoefficient"], status = null, diagnostic = null, busy = false, debounce = null;
  let lastValidShot = null, changeComparison = null;
  let optimizer = null;
  let playbackUniform = false, playbackSpeed = 1, calculationPending = false, playheadTime = 0;
  const chartCache = new Map();
  const workspaceState = { category: "geometry", view: "shot", categoryScroll: {}, viewScroll: {} };
  let workspace = null;
  const fields = {
    cylinderBore: ["Cylinder internal diameter", "Unutarnji promjer cilindra", "mm", 15, 35, .01],
    strokeLength: ["Nominal piston stroke before added bumper", "Nominalni hod pistona prije dodatne gumice", "mm", 20, 150, .1],
    barrelLength: ["Inner-barrel length", "Duljina unutarnje cijevi", "mm", 100, 800, 1],
    barrelDiameter: ["Inner-barrel diameter", "Promjer unutarnje cijevi", "mm", 5.8, 6.5, .01],
    pistonMass: ["Assembled piston mass", "Masa sastavljenog pistona", "g", 5, 300, .1],
    bbMass: ["BB mass", "Masa BB-a", "g", .1, 1, .01],
    bbDiameter: ["Actual BB diameter", "Stvarni promjer BB-a", "mm", 5.5, 6.4, .01],
    headBore: ["Head receiving-bore diameter", "Promjer ulaznog provrta glave", "mm", 1, 10, .01],
    headLength: ["Receiving-passage length", "Duljina ulaznog provrta", "mm", 1, 40, .1],
    nozzleBore: ["Downstream nozzle diameter", "Promjer izlaznog kanala mlaznice", "mm", 1, 10, .01],
    nozzleLength: ["Downstream nozzle length", "Duljina izlaznog kanala mlaznice", "mm", 1, 50, .1],
    bumperThickness: ["Added head-bumper thickness (0 = none)", "Debljina dodatne odbojne gumice (0 = nema)", "mm", 0, 20, .1],
    bumperBore: ["Bumper inner diameter", "Unutarnji promjer odbojne gumice", "mm", .5, 30, .01],
    bumperStiffness: ["Bumper compression stiffness", "Krutost stlačivanja gumice", "N/mm", 0, 5000, 10],
    bumperDamping: ["Bumper viscous damping", "Viskozno prigušenje gumice", "N·s/m", 0, 1000, 5],
    bumperMaxCompression: ["Bumper compression limit (capped by thickness)", "Granica stlačenja gumice (do debljine)", "mm", 0, 10, .05],
    airbrakeLength: ["Pin projection from piston face", "Izbočenje pina od čela pistona", "mm", 0, 40, .1],
    airbrakeDiameter: ["Airbrake maximum / shaft diameter", "Najveći promjer / promjer tijela pina", "mm", .5, 9, .01],
    airbrakeTipDiameter: ["Airbrake tip diameter", "Promjer vrha pina", "mm", 0, 9, .01],
    airbrakeTaper: ["Tapered tip length", "Duljina konusnog vrha", "mm", 0, 10, .1],
    deadVolume: ["Cylinder-side residual cavity", "Preostali volumen na strani cilindra", "cm³", .05, 5, .01],
    breechVolume: ["Head / nozzle / breech storage", "Volumen glave, mlaznice i komore", "cm³", .05, 5, .01],
    frontDeadVolume: ["Muzzle/front-gas residual volume", "Preostali volumen zraka ispred BB-a", "cm³", .001, 2, .001],
    silencerLength: ["Silencer internal expansion length", "Unutarnja ekspanzijska duljina prigušivača", "mm", 20, 500, 1],
    silencerInnerDiameter: ["Silencer internal chamber diameter", "Unutarnji promjer komore prigušivača", "mm", 7, 80, .1],
    silencerBaffleCount: ["Internal baffle count", "Broj unutarnjih pregrada", "", 0, 50, 1],
    silencerBaffleThickness: ["Average baffle thickness", "Prosječna debljina pregrade", "mm", .1, 15, .1],
    silencerBaffleBore: ["Smallest baffle / core bore", "Najmanji provrt pregrade / jezgre", "mm", 5.5, 30, .01],
    silencerEndCapBore: ["Exit end-cap bore", "Promjer izlaznog otvora završne kape", "mm", 5.5, 30, .01],
    silencerPackingFraction: ["Estimated solid fill fraction", "Procijenjeni udio volumena ispune", "", 0, .89, .01],
    silencerDischargeCoefficient: ["Silencer outlet discharge coefficient Cd", "Koeficijent protoka izlaza prigušivača Cd", "", .1, 1, .01],
    silencerHeatTransfer: ["Silencer effective heat conductance", "Efektivna toplinska vodljivost prigušivača", "W/K", 0, 2, .005],
    springStiffness: ["Spring stiffness before any simulated cut", "Krutost opruge prije simuliranog skraćivanja", "N/m", 0, 4000, 10],
    springPreload: ["Spring compression at rigid-head plane before added bumper", "Stlačenje opruge na ravnini krute glave prije dodatne gumice", "mm", 0, 150, .5],
    springMass: ["Installed spring mass (after any cut)", "Masa ugrađene opruge (nakon skraćivanja)", "g", 0, 100, .1],
    springFreeLength: ["Unloaded spring length before simulated cut", "Slobodna duljina opruge prije simuliranog skraćivanja", "mm", 0, 500, .5],
    springInstalledLength: ["Spring-seat distance at rigid-head plane before added bumper", "Razmak oslonaca opruge na ravnini krute glave prije dodatne gumice", "mm", 0, 500, .5],
    springCutLength: ["Free length removed by cutting", "Smanjenje slobodne duljine rezanjem", "mm", 0, 400, .5],
    springActiveCoils: ["Active coils before cutting (0 = unknown)", "Aktivni zavoji prije rezanja (0 = nepoznato)", "turns", 0, 200, .25],
    springRemovedCoils: ["Active coils removed (0 = inactive ends only)", "Uklonjeni aktivni zavoji (0 = samo neaktivni krajevi)", "turns", 0, 200, .25],
    springSolidLength: ["Remaining spring solid height (0 = unknown)", "Duljina skraćene potpuno stisnute opruge (0 = nepoznato)", "mm", 0, 500, .5],
    pistonFriction: ["Piston sliding / static friction", "Klizno / statičko trenje pistona", "N", 0, 20, .1],
    sealFriction: ["Pressure-dependent seal friction factor", "Faktor trenja brtve ovisan o tlaku", "", 0, .2, .001],
    rearDamping: ["Rear vent / mechanical drag coefficient", "Koeficijent stražnjeg / mehaničkog otpora", "N·s/m", 0, 5, .01],
    restitution: ["Rigid / bottom-out restitution", "Koeficijent odskoka krutog graničnika", "", 0, .8, .01],
    dischargeCoefficient: ["Head discharge coefficient Cd", "Koeficijent protoka glave Cd", "", .1, 1, .01],
    muzzleDischargeCoefficient: ["Muzzle discharge coefficient Cd", "Koeficijent protoka na ustima Cd", "", .1, 1, .01],
    pistonLeak: ["Piston-seal effective leak area", "Efektivna površina curenja brtve pistona", "mm²", 0, .5, .001],
    nozzleLeak: ["Nozzle-to-hop effective leak area", "Efektivna površina curenja spoja mlaznice", "mm²", 0, .5, .001],
    bbLeakCoefficient: ["BB clearance leakage coefficient", "Koeficijent curenja oko BB-a", "", 0, 1, .01],
    bbBreakaway: ["Hop / bucking breakaway force", "Sila pokretanja BB-a kroz hop gumicu", "N", 0, 8, .05],
    barrelDrag: ["Moving BB resistance", "Otpor pri gibanju BB-a", "N", 0, 2, .01],
    heatTransfer: ["Heat conductance per gas chamber", "Toplinska vodljivost po plinskoj komori", "W/K", 0, .5, .001],
    ambientPressure: ["Atmospheric absolute pressure", "Apsolutni atmosferski tlak", "kPa", 70, 110, .1],
    airTemperature: ["Air / wall temperature", "Temperatura zraka / stijenke", "°C", -20, 60, 1],
    usefulFraction: ["Useful-energy threshold (convention)", "Prag korisne energije (dogovoreni kriterij)", "", .8, .999, .005],
    decelThreshold: ["Substantial piston-deceleration threshold", "Prag značajnog usporavanja pistona", "m/s²", 100, 10000, 100],
    maxTime: ["Maximum modeled time", "Najdulje vrijeme simulacije", "ms", 10, 250, 5]
  };
  const platforms = {
    ssg10: { name: "SSG10 / AMP", volume: 35.8, stroke: 85, barrel: 430, bore: 6.01, mass: 71 },
    "ssg10-short": { name: "SSG10 −20 mm", volume: 35.8 * 65 / 85, stroke: 65, barrel: 430, bore: 6.01, mass: 71 },
    tac41p: { name: "TAC-41P", volume: 41, stroke: 95, barrel: 510, bore: 6.05, mass: 65 },
    tac41ls: { name: "TAC-41 Lite Sport", volume: 41, stroke: 95, barrel: 330, bore: 6.05, mass: 65 },
    srs16: { name: "SRS A2 16″", volume: 41, stroke: 95, barrel: 420, bore: 6.05, mass: 65 },
    srs22: { name: "SRS A2 22″", volume: 41, stroke: 95, barrel: 578, bore: 6.05, mass: 65 },
    vsr: { name: "VSR-10 Pro / clone", volume: 31.8, stroke: 80, barrel: 430, bore: 6.08, mass: 45 },
    gspec: { name: "VSR-10 G-Spec", volume: 31.8, stroke: 80, barrel: 303, bore: 6.08, mass: 45 },
    l96: { name: "APS2 / L96", volume: 30, stroke: 80, barrel: 490, bore: 6.03, mass: 45 }
  };
  const events = () => [
    ["engageTime", t("Pin enters bumper / head passage", "Ulazak pina u otvor gumice / glave"), ""],
    ["decelTime", t("Piston starts slowing", "Piston počinje usporavati"), ""],
    ["usefulTime", `${I.thresholdPercent(p.usefulFraction)}% ${t("of peak BB energy", "vršne energije BB-a")}`, "useful"],
    ["strongBrakeTime", t("Substantial slowing after entry", "Značajno usporavanje nakon ulaska"), "brake"],
    ["exitTime", t("BB exit", "Izlazak BB-a"), ""],
    ["preContactReversalTime", t("Reversal before contact (model)", "Povrat prije kontakta (model)"), ""],
    ["contactReboundTime", t("Reverse motion after contact", "Povratno gibanje nakon kontakta"), ""],
    ["pistonHitTime", t("First piston contact", "Prvi kontakt pistona"), ""]
  ];
  function setStatus(en, hr) { status = [en, hr]; if ($("fitStatus")) $("fitStatus").textContent = t(en, hr); }
  function save() {
    try { localStorage.setItem(C.KEY, JSON.stringify(C.encode(measurements))); }
    catch (_) { setStatus("Browser storage unavailable. Export your measurements to keep them.", "Pohrana u pregledniku nije dostupna. Izvezite mjerenja kako biste ih sačuvali."); }
  }
  function invalidateFit() { fit = null; if ($("fitReport")) $("fitReport").innerHTML = ""; }
  try {
    const current = localStorage.getItem(C.KEY), old = localStorage.getItem(C.OLD_KEY);
    if (current || old) {
      measurements = C.decode(current || old).measurements;
      if (!current) status = ["Old measurements preserved as unverified references; previous fits were discarded.", "Stara mjerenja sačuvana su kao nepotvrđene reference; prijašnje prilagodbe nisu prenesene."];
      else if (measurements.some(row => row.legacySetup || row.setup && row.solverVersion !== P.VERSION)) status = ["Previous solver snapshots and shot metadata are preserved. Older-version shots are excluded from the current fit; record confirmed measurements with the current spring inputs.", "Konfiguracije i podaci hitaca prijašnjeg rješavača sačuvani su. Hici starije verzije isključeni su iz trenutačne prilagodbe; zabilježite potvrđena mjerenja s trenutačnim ulazima opruge."];
    } else measurements = [C.reference()];
  } catch (_) { measurements = [C.reference()]; status = ["Stored data could not be read. It has not been overwritten.", "Pohranjeni podaci nisu čitljivi. Nisu prebrisani."]; }
  function languageSwitch() { return `<div class="language-switch" role="group" aria-label="${t("Language", "Jezik")}"><button type="button" data-lang="en" aria-pressed="${language === "en"}">English</button><button type="button" data-lang="hr" aria-pressed="${language === "hr"}">Hrvatski</button></div>`; }
  function field(key) {
    const [en, hr, unit, min, max, step] = fields[key];
    const name = t(en, hr), helpId = `field-help-${key}`, help = Parts.help(key, t);
    return `<div class="control"><div class="control-label-row"><label for="${key}"><span>${name}</span><span class="mono">${unit === "turns" ? t("turns", "zavoja") : unit}</span></label><span class="field-info-wrap"><button class="field-info" type="button" data-field-info="${helpId}" aria-label="${esc(t(`Explain ${en}`, `Objasni: ${hr}`))}" aria-describedby="${helpId}"><span aria-hidden="true">i</span></button><span class="field-tooltip" id="${helpId}" role="tooltip">${esc(help)}</span></span></div><div class="field-entry"><input data-range="${key}" aria-label="${name}" type="range" min="${min}" max="${max}" step="${step}" value="${p[key]}"><input id="${key}" data-number="${key}" type="number" min="${min}" max="${max}" step="${step}" value="${p[key]}" required></div></div>`;
  }
  function springMarkup() {
    return `<details id="springDetails" ${p.springLengthMode ? "open" : ""}><summary>${t("Spring length, cutting & mechanical losses", "Duljina i skraćivanje opruge te mehanički gubici")}</summary>
      <label class="provenance"><input id="springLengthMode" type="checkbox" ${p.springLengthMode ? "checked" : ""}>${t("Calculate from spring lengths / simulate cutting", "Računaj iz duljina opruge / simuliraj skraćivanje")}</label>
      <p class="field-help">${t("Off: enter compression directly. On: length measurements replace that input. Zero lengths mean unknown; no SSG10 dimensions are assumed. The entered front seat/preload uses the rigid-head plane before the added bumper. If you measure at an installed pad, add its thickness back to the seat distance; the model then moves contact rearward once.", "Isključeno: izravno unesite stlačenje. Uključeno: zamjenjuju ga izmjerene duljine. Nulte duljine znače nepoznato; dimenzije SSG10 nisu pretpostavljene. Uneseni prednji razmak/prednaprezanje odnosi se na ravninu krute glave prije dodatne gumice. Ako mjerite na ugrađenoj gumici, njezinu debljinu dodajte natrag razmaku oslonaca; model zatim samo jednom pomiče kontakt unatrag.")}</p>
      <div id="springLengthFields" ${p.springLengthMode ? "" : "hidden"}>${["springFreeLength", "springInstalledLength", "springCutLength", "springActiveCoils", "springRemovedCoils", "springSolidLength"].map(field).join("")}
      <p class="field-help">${t("Cut length is the reduction in unloaded axial length, not wire length. Count removed active coils separately; length alone cannot tell us the new stiffness. More active coils removed → higher estimated stiffness, but shorter free length → less installed compression. Actual output can go down despite higher stiffness.", "Duljina reza je smanjenje slobodne uzdužne duljine, ne duljina žice. Uklonjene aktivne zavoje unesite zasebno; sama duljina ne određuje novu krutost. Više uklonjenih aktivnih zavoja → veća procijenjena krutost, ali kraća opruga → manje ugrađeno stlačenje. Izlazna energija može pasti unatoč većoj krutosti.")}</p>
      <p class="field-help">${t("Cutting is an estimate for uniform linear coils with unchanged wire, diameter and effective end support. Progressive coils and changed ends need new force measurements. Solid height must describe the remaining spring; a positive clearance is not a certified safety margin. Slack/unseating is outside this model.", "Skraćivanje je procjena za jednolike linearne zavoje uz istu žicu, promjer i efektivni oslonac krajeva. Progresivni zavoji i promijenjeni krajevi traže novo mjerenje sile. Duljina potpuno stisnute opruge mora opisivati preostalu oprugu; pozitivan zazor nije potvrđena sigurnosna margina. Labava opruga i gubitak kontakta izvan su ovog modela.")}</p></div>
      ${["springStiffness", "springPreload", "springMass"].map(field).join("")}<div id="springSummary" class="small-note" role="status"></div>
      <p class="field-help">${t("Weigh the remaining spring: mass is not inferred from length. The optional moving-mass approximation is one third of the entered spring mass.", "Izvažite preostalu oprugu: masa se ne izvodi iz duljine. Neobavezna aproksimacija pomične mase iznosi trećinu unesene mase opruge.")}</p>
      <label for="springCurve">${t("Optional measured force curve: compression mm, force N (one pair per line)", "Neobavezna izmjerena krivulja: stlačenje mm, sila N (jedan par po retku)")}</label><textarea id="springCurve" rows="4" placeholder="50, 27.5&#10;100, 55&#10;140, 77">${p.springCurve.map(v => v.join(", ")).join("\n")}</textarea>
      <p class="field-help">${t("A curve replaces linear stiffness and must cover the installed compression range. It cannot be reused for a simulated cut. For an already cut, measured spring, enter its current free length and force curve with cut length and removed coils set to zero. Estimated cuts are excluded from calibration fitting.", "Krivulja zamjenjuje linearnu krutost i mora pokrivati raspon ugrađenog stlačenja. Ne može se ponovno koristiti za simulirani rez. Za već skraćenu i izmjerenu oprugu unesite trenutačnu slobodnu duljinu i krivulju sile, a rez i uklonjene zavoje postavite na nulu. Procijenjeni rezovi ne koriste se za kalibracijsku prilagodbu.")}</p>
      ${provenanceControl("spring", "I have measured the spring force and installed compression", "Izmjerio/la sam silu opruge i ugrađeno stlačenje")}
      ${["pistonFriction", "sealFriction", "rearDamping"].map(field).join("")}</details>`;
  }
  function syncSpringControls() {
    if (!$("springLengthFields")) return;
    $("springLengthFields").hidden = p.springLengthMode !== 1;
    for (const key of ["springPreload", "springStiffness"]) {
      const disabled = key === "springPreload" ? p.springLengthMode === 1 : Boolean(p.springCurve.length);
      $(key).disabled = disabled; document.querySelector(`[data-range="${key}"]`).disabled = disabled;
      if (key === "springPreload") {
        const value = disabled ? P.springState(p).preload : p.springPreload;
        $(key).value = finite(value) ? value : ""; document.querySelector(`[data-range="${key}"]`).value = finite(value) ? value : 0;
      }
    }
    for (const key of O.GROUPS.spring) {
      const input = $("opt-" + key);
      if (input) {
        const fixed = O.fixedReason(p, key);
        input.disabled = optimizer.locks.spring || Boolean(fixed);
        input.value = fixed ? String(p[key]) : optimizer.values[key];
        const note = input.parentElement.querySelector("small");
        if (note) note.hidden = !fixed;
      }
    }
  }
  function syncBumperControls() {
    if (!$('bumperStiffness')) return;
    const fixed = Boolean(p.bumperCurve.length);
    $('bumperStiffness').disabled = fixed;
    document.querySelector('[data-range="bumperStiffness"]').disabled = fixed;
    const input = $('opt-bumperStiffness');
    if (input) {
      input.disabled = optimizer.locks.head || fixed;
      input.value = fixed ? String(p.bumperStiffness) : optimizer.values.bumperStiffness;
      const note = input.parentElement.querySelector('small');
      if (note) note.hidden = !fixed;
    }
  }
  function silencerMarkup() {
    return `<details id="silencerDetails" ${p.silencerEnabled ? "open" : ""}><summary>${t("Silencer / suppressor expansion chamber", "Ekspanzijska komora prigušivača")}</summary>
      <label class="provenance"><input id="silencerEnabled" type="checkbox" ${p.silencerEnabled ? "checked" : ""}>${t("Silencer installed for this shot", "Prigušivač je ugrađen za ovaj hitac")}</label>
      <p class="field-help">${t("The model adds a conservative gas chamber after the inner-barrel crown. It predicts pressure storage and outlet mass flow—not acoustic transmission, frequency response or real dB.", "Model dodaje konzervativnu plinsku komoru nakon krune unutarnje cijevi. Predviđa pohranu tlaka i maseni protok na izlazu — ne prijenos zvuka, frekvencijski odziv ni stvarne dB.")}</p>
      ${group("Measured internal geometry", "Izmjerena unutarnja geometrija", ["silencerLength", "silencerInnerDiameter", "silencerBaffleCount", "silencerBaffleThickness", "silencerBaffleBore", "silencerEndCapBore", "silencerPackingFraction"])}
      ${group("Conditional flow and thermal inputs", "Uvjetni ulazi protoka i topline", ["silencerDischargeCoefficient", "silencerHeatTransfer"], t("Cd combines contraction, turbulence and unmodeled baffle detail. Heat conductance is an effective transient fit. Neither is obtained from exterior dimensions.", "Cd objedinjuje suženje, turbulenciju i nerazriješene detalje pregrada. Toplinska vodljivost efektivna je prilagodba prijelaznog procesa. Nijedna se ne dobiva iz vanjskih dimenzija."))}
      <div id="silencerSummary" class="small-note" role="status"></div>
      ${provenanceControl("geometry", "I have measured the silencer's internal geometry", "Izmjerio/la sam unutarnju geometriju prigušivača")}</details>`;
  }
  function syncSilencerControls() {
    if (!$("silencerEnabled")) return;
    $("silencerEnabled").checked = p.silencerEnabled === 1;
    for (const key of O.GROUPS.silencer) {
      const input = $("opt-" + key);
      if (!input) continue;
      const inactive = p.silencerEnabled !== 1;
      input.disabled = optimizer.locks.silencer || inactive;
      if (inactive) input.value = String(p[key]);
      const note = input.parentElement.querySelector("small");
      if (note) {
        note.hidden = !inactive;
        if (inactive) note.textContent = t("Install the silencer in Setup before searching its physical geometry.", "Uključite prigušivač u Postavkama prije pretraživanja njegove fizičke geometrije.");
      }
    }
    const sg = P.silencerGeometry(p), barrel = P.geometry(p, 0, 0).barrelVolume;
    $("silencerSummary").innerHTML = p.silencerEnabled ? `${t("Calculated free gas volume", "Izračunati slobodni volumen plina")}: <strong>${fmt(sg.freeVolume * 1e6, 2, "cm³")}</strong> · ${t("volume / barrel", "volumen / cijev")}: <strong>${fmt(sg.freeVolume / barrel, 2, ": 1")}</strong> · ${t("equivalent outlet area", "ekvivalentna izlazna površina")}: <strong>${fmt(sg.effectiveOutletArea * 1e6, 2, "mm²")}</strong>. ${t("The equivalent area includes a disclosed lumped baffle/fill loss proxy; it is not a measured acoustic rating.", "Ekvivalentna površina uključuje navedenu koncentriranu procjenu gubitaka pregrada/ispune; nije izmjerena akustička ocjena.")}` : t("Silencer inactive: its dimensions do not affect this shot.", "Prigušivač nije aktivan: njegove dimenzije ne utječu na ovaj hitac.");
  }
  function group(en, hr, keys, help = "") { return `<section class="control-group"><p class="group-label">${t(en, hr)}</p>${keys.map(field).join("")}${help ? `<p class="field-help">${help}</p>` : ""}</section>`; }
  function provenanceControl(key, en, hr) { return `<label class="provenance"><input type="checkbox" data-provenance="${key}" ${provenance[key] === "measured" ? "checked" : ""}>${t(en, hr)}</label>`; }
  function render() {
    workspace?.rememberScroll();
    stop();
    const lab = location.hash === "#pneumatic-timing";
    document.documentElement.lang = language;
    document.title = lab ? t("Spring Sniper Pneumatic Timing Lab", "Laboratorij pneumatike opružnih snajpera") : "Airsoft Tools";
    if (!lab) {
      workspace = null;
      $("root").innerHTML = `<main class="tool-hub"><div class="hub-shell"><nav class="hub-nav"><div class="hub-brand"><span class="hub-brand-mark">AT</span><span>Airsoft Tools</span></div>${languageSwitch()}</nav><div class="hub-content"><div class="hub-intro"><p class="eyebrow">${t("Interactive workshop", "Interaktivna radionica")}</p><h1>Airsoft Tools</h1><p>${t("Explore the mechanics behind your setup.", "Istražite mehaniku svoje konfiguracije.")}</p></div><p class="hub-count">${t("1 tool available", "Dostupan je 1 alat")}</p><div class="tool-grid"><a class="tool-card" href="#pneumatic-timing"><span class="tool-icon" aria-hidden="true">↝</span><span class="tool-copy"><span class="tool-status">${t("Available", "Dostupno")}</span><h2>${t("Spring Sniper Pneumatic Timing Lab", "Laboratorij pneumatike opružnih snajpera")}</h2><p>${t("Explore airflow, piston motion and BB timing. Compare measured setups and calibrate with chrono data.", "Istražite protok zraka, gibanje pistona i BB-a. Usporedite izmjerene konfiguracije i kalibrirajte kronografom.")}</p></span><span class="tool-arrow">→</span></a></div><p class="hub-footnote">${t("More tools will appear here later.", "Novi alati bit će dodani kasnije.")}</p></div></div></main>`;
      bindLanguage(); return;
    }
    $("root").innerHTML = `<main class="app tuning-app"><header class="lab-header"><div><a href="#">${t("← All tools", "← Svi alati")}</a><h1>${t("Spring Sniper Pneumatic Timing Lab", "Laboratorij pneumatike opružnih snajpera")}</h1></div>${languageSwitch()}</header>
      <details class="model-caveat"><summary>${t("Unvalidated model · not exact joules or dB", "Nepotvrđen model · nisu točni jouli ni dB")}</summary><p>${t("Conditional physics predictions, not measured performance. Head/pin dimensions, spring data, bumper material response, muzzle Cd and silencer flow/thermal factors start as assumptions. A chrono fit does not validate internal timing, contact force, acoustic attenuation or sound. No exact real-world joules or dB are claimed.", "Uvjetna predviđanja fizikalnog modela, a ne izmjerene performanse. Dimenzije glave/pina, podaci opruge, odziv materijala gumice, Cd usta te faktori protoka/topline prigušivača početne su pretpostavke. Kalibracija kronografom ne potvrđuje unutarnji vremenski odnos, silu kontakta, akustičko prigušenje ni zvuk. Ne tvrdimo da su stvarni jouli ili dB točno predviđeni.")}</p></details>
      <div class="layout"><aside class="panel controls-panel" aria-label="${t("Simulation controls", "Kontrole simulacije")}"><div class="panel-heading"><h2>${t("Setup", "Postavke")}</h2><button class="secondary-button" id="toggleControls" type="button" aria-expanded="true">${t("Show / hide", "Prikaži / sakrij")}</button></div>
        <section class="control-group"><label for="platformPreset">${t("Rifle starting point", "Početna konfiguracija replike")}</label><select id="platformPreset">${Object.entries(platforms).map(([id, v]) => `<option value="${id}" ${selectedPlatform === id ? "selected" : ""}>${v.name}</option>`).join("")}<option value="custom" ${selectedPlatform === "custom" ? "selected" : ""}>${t("Custom", "Prilagođeno")}</option></select>
        <p class="evidence">${t("Preset geometry is nominal or assumed—not a measurement of your rifle. Changing platforms resets the mechanical assumptions.", "Geometrija predloška nominalna je ili pretpostavljena — nije mjerenje vaše replike. Promjena platforme vraća mehaničke pretpostavke.")}</p>
        <label for="component">${t("Piston / head identity", "Piston / glava cilindra")}</label><select id="component"><option value="amp" ${component === "amp" ? "selected" : ""}>AMP / Tridos Ultimate SSG10</option><option value="scorpion" ${component === "scorpion" ? "selected" : ""}>Stalker Scorpion</option><option value="custom" ${component === "custom" ? "selected" : ""}>${t("Other / custom", "Drugo / prilagođeno")}</option></select>
        <p class="field-help">${t("Identity labels never apply hidden power multipliers. AMP: nominal 71 g at Tridos; manufacturer lists 69–72 g depending on pin. Weigh the complete assembly. Exact head and pin dimensions remain unknown until measured.", "Naziv dijela ne uvodi skrivene množitelje snage. AMP: Tridos navodi 71 g, proizvođač 69–72 g ovisno o pinu. Izvažite cijeli sklop. Točne dimenzije glave i pina nepoznate su do mjerenja.")}</p>
        <label for="springLabel">${t("Spring identity (label only)", "Oznaka opruge (samo naziv)")}</label><select id="springLabel">${["unspecified", "M110", "M120", "M130", "M140", "M150", "M160", "M170", "M180", "M190", "M220", "custom"].map(v => `<option value="${v}" ${springLabel === v ? "selected" : ""}>${v === "unspecified" ? t("Unknown / not recorded", "Nepoznato / nije zabilježeno") : v === "custom" ? t("Other measured spring", "Druga izmjerena opruga") : v}</option>`).join("")}</select><p class="field-help">${t("Use the force data below. An M-rating alone does not determine spring stiffness or preload.", "Koristite podatke o sili u nastavku. Oznaka M ne određuje krutost ni prednaprezanje opruge.")}</p></section>
        ${group("Cylinder and barrel", "Cilindar i cijev", ["cylinderBore", "strokeLength", "barrelLength", "barrelDiameter"], t("Short stroke changes the cocked position. Added bumper thickness below moves the front contact plane rearward instead; the app shows the resulting effective travel separately.", "Skraćeni hod mijenja zapeti položaj. Debljina dodatne gumice niže umjesto toga pomiče prednju ravninu kontakta unatrag; aplikacija zasebno prikazuje dobiveni efektivni hod."))}
        <p class="small-note" id="shortStrokeDynamic"></p>
        ${silencerMarkup()}
        ${group("Moving masses", "Pomične mase", ["pistonMass", "bbMass", "bbDiameter"])}<div class="preset-row">${[58, 65, 68, 72, 76, 82].map(m => `<button class="preset" type="button" data-mass="${m}" aria-pressed="${p.pistonMass === m}">${m} g</button>`).join("")}</div>
        <details open><summary>${t("Head, bumper and airbrake geometry", "Geometrija glave, odbojne gumice i zračne kočnice")}</summary><p class="field-help">${t("Pneumatic cushioning: the pin restricts airflow before contact. The rubber bumper acts only when the piston reaches it. These are separate effects.", "Pneumatsko ublažavanje: pin ograničava protok prije kontakta. Odbojna gumica djeluje tek kad je piston dotakne. To su odvojeni učinci.")}</p>
        <section class="control-group bumper-controls"><p class="group-label">${t("Added cylinder-head bumper", "Dodatna odbojna gumica glave cilindra")}</p>${["bumperThickness", "bumperBore", "bumperStiffness", "bumperDamping", "bumperMaxCompression", "restitution"].map(field).join("")}<label for="bumperCurve">${t("Optional measured bumper curve: compression mm, force N", "Neobavezna izmjerena krivulja gumice: stlačenje mm, sila N")}</label><textarea id="bumperCurve" rows="4" placeholder="0, 0&#10;0.5, 100&#10;1.0, 300">${p.bumperCurve.map(v => v.join(", ")).join("\n")}</textarea><p class="field-help">${t("A measured nonlinear curve replaces the single linear stiffness. Start at 0 mm / 0 N and cover the complete compression cap. Dynamic damping is still entered separately; neither input is Shore hardness or dB.", "Izmjerena nelinearna krivulja zamjenjuje jednu linearnu krutost. Počnite s 0 mm / 0 N i pokrijte cijelu granicu stlačenja. Dinamičko prigušenje i dalje se unosi zasebno; nijedan ulaz nije Shore tvrdoća ni dB.")}</p><p class="field-help">${t("Thickness 0 mm means no added pad. With a pad, force and damping create a finite compression/contact interval; the effective cap is the smaller of the entered limit and physical thickness. Reaching that cap uses rigid bottom-out restitution.", "Debljina 0 mm znači da nema dodatne gumice. Uz gumicu, sila i prigušenje stvaraju konačan interval stlačivanja/kontakta; efektivna granica manja je od unesene vrijednosti i fizičke debljine. Dosezanje te granice koristi odskok krutog graničnika.")}</p></section>
        <label for="pinLabel">${t("Installed AMP pin", "Ugrađeni AMP pin")}</label><select id="pinLabel">${[["custom", "Measured / custom", "Izmjeren / prilagođen"], ["plug", "Plug / no airbrake", "Čep / bez zračne kočnice"], ["short", "Short pin — enter measured size", "Kratki pin — unesite dimenzije"], ["medium", "Medium pin — enter measured size", "Srednji pin — unesite dimenzije"], ["long", "Long pin — enter measured size", "Dugi pin — unesite dimenzije"]].map(([v, en, hr]) => `<option value="${v}" ${pinLabel === v ? "selected" : ""}>${t(en, hr)}</option>`).join("")}</select>
        ${["headBore", "headLength", "nozzleBore", "nozzleLength", "airbrakeLength", "airbrakeDiameter", "airbrakeTipDiameter", "airbrakeTaper", "deadVolume", "breechVolume", "frontDeadVolume"].map(field).join("")}<p class="small-note" id="clearanceNote"></p><p class="field-help">${t("Internal diameters—not outer diameters. The model has three consecutive axial passages: bumper opening, rigid-head bore and nozzle. Each restricts only the part of the pin actually reaching that segment. Dead volume is the bare rigid-head cavity; the pad's annular solid volume is subtracted automatically. Front residual volume prevents a zero-volume singularity as the BB clears the crown and should represent only the small terminal/muzzle pocket. Measure the installed geometry because rubber deformation and eccentricity are not resolved.", "Unutarnji promjeri — ne vanjski promjeri. Model ima tri uzastopna uzdužna kanala: otvor gumice, provrt krute glave i mlaznicu. Svaki ograničava samo dio pina koji stvarno doseže taj segment. Preostali volumen predstavlja šupljinu gole krute glave; puni prstenasti volumen gumice oduzima se automatski. Prednji preostali volumen sprječava singularnost nultog volumena pri izlasku BB-a i treba predstavljati samo mali završni džep na ustima. Izmjerite ugrađenu geometriju jer deformacija gume i ekscentričnost nisu razriješene.")}</p>${provenanceControl("geometry", "I have measured the geometry and assembled masses", "Izmjerio/la sam geometriju i mase sklopova")}</details>
        ${springMarkup()}
        <details><summary>${t("Airflow, friction and environment", "Protok, trenje i okoliš")}</summary>${["dischargeCoefficient", "muzzleDischargeCoefficient", "pistonLeak", "nozzleLeak", "bbLeakCoefficient", "bbBreakaway", "barrelDrag", "heatTransfer", "ambientPressure", "airTemperature"].map(field).join("")}<p class="field-help">${t("Head Cd controls transfer through the bumper/head/nozzle stack. Muzzle Cd vents the modeled air ahead of the BB before exit and the compressed charge after exit, so it can now affect both exit speed and the discharge/blast contributor. Leak areas include their own effective coefficient. All loss coefficients need evidence; they are not efficiency percentages.", "Cd glave određuje prijenos kroz sklop gumice/glave/mlaznice. Cd usta odzračuje modelirani zrak ispred BB-a prije izlaska i stlačeni naboj nakon izlaska, pa sada može utjecati i na izlaznu brzinu i na doprinos pražnjenja/praska. Površine curenja uključuju vlastiti efektivni koeficijent. Svi koeficijenti gubitaka traže potvrdu; nisu postoci učinkovitosti.")}</p></details>
        <details><summary>${t("Timing criteria and solver", "Vremenski kriteriji i rješavač")}</summary>${["usefulFraction", "decelThreshold", "maxTime"].map(field).join("")}<p class="field-help">${t("Adaptive midpoint integration, maximum step 0.01 ms. Thresholds are user conventions, not physical switches. The model can end before contact or complete discharge.", "Adaptivna integracija metodom srednje točke, najveći korak 0,01 ms. Pragovi su dogovoreni kriteriji, a ne fizikalne sklopke. Model može završiti prije kontakta ili potpunog pražnjenja.")}</p></details>
      </aside><section class="main">${optimizerMarkup()}<div id="results"></div>${calibrationMarkup()}</section></div></main>`;
    workspace = globalThis.PneumaticWorkspace.mount(document, workspaceState, t, view => {
      if (view === "optimizer") { optimizer.open = true; $("optimizerBody").hidden = false; $("toggleOptimizer").setAttribute("aria-expanded", "true"); }
      if (view === "calibration") $("calibrationPanel").open = true;
      setFrame(fraction);
    });
    bindLanguage(); bindControls(); bindFieldHelp(); bindOptimizer(); syncSpringControls(); syncBumperControls(); syncSilencerControls(); updateResults(); renderMeasurements(); renderOptimizerResults(); workspace.restoreScroll();
  }
  function calibrationMarkup() {
    return `<details class="panel calibration" id="calibrationPanel"><summary>${t("Calibration · actual chrono measurements", "Kalibracija · stvarna mjerenja kronografom")}</summary><div class="calibration-body"><p class="calibration-intro">${t("Your 0.46 g / 330 fps observation is a reference until its full setup is recorded. Energy is derived from mass and velocity, not an independent measurement. Record each shot. All data stays in this browser unless you export it.", "Mjerenje 0,46 g / 330 fps ostaje referenca dok se ne zabilježi potpuna konfiguracija. Energija se izvodi iz mase i brzine, nije neovisno mjerenje. Zabilježite svaki hitac. Podaci ostaju u ovom pregledniku osim ako ih izvezete.")}</p>
      <form id="measurementForm" class="measurement-form"><label>${t("BB mass (g)", "Masa BB-a (g)")}<input id="measurementMass" type="number" value="${p.bbMass}" min=".1" max="1" step=".01" required></label><label>${t("Measured speed (fps)", "Izmjerena brzina (fps)")}<input id="measurementFps" type="number" value="330" min="1" max="1000" step=".1" required></label><label>${t("Chrono uncertainty (fps)", "Nesigurnost kronografa (fps)")}<input id="measurementSigma" type="number" value="1" min=".1" max="100" step=".1" required></label>
      <label>${t("Piston contact time (ms, optional)", "Vrijeme kontakta pistona (ms, neobavezno)")}<input id="measurementHitMs" type="number" min="0" max="1000" step=".01"></label><label>${t("Peak cylinder bar(g), optional", "Vršni tlak cilindra bar(g), neobavezno")}<input id="measurementPressure" type="number" min="0" max="100" step=".01"></label><label>${t("Peak silencer bar(g), optional", "Vršni tlak prigušivača bar(g), neobavezno")}<input id="measurementSilencerPressure" type="number" min="0" max="100" step=".01"></label><label>${t("Peak bumper force (N, optional)", "Vršna sila gumice (N, neobavezno)")}<input id="measurementBumperForce" type="number" min="0" max="100000" step=".1"></label>
      <label>${t("Use this shot as", "Namjena hica")}<select id="measurementRole"><option value="reference">${t("Reference only", "Samo referenca")}</option><option value="train">${t("Training / fit", "Podatak za prilagodbu")}</option><option value="validation">${t("Held-out validation", "Neovisna provjera")}</option></select></label><label class="wide">${t("Notes: pin, spring, hop setting, BB batch, chrono distance, temperature", "Bilješke: pin, opruga, hop, serija BB-a, udaljenost kronografa, temperatura")}<input id="measurementNotes" type="text" maxlength="2000"></label><label class="wide provenance"><input id="measurementConfirm" type="checkbox">${t("The current inputs describe the hardware used for this measured shot", "Trenutačni ulazi opisuju sklop kojim je ovaj hitac izmjeren")}</label><output id="measurementEnergy" class="wide small-note"></output><button type="submit" class="secondary-button">${t("Add shot", "Dodaj hitac")}</button></form>
      <p class="small-note">${t("Fitting is enabled only for confirmed setups with measured geometry/masses and spring data. Select at most three unknowns. Fitting two parameters requires at least two genuinely different training configurations; repeats alone do not create identifiability. Instrumented contact/pressure/force measurements constrain internal mechanics far better than chrono alone. Held-out shots remain excluded.", "Prilagodba je omogućena samo za potvrđene konfiguracije s izmjerenom geometrijom/masama i podacima opruge. Odaberite najviše tri nepoznanice. Prilagodba dvaju parametara traži najmanje dvije stvarno različite konfiguracije; ponavljanja sama ne stvaraju prepoznatljivost. Instrumentirana mjerenja kontakta/tlaka/sile mnogo bolje ograničavaju unutarnju mehaniku od samog kronografa. Hici za neovisnu provjeru ostaju isključeni.")}</p>
      <fieldset class="fit-parameters"><legend>${t("Parameters to fit", "Parametri za prilagodbu")}</legend>${Object.keys(C.PARAMETER_SPECS).map(key => `<label><input type="checkbox" data-fit-parameter="${key}" ${fitSelection.includes(key) ? "checked" : ""}>${esc(fields[key]?.[language === "hr" ? 1 : 0] || key)}</label>`).join("")}</fieldset>
      <div class="table-wrap"><table><thead><tr><th>BB</th><th>fps / J</th><th>${t("Use / setup", "Namjena / konfiguracija")}</th><th>${t("Notes", "Bilješke")}</th><th></th></tr></thead><tbody id="measurementRows"></tbody></table></div>
      <div class="fit-row"><button id="fitButton" class="primary-button" type="button">${t("Fit selected parameters", "Prilagodi odabrane parametre")}</button><button id="exportMeasurements" class="secondary-button" type="button">${t("Export data", "Izvezi podatke")}</button><label class="secondary-button">${t("Import data", "Uvezi podatke")}<input id="importMeasurements" type="file" accept="application/json,.json" hidden></label></div><p id="fitStatus" class="status-line" role="status">${status ? esc(t(...status)) : t("No fit applied. References do not calibrate the solver.", "Prilagodba nije primijenjena. Reference ne kalibriraju rješavač.")}</p><div id="fitReport"></div>
      </div></details>`;
  }
  function ensureOptimizer() {
    if (optimizer) return;
    optimizer = { locks: Object.fromEntries(Object.keys(O.GROUPS).map(key => [key, !["piston", "airbrake"].includes(key)])),
      values: Object.fromEntries(Object.keys(O.LIMITS).map(key => [key, String(p[key])])), priority: "balanced", budget: 120,
      result: null, open: false, cancelled: false, running: false, status: null };
    optimizer.values.pistonMass = [...new Set([p.pistonMass, 58, 65, 68, 72, 76, 82])].join(", ");
    optimizer.values.airbrakeLength = [...new Set([p.airbrakeLength, 0, p.airbrakeLength - 2, p.airbrakeLength - 1, p.airbrakeLength + 1, p.airbrakeLength + 2].filter(v => v >= 0 && v <= 40).map(v => Number(v.toFixed(3))))].join(", ");
  }
  function optimizerMarkup() {
    ensureOptimizer();
    const labels = { cylinder: ["Cylinder", "Cilindar"], barrel: ["Barrel", "Cijev"], silencer: ["Silencer", "Prigušivač"], head: ["Head / bumper / nozzle", "Glava / gumica / mlaznica"], piston: ["Piston", "Piston"], airbrake: ["Airbrake", "Zračna kočnica"], spring: ["Spring", "Opruga"], bb: ["BB", "BB"] };
    return `<section class="panel optimizer"><div class="optimizer-heading"><div><h2>${t("Find a quieter, efficient setup", "Pronađi tišu i učinkovitiju konfiguraciju")}</h2><p class="small-note">${t("Freeze the parts you want to keep. Search only the hardware choices you can change.", "Zamrznite dijelove koje želite zadržati. Pretražujte samo zamjenjive dijelove.")}</p></div><button class="primary-button" type="button" id="toggleOptimizer" aria-expanded="${optimizer.open}" aria-controls="optimizerBody">${t("Freeze parts & optimize", "Zamrzni dijelove i optimiziraj")}</button></div>
      <div id="optimizerBody" ${optimizer.open ? "" : "hidden"}><p class="optimizer-target">${t("Performance constraint: keep 95–105% of this setup’s predicted BB exit energy.", "Uvjet performansi: zadrži 95–105% predviđene izlazne energije BB-a trenutačne konfiguracije.")}</p>
      <p class="small-note">${t("Checked = frozen. Enter actual available choices separated by commas; use a dot for decimals. The current value is always included. Example piston masses and pin lengths are hypothetical—not verified compatible AMP parts. Changing geometry can require new sealing/friction measurements.", "Označeno = zamrznuto. Unesite stvarno dostupne vrijednosti odvojene zarezima; decimalni znak je točka. Trenutačna vrijednost uvijek je uključena. Primjeri masa pistona i duljina pina hipotetski su — nisu potvrđeni kompatibilni AMP dijelovi. Promjena geometrije može zahtijevati novo mjerenje brtvljenja i trenja.")}</p>
      <div class="optimizer-locks">${Object.entries(O.GROUPS).map(([group, keys]) => `<fieldset class="optimizer-part"><legend><label><input type="checkbox" data-opt-lock="${group}" ${optimizer.locks[group] ? "checked" : ""}>${t("Freeze", "Zamrzni")} ${t(...labels[group])}</label></legend><details ${!optimizer.locks[group] ? "open" : ""}><summary>${t("Candidate values", "Vrijednosti kandidata")}</summary>${keys.map(key => {
        const fixedInput = O.fixedReason(p, key);
        return `<label class="optimizer-field" for="opt-${key}"><span>${t(fields[key][0], fields[key][1])} (${fields[key][2] === "turns" ? t("turns", "zavoja") : fields[key][2]})</span><input type="text" id="opt-${key}" data-opt-values="${key}" value="${esc(fixedInput ? String(p[key]) : optimizer.values[key])}" ${optimizer.locks[group] || fixedInput ? "disabled" : ""} maxlength="180"><small ${fixedInput ? "" : "hidden"}>${fixedInput === "measured-bumper" ? t("Fixed because the measured bumper force curve replaces linear stiffness.", "Fiksno jer izmjerena krivulja sile gumice zamjenjuje linearnu krutost.") : fixedInput === "silencer-disabled" ? t("Install the silencer in Setup before searching its physical geometry.", "Uključite prigušivač u Postavkama prije pretraživanja njegove fizičke geometrije.") : t("Fixed by the spring input mode or measured curve. Enable length mode in Setup to search spring lengths.", "Fiksno zbog načina unosa opruge ili izmjerene krivulje. Za pretragu duljina uključite taj način u Postavkama.")}</small></label>`;
      }).join("")}</details></fieldset>`).join("")}</div>
      <div class="optimizer-options"><label>${t("Ranking preference", "Prioritet rangiranja")}<select id="optimizerPriority">${[["balanced", "Balanced trade-off", "Uravnotežen kompromis"], ["quiet", "Lower sound contributors", "Niži doprinosi zvuku"], ["efficient", "Higher energy efficiency", "Viša energetska učinkovitost"]].map(([value, en, hr]) => `<option value="${value}" ${optimizer.priority === value ? "selected" : ""}>${t(en, hr)}</option>`).join("")}</select></label><label>${t("Maximum combinations", "Najviše kombinacija")}<select id="optimizerBudget">${[60, 120, 240].map(v => `<option ${optimizer.budget === v ? "selected" : ""}>${v}</option>`).join("")}</select></label></div>
      <p class="small-note">${t("Weather, fitted airflow/leakage, friction, rear damping, rigid restitution and timing criteria stay fixed. Bumper mechanics are searchable when the head group is unlocked; measured silencer geometry is searchable only when that silencer is installed and unlocked. Every candidate uses the same 250 ms observation limit. Rankings compare total modeled contact dissipation, peak flow at the actual atmospheric outlet (muzzle or silencer end cap), inner-barrel exit pressure, efficiency and pressure-wave uncertainty—not dB or guaranteed loudness.", "Vrijeme, prilagođeni protok/curenje, trenje, stražnje prigušenje, kruti odskok i vremenski kriteriji ostaju fiksni. Mehanika gumice pretraživa je kada je grupa glave otključana; izmjerena geometrija prigušivača pretraživa je samo kada je taj prigušivač ugrađen i otključan. Svaki kandidat koristi isti prozor promatranja od 250 ms. Rangiranje uspoređuje ukupno modelirano rasipanje kontakata, vršni protok na stvarnom izlazu u atmosferu (usta cijevi ili završna kapa prigušivača), tlak pri izlasku iz unutarnje cijevi, učinkovitost i nesigurnost tlačnih valova — ne dB ni zajamčenu glasnoću.")}</p>
      <details><summary>${t("How ranking works", "Kako radi rangiranje")}</summary><p class="small-note">${t("Only completed, numerically acceptable shots inside the energy band qualify. Keep the non-dominated trade-offs across five objectives, then rank the frontier with normalized preference weights. Contact / airflow / pressure / inefficiency / uncertainty weights: balanced 30/17/13/25/15%; sound-biased 38/20/17/10/15%; efficiency-biased 12/8/5/60/15%. Contact uses the complete dissipated contact sequence, not only the first strike. These weights are preferences, not an acoustic formula. A limited search finds the best tested choices, not a global optimum.", "Prikladni su samo završeni, numerički prihvatljivi hici unutar energetskog raspona. Zadržavaju se nedominirani kompromisi kroz pet ciljeva, zatim se fronta rangira normaliziranim ponderima. Kontakt / protok / tlak / neučinkovitost / nesigurnost: uravnoteženo 30/17/13/25/15%; zvuk 38/20/17/10/15%; učinkovitost 12/8/5/60/15%. Kontakt koristi cijeli slijed rasipanja, ne samo prvi udar. Ponderi su prioriteti, ne akustička formula. Ograničena pretraga pronalazi najbolje ispitane opcije, ne globalni optimum.")}</p></details>
      <div class="fit-row"><button class="primary-button" type="button" id="runOptimizer">${t("Find best combinations", "Pronađi najbolje kombinacije")}</button><button class="secondary-button" type="button" id="cancelOptimizer" disabled>${t("Cancel search", "Prekini pretragu")}</button></div><p class="status-line" role="status" id="optimizerStatus">${optimizer.status ? esc(t(...optimizer.status)) : ""}</p><div id="optimizerResults"></div></div></section>`;
  }
  function invalidateOptimizer() {
    if (!optimizer) return;
    optimizer.cancelled = true;
    if (optimizer.result) optimizer.status = ["Setup or search choices changed. Run the search again before applying a result.", "Konfiguracija ili odabiri pretrage promijenjeni su. Ponovite pretragu prije primjene rezultata."];
    optimizer.result = null;
    // Keep the old table's footprint so editing does not jump the animation.
    if ($("optimizerResults")) {
      $("optimizerResults").classList.add("is-stale");
      $("optimizerResults").querySelectorAll("button").forEach(button => { button.disabled = true; });
    }
    if ($("optimizerStatus")) $("optimizerStatus").textContent = optimizer.status ? t(...optimizer.status) : "";
  }
  function bindOptimizer() {
    $("toggleOptimizer").addEventListener("click", e => { optimizer.open = !optimizer.open; $("optimizerBody").hidden = !optimizer.open; e.currentTarget.setAttribute("aria-expanded", String(optimizer.open)); });
    document.querySelectorAll("[data-opt-lock]").forEach(box => box.addEventListener("change", () => {
      const group = box.dataset.optLock; optimizer.locks[group] = box.checked; invalidateOptimizer();
      for (const key of O.GROUPS[group]) $("opt-" + key).disabled = box.checked || Boolean(O.fixedReason(p, key));
      box.closest("fieldset").querySelector("details").open = !box.checked;
    }));
    document.querySelectorAll("[data-opt-values]").forEach(input => input.addEventListener("input", () => { optimizer.values[input.dataset.optValues] = input.value; invalidateOptimizer(); }));
    $("optimizerPriority").addEventListener("change", e => { optimizer.priority = e.target.value; invalidateOptimizer(); });
    $("optimizerBudget").addEventListener("change", e => { optimizer.budget = Number(e.target.value); invalidateOptimizer(); });
    $("cancelOptimizer").addEventListener("click", () => { optimizer.cancelled = true; $("cancelOptimizer").disabled = true; $("optimizerStatus").textContent = t("Cancelling after the current shot…", "Prekid nakon trenutačnog hica…"); });
    $("runOptimizer").addEventListener("click", async () => {
      if (busy) return;
      clearTimeout(debounce); stop();
      if (calculationPending || !shot) recalculate();
      const base = clone(p), config = { locks: clone(optimizer.locks), values: {}, budget: optimizer.budget, priority: optimizer.priority };
      try {
        for (const [group, keys] of Object.entries(O.GROUPS)) if (!config.locks[group]) for (const key of keys) config.values[key] = O.fixedReason(p, key) ? [p[key]] : O.parseValues(optimizer.values[key]);
        O.searchSpace(base, config);
      } catch (_) { optimizer.status = ["Check candidate lists: up to 12 numbers per field, within the normal control ranges. Use decimal dots. Confirm the starting setup is valid.", "Provjerite popise: do 12 brojeva po polju, unutar uobičajenih raspona kontrola. Koristite decimalnu točku. Početna konfiguracija mora biti valjana."]; $("optimizerStatus").textContent = t(...optimizer.status); return; }
      optimizer.cancelled = false; optimizer.running = true; optimizer.result = null;
      $("optimizerResults").innerHTML = ""; setBusy(true); $("cancelOptimizer").disabled = false;
      $("optimizerStatus").textContent = t("Capturing current energy and evaluating hardware combinations…", "Bilježenje trenutačne energije i provjera kombinacija dijelova…");
      await new Promise(resolve => setTimeout(resolve, 20));
      try {
        const result = await O.search(base, config, {
          isCancelled: () => optimizer.cancelled || JSON.stringify(p) !== JSON.stringify(base) || location.hash !== "#pneumatic-timing",
          onProgress: progress => { if ($("optimizerStatus")) $("optimizerStatus").textContent = t(`${progress.completed} / ${progress.planned} combinations checked · ${progress.eligible} eligible.`, `Provjereno ${progress.completed} / ${progress.planned} kombinacija · ${progress.eligible} prikladnih.`); }
        });
        optimizer.result = result; optimizer.status = ["Search complete. Review the trade-offs before applying a hypothetical setup.", "Pretraga je završena. Pregledajte kompromise prije primjene hipotetske konfiguracije."];
      } catch (error) {
        optimizer.result = null;
        optimizer.status = error.message === "optimizer:cancelled" ? ["Search cancelled. No setup was changed and partial results were discarded.", "Pretraga je prekinuta. Konfiguracija nije promijenjena, a djelomični rezultati odbačeni su."] : ["Search cannot start: the current setup needs a valid BB exit to define its energy target. Check inputs or spring data.", "Pretraga nije moguća: trenutačna konfiguracija mora dati valjan izlazak BB-a za ciljni energetski raspon. Provjerite ulaze ili oprugu."];
      } finally {
        optimizer.running = false; setBusy(false);
        if ($("optimizerStatus")) { $("optimizerStatus").textContent = t(...optimizer.status); $("cancelOptimizer").disabled = true; renderOptimizerResults(); }
      }
    });
  }
  function renderOptimizerResults() {
    if (!$("optimizerResults")) return;
    const r = optimizer?.result;
    if (!r) { $("optimizerResults").innerHTML = ""; return; }
    $("optimizerResults").classList.remove("is-stale");
    const rejected = r.rejected, best = r.frontier.slice(0, 5);
    const changeText = candidate => Object.entries(candidate.changes).map(([key, v]) => `${t(fields[key][0], fields[key][1])}: ${fmt(v.from, 3)} → ${fmt(v.to, 3)} ${fields[key][2]}`).join("; ") || t("Current setup — unchanged", "Trenutačna konfiguracija — nepromijenjena");
    const metricCells = m => `<td>${fmt(m.energy, 3, "J")}</td><td>${fmt(m.impact * 1000, 3, "mJ")}</td><td>${fmt(m.outflow * 1000, 3, "g/s")}</td><td>${fmt(m.exitGauge / 1e5, 3, "bar(g)")}</td><td>${fmt(m.efficiency * 100, 1, "%")}</td><td>${fmt(m.uncertainty, 2)}</td>`;
    $("optimizerResults").innerHTML = `<p class="optimizer-target">${t("Required model exit energy", "Tražena izlazna energija modela")}: ${fmt(r.bounds.min, 3)}–${fmt(r.bounds.max, 3, "J")}.</p>
      <p class="small-note">${t(`Checked ${r.evaluated} of ${r.total.toLocaleString("en")} combinations. ${r.exhaustive ? "All listed combinations checked." : "Sampled search; untested combinations may be better."} ${r.eligible} eligible; ${r.frontier.length} non-dominated trade-offs.`, `Provjereno ${r.evaluated} od ${r.total.toLocaleString("hr")} kombinacija. ${r.exhaustive ? "Provjerene su sve navedene kombinacije." : "Uzorkovana pretraga; neispitane kombinacije mogu biti bolje."} ${r.eligible} prikladnih; ${r.frontier.length} nedominiranih kompromisa.`)}</p>
      <p class="small-note">${t(`Excluded: ${rejected.energy} outside energy band, ${rejected.unfinished} missing contact/unfinished discharge, ${rejected.noExit} no exit, ${rejected.invalid} invalid, ${rejected.numerical} failed numerical checks. Unfinished impacts are unknown, never zero.`, `Isključeno: ${rejected.energy} izvan energije, ${rejected.unfinished} bez kontakta/nepotpuno pražnjenje, ${rejected.noExit} bez izlaska, ${rejected.invalid} nevaljanih, ${rejected.numerical} numerički neprihvatljivih. Nezavršeni udari nepoznati su, nikad nula.`)}</p>
      ${r.noVariables ? `<p class="lab-warning">${t("All values are frozen or have only the current choice. Nothing can be optimized; unfreeze a part and enter alternatives.", "Sve vrijednosti su zamrznute ili imaju samo trenutačni izbor. Nema promjenjivih veličina; odmrznite dio i unesite alternative.")}</p>` : ""}
      ${best.length ? `<div class="table-wrap"><table class="optimizer-table"><thead><tr><th>${t("Choice / changes", "Odabir / promjene")}</th><th>${t("BB energy", "Energija BB-a")}</th><th>${t("All-contact loss", "Gubitak svih kontakata")}</th><th>${t("Peak outlet flow", "Vršni izlazni protok")}</th><th>${t("Barrel-exit pressure", "Tlak na izlazu iz cijevi")}</th><th>${t("Efficiency", "Učinkovitost")}</th><th>${t("Uncertainty", "Nesigurnost")}</th><th></th></tr></thead><tbody>${r.baseline ? `<tr class="optimizer-baseline"><td>${t("Current setup · reference", "Trenutačno · referenca")}</td>${metricCells(r.baseline)}<td></td></tr>` : ""}${best.map((candidate, i) => {
        const m = candidate.metrics, b = r.baseline;
        const compromise = b && (m.impact > b.impact + 1e-9 || m.outflow > b.outflow + 1e-9 || m.exitGauge > b.exitGauge + 1e-4 || m.efficiency < b.efficiency - 1e-8 || m.uncertainty > b.uncertainty + 1e-8);
        return `<tr><td><strong>${i + 1}. ${t("Best found trade-off", "Najbolji pronađeni kompromis")}</strong><p>${esc(changeText(candidate))}</p><small>${compromise ? t("At least one objective is worse than the reference.", "Najmanje jedan cilj lošiji je od reference.") : t("No listed objective is worse than the reference, if available.", "Nijedan navedeni cilj nije lošiji od reference, ako je dostupna.")} ${t("Energy threshold → slowing", "Prag energije → usporavanje")}: ${stamp(m.timingMargin)}.</small></td>${metricCells(m)}<td><button class="secondary-button" type="button" data-apply-optimizer="${i}" ${Object.keys(candidate.changes).length ? "" : "disabled"}>${t("Apply & replay", "Primijeni i prikaži")}</button></td></tr>`;
      }).join("")}</tbody></table></div><p class="small-note">${t("Apply changes only the listed unlocked hardware and extends the playback limit to 250 ms (observation time, not a physical change). It marks changed inputs as unmeasured. Calibration records stay intact. Compare actual chrono and sound measurements before buying or changing parts.", "Primjena mijenja samo navedene odmrznute dijelove i produljuje prikaz na 250 ms (vrijeme promatranja, ne fizička promjena). Promijenjeni ulazi označuju se kao neizmjereni. Kalibracijski zapisi ostaju sačuvani. Usporedite stvarna mjerenja kronografom i zvuka prije kupnje ili zamjene dijelova.")}</p>` : `<p class="lab-warning">${t("No complete candidate meets the energy constraint. No best setup is claimed. Review your candidate values; unresolved low-impact cases are not assumed quiet.", "Nijedan završeni kandidat ne zadovoljava energetski uvjet. Ne tvrdi se da postoji najbolja konfiguracija. Provjerite kandidate; nezavršeni slučajevi ne smatraju se tihima.")}</p>`}
      <button class="secondary-button" type="button" id="exportOptimizer">${t("Export search and locks", "Izvezi pretragu i zaključavanja")}</button>`;
    $("exportOptimizer").addEventListener("click", () => download("airsoft-optimizer-search.json", r));
    document.querySelectorAll("[data-apply-optimizer]").forEach(button => button.addEventListener("click", () => {
      if (busy || !optimizer.result) return;
      const candidate = optimizer.result.frontier[Number(button.dataset.applyOptimizer)];
      try {
        const next = O.applyCandidate(p, optimizer.result, candidate), keys = Object.keys(candidate.changes);
        // Recheck using the normal full-trace solver before changing the live setup.
        const checked = P.simulate(next, { maxTime: r.horizonMs });
        if (O.assess(next, checked, r.bounds).reason) throw new Error("candidate changed");
        p = next; p.maxTime = r.horizonMs; selectedPlatform = "custom";
        if (keys.some(key => O.GROUPS.spring.includes(key))) { provenance.spring = "assumed"; springLabel = "custom"; }
        if (keys.some(key => !O.GROUPS.spring.includes(key))) provenance.geometry = "assumed";
        if (keys.some(key => [...O.GROUPS.piston, ...O.GROUPS.head, ...O.GROUPS.airbrake].includes(key))) component = "custom";
        if (keys.some(key => O.GROUPS.airbrake.includes(key))) pinLabel = p.airbrakeLength ? "custom" : "plug";
        invalidateFit(); setStatus("A hypothetical optimizer setup is active. Existing measurements are preserved; this new hardware combination is not automatically calibrated.", "Aktivna je hipotetska konfiguracija optimizatora. Postojeća mjerenja sačuvana su; nova kombinacija dijelova nije automatski kalibrirana."); invalidateOptimizer(); syncSetupControls(); recalculate(); optimizer.status = ["Candidate applied. Frozen hardware and environmental/loss assumptions were preserved. Playback now observes up to 250 ms.", "Kandidat je primijenjen. Zamrznuti dijelovi i pretpostavke okoliša/gubitaka sačuvani su. Prikaz sada prati do 250 ms."]; $("optimizerStatus").textContent = t(...optimizer.status);
        const category = keys.every(key => O.GROUPS.spring.includes(key)) ? "spring" : keys.some(key => O.GROUPS.silencer.includes(key)) ? "silencer" : keys.some(key => [...O.GROUPS.head, ...O.GROUPS.airbrake].includes(key)) ? "airbrake" : keys.some(key => [...O.GROUPS.piston, ...O.GROUPS.bb].includes(key)) ? "masses" : "geometry";
        workspace.selectCategory(category); workspace.selectView("shot");
        setFrame(0); $("workspaceBody").scrollTop = 0;
        if (window.innerWidth <= 960) $("previewPanel").scrollIntoView({ block: "start" });
        $("playButton").focus({ preventScroll: true }); startPlayback();
      } catch (_) { invalidateOptimizer(); optimizer.status = ["Result is stale or failed rechecking. No candidate was applied; run the search again.", "Rezultat je zastario ili nije prošao ponovnu provjeru. Kandidat nije primijenjen; ponovite pretragu."]; $("optimizerStatus").textContent = t(...optimizer.status); }
    }));
  }
  function metric(label, value, note, kind = "model") { return `<article class="readout"><div class="topline"><span>${label}</span><span class="tag ${kind}">${kind === "geometry" ? t("geometry", "geometrija") : t("model", "model")}</span></div><strong>${value}</strong><small>${note}</small></article>`; }
  function updateSpringSummary() {
    if (!$("springSummary")) return;
    const s = P.springState(p), errors = P.validate(p).filter(v => v.startsWith("spring"));
    const messages = {
      "spring:lengths": ["Enter positive free length and a front seat distance greater than the stroke.", "Unesite pozitivnu slobodnu duljinu i razmak prednjih oslonaca veći od hoda."],
      "spring:slack": ["The resulting spring is shorter than the front seat distance. Unseating/recontact is not modeled.", "Dobivena opruga kraća je od razmaka oslonaca pri prednjem kontaktu. Gubitak i ponovni kontakt nisu modelirani."],
      "spring:coils": ["A cut estimate needs the original active-coil count and fewer removed active coils. Do not infer these from length alone.", "Procjena reza traži početni broj aktivnih zavoja i manji broj uklonjenih. Ne izvodite ih samo iz duljine."],
      "spring:cut-length": ["Enter the free-length reduction when active coils have been removed.", "Unesite smanjenje slobodne duljine ako su uklonjeni aktivni zavoji."],
      "spring:coil-bind": ["Coil bind: the cocked seat distance is at or below the entered solid height.", "Potpuno stiskanje zavoja: razmak oslonaca zapete opruge manji je ili jednak duljini potpuno stisnute opruge."],
      "spring:cut-curve": ["An uncut force curve cannot predict a cut spring. Clear it to estimate, or enter the already-cut measured spring with cut/removal set to zero.", "Krivulja neskraćene opruge ne predviđa skraćenu. Izbrišite je za procjenu ili unesite već skraćenu izmjerenu oprugu uz nulti rez i uklonjene zavoje."],
      "spring:coverage": ["The measured curve must cover front compression through full cocked compression.", "Izmjerena krivulja mora pokriti stlačenje pri prednjem kontaktu do punog zapinjanja."]
    };
    $("springSummary").innerHTML = errors.length ? `<p class="lab-warning" role="alert">${errors.map(code => esc(messages[code] ? t(...messages[code]) : code)).join(" ")}</p>` : `<div class="spring-summary">
      ${p.springLengthMode ? `<p>${t("Resulting free length", "Dobivena slobodna duljina")}: <strong>${fmt(s.freeLength, 1, "mm")}</strong></p><p>${t("Cocked seat distance", "Razmak oslonaca pri zapinjanju")}: <strong>${fmt(s.cockedLength, 1, "mm")}</strong></p>` : ""}
      <p>${t("Compression · front / cocked", "Stlačenje · prednji kontakt / zapeto")}: <strong>${fmt(s.preload, 1)} / ${fmt(s.cockedCompression, 1)} mm</strong></p>
      <p>${p.springCurve.length ? t("Measured force curve active", "Aktivna izmjerena krivulja sile") : `${t("Effective stiffness", "Efektivna krutost")}: <strong>${fmt(s.stiffness, 1, "N/m")}</strong>${p.springLengthMode && p.springCutLength > 0 ? ` · ${t("cut estimate", "procjena reza")}` : ""}`}</p>
      <p>${t("Force · bumper contact / cocked", "Sila · kontakt s gumicom / zapeto")}: <strong>${fmt(P.springForce(p, P.contactStroke(p)), 2)} / ${fmt(P.springForce(p, 0), 2)} N</strong></p>
      <p>${t("Available spring work", "Raspoloživi rad opruge")}: <strong>${fmt(P.springEnergy(p, 0), 3, "J")}</strong> · ${t("not BB exit energy", "nije izlazna energija BB-a")}</p>
      <p>${s.coilBindChecked ? `${t("Cocked clearance above solid height", "Zazor zapete opruge iznad potpuno stisnute duljine")}: ${fmt(s.cockedLength - p.springSolidLength, 1, "mm")}` : t("Coil bind not checked — solid height / seat geometry unknown.", "Potpuno stiskanje zavoja nije provjereno — nepoznata duljina / geometrija oslonaca.")}</p></div>`;
  }
  function setResultState(state) {
    const results = $("results");
    if (!results) return;
    if (!$("resultContent")) {
      results.innerHTML = '<div id="resultStatus" class="result-status" role="status" aria-live="polite"></div><div id="resultError" class="lab-warning error" role="alert" hidden></div><div id="resultContent"></div>';
      bindResults();
    }
    results.dataset.state = state;
    workspace?.sync();
    results.setAttribute("aria-busy", String(state === "pending"));
    $("resultContent").inert = state !== "ready";
    $("resultContent").setAttribute("aria-hidden", String(state === "invalid"));
    $("resultError").hidden = state !== "invalid";
    $("resultStatus").textContent = state === "pending" ? t("Updating… previous shot held on screen; playback paused.", "Ažuriranje… prethodni hitac ostaje na zaslonu; prikaz je pauziran.") : state === "invalid" ? t("Check inputs · results unavailable", "Provjerite ulaze · rezultati nisu dostupni") : t("Live model · edits update in place · playback stays at the same shot time", "Model uživo · izmjene bez ponovnog učitavanja · zadržava se vrijeme prikaza");
  }
  function updateResults() {
    if (!$("results")) return;
    updateSpringSummary();
    syncSilencerControls();
    const g = P.geometry(p, 0, 0), effectiveStroke = g.stroke * 1000, before = Math.max(0, effectiveStroke - p.airbrakeLength);
    $("shortStrokeDynamic").textContent = t(`Effective piston travel: ${effectiveStroke.toFixed(1)} mm (${p.bumperThickness.toFixed(1)} mm added bumper). Swept volume: ${(g.sweptVolume * 1e6).toFixed(2)} cm³. Before pin entry: ${before.toFixed(1)} mm / ${(g.ac * before * 1000).toFixed(2)} cm³.`, `Efektivni hod pistona: ${effectiveStroke.toFixed(1)} mm (${p.bumperThickness.toFixed(1)} mm dodatne gumice). Radni volumen: ${(g.sweptVolume * 1e6).toFixed(2)} cm³. Prije ulaska pina: ${before.toFixed(1)} mm / ${(g.ac * before * 1000).toFixed(2)} cm³.`);
    const bumperClearance = p.bumperThickness > 0 ? `${g.bumperGap.toFixed(3)} mm / ${(g.bumperAnnulus * 1e6).toFixed(3)} mm²` : t("inactive (0 mm thickness)", "neaktivno (debljina 0 mm)");
    $("clearanceNote").textContent = t(`Full-shaft clearance / annular area — bumper: ${bumperClearance}; metal head: ${g.gap.toFixed(3)} mm / ${(g.annulus * 1e6).toFixed(3)} mm². Added bumper solid volume: ${(g.bumperSolidVolume * 1e6).toFixed(3)} cm³.`, `Zazor tijela pina / prstenasta površina — gumica: ${bumperClearance}; metalna glava: ${g.gap.toFixed(3)} mm / ${(g.annulus * 1e6).toFixed(3)} mm². Puni volumen dodatne gumice: ${(g.bumperSolidVolume * 1e6).toFixed(3)} cm³.`);
    if (!shot?.valid) {
      setResultState("invalid");
      const errorText = {
        "bumper:curve": ["Bumper curve needs finite, increasing compression points and nondecreasing nonnegative force.", "Krivulja gumice traži konačne rastuće točke stlačenja te neopadajuću nenegativnu silu."],
        "bumper:coverage": ["Bumper curve must start at 0 mm / 0 N and cover the full compression cap.", "Krivulja gumice mora početi s 0 mm / 0 N i pokriti cijelu granicu stlačenja."],
        "silencer:bb-clearance": ["Every silencer bore must be larger than the entered BB diameter.", "Svaki provrt prigušivača mora biti veći od unesenog promjera BB-a."],
        "silencer:clearance": ["Silencer baffle and end-cap bores must be smaller than its internal chamber diameter.", "Provrt pregrada i izlazne kape mora biti manji od unutarnjeg promjera komore prigušivača."],
        "silencer:length": ["The combined baffle thickness must be shorter than the internal expansion length.", "Zbroj debljina pregrada mora biti manji od unutarnje ekspanzijske duljine."],
        "silencer:packing": ["Silencer solid fill fraction must stay between 0 and 0.89.", "Udio punog volumena ispune prigušivača mora biti između 0 i 0,89."],
        "silencer:volume": ["The entered silencer geometry leaves no usable gas volume or outlet area.", "Unesena geometrija prigušivača ne ostavlja uporabljiv volumen plina ili izlaznu površinu."],
        "solver:convergence": ["The numerical solver did not converge; this run is invalid, not a settled shot.", "Numerički rješavač nije konvergirao; ovaj hitac nije valjan niti se smatra smirenim."]
      };
      $("resultError").textContent = t("Cannot simulate this setup. Check dimensions, clearances, residual volumes and force curves. Previous results are hidden: ", "Ovu konfiguraciju nije moguće simulirati. Provjerite dimenzije, zazore, preostale volumene i krivulje sile. Prethodni rezultati su skriveni: ") + (shot?.errors || []).map(code => errorText[code] ? t(...errorText[code]) : code).join(" · "); return;
    }
    const s = shot, retention = s.exitEnergy !== null && baseline?.valid && baseline.exitEnergy > 0 ? 100 * s.exitEnergy / baseline.exitEnergy : null;
    const diff = s.engageTime !== null && s.exitTime !== null ? (s.engageTime - s.exitTime) * 1000 : null;
    const timing = I.timing(s, p), delta = timing.marginMs;
    const verdict = I.verdictText(timing.verdict, t);
    const next = document.createElement("div");
    next.innerHTML = `<div class="readout-grid">
      ${metric(t("Cylinder / barrel volumes", "Volumeni cilindra / cijevi"), `${fmt(s.cylinderVolume * 1e6, 2)} / ${fmt(s.barrelVolume * 1e6, 2)}`, "cm³", "geometry")}
      ${metric(t("Cylinder / barrel ratio", "Omjer cilindra / cijevi"), fmt(s.ratio, 2, ": 1"), t("Swept volume / barrel volume", "Radni volumen / volumen cijevi"), "geometry")}
      ${metric(t("Silencer free volume / barrel", "Slobodni volumen prigušivača / cijev"), p.silencerEnabled ? `${fmt(s.silencerVolume * 1e6, 2)} / ${fmt(s.silencerExpansionRatio, 2, ": 1")}` : t("inactive", "neaktivno"), p.silencerEnabled ? t("Calculated from internal dimensions, baffle solids and fill fraction", "Izračunato iz unutarnjih dimenzija, punog volumena pregrada i udjela ispune") : t("No silencer chamber in this run", "U ovoj simulaciji nema komore prigušivača"), "geometry")}
      ${metric(t("Bumper / effective contact travel", "Gumica / efektivni hod do kontakta"), `${fmt(p.bumperThickness, 1)} / ${fmt(s.stroke * 1000, 1)}`, "mm", "geometry")}
      ${metric(t("Bumper compression / peak force", "Stlačenje gumice / vršna sila"), p.bumperThickness > 0 ? `${fmt(s.maxBumperCompression * 1000, 3)} / ${fmt(s.peakBumperForce, 1)}` : t("inactive", "neaktivno"), t("mm / N · conditional contact model", "mm / N · uvjetni model kontakta"))}
      ${metric(p.silencerEnabled ? t("Predicted inner-barrel exit speed", "Predviđena brzina na izlazu iz unutarnje cijevi") : t("Predicted muzzle speed", "Predviđena izlazna brzina"), fmt(fps(s.exitVelocity), 1, "fps"), s.exitEnergy === null ? t("BB did not exit within the run", "BB nije izašao tijekom simulacije") : `${fmt(s.exitEnergy, 3, "J")} · ${t("conditional, not chrono", "uvjetno, nije kronograf")}`)}
      ${metric(t("Energy gained at slowing event", "Energija pri događaju usporavanja"), fmt(s.preBrakeShare === null ? null : s.preBrakeShare * 100, 1, "%"), t("Relative to exit energy; can exceed 100%", "U odnosu na izlaznu energiju; može prijeći 100%"))}
      ${metric(t("Peak cylinder / behind / ahead-BB pressure", "Vršni tlak cilindra / iza / ispred BB-a"), `${fmt((s.peakCylinderPressure - s.ambientPressure) / 1e5, 2)} / ${fmt((s.peakPressure - s.ambientPressure) / 1e5, 2)} / ${fmt((s.peakFrontPressure - s.ambientPressure) / 1e5, 2)}`, t("bar above atmosphere", "bar iznad atmosferskog tlaka"))}
      ${metric(t("Silencer pressure / outlet pulse", "Tlak prigušivača / izlazni impuls"), p.silencerEnabled ? `${fmt((s.peakSilencerPressure - s.ambientPressure) / 1e5, 2)} / ${fmt(s.outflowPulseDuration * 1000, 2)}` : t("inactive", "neaktivno"), p.silencerEnabled ? t("peak bar(g) / duration above 10% peak flow in ms · not dB", "vršni bar(g) / trajanje iznad 10% vršnog protoka u ms · nije dB") : t("Direct muzzle discharge", "Izravno pražnjenje na ustima"))}
      ${metric(t("Relative exit-energy retention", "Relativno zadržavanje izlazne energije"), fmt(retention, 1, "%"), t("Same mass, no-pin baseline; not sound reduction", "Ista masa, referenca bez pina; nije utišavanje"))}
      ${metric(t("Piston momentum at entry", "Količina gibanja pistona pri ulasku"), fmt(s.momentumAtEngage, 3, "kg·m/s"), t("Actual piston mass × signed velocity", "Stvarna masa pistona × predznačena brzina"))}
      ${metric(t("Pin entry relative to BB exit", "Ulazak pina u odnosu na izlazak BB-a"), fmt(diff, 2, "ms"), t("Negative = pin enters first", "Negativno = pin ulazi prvi"))}
      </div>
      ${s.waveDiagnostics.risk !== "low" ? `<div class="lab-warning" role="status"><strong>${t("Pressure-wave timing uncertainty is not negligible", "Nesigurnost vremenskog odnosa zbog tlačnih valova nije zanemariva")}</strong><p>${t(`The causal travel-time envelope finds up to ${fmt(s.waveDiagnostics.maxTransit * 1000, 3)} ms one-way transit and ${fmt(s.waveDiagnostics.relativePressureSpan * 100, 1)}% pressure-history spread. Its ${s.waveDiagnostics.referenceCellCount}-cell scale is only a resolution reference, not a solved 1D flow field. The primary motion still uses lumped chamber pressure; treat sub-millisecond event ordering as conditional until instrumented or fully coupled 1D validation agrees.`, `Uzročna ovojnica vremena putovanja nalazi do ${fmt(s.waveDiagnostics.maxTransit * 1000, 3)} ms jednosmjernog prolaza i ${fmt(s.waveDiagnostics.relativePressureSpan * 100, 1)}% raspona povijesti tlaka. Skala od ${s.waveDiagnostics.referenceCellCount} ćelije samo je referentna rezolucija, a ne riješeno 1D polje protoka. Primarno gibanje i dalje koristi koncentrirani tlak komore; redoslijed događaja ispod milisekunde smatrajte uvjetnim dok se ne potvrdi instrumentiranim ili potpuno spregnutim 1D modelom.`)}</p></div>` : ""}
      ${!s.complete ? `<div class="lab-warning">${t("Run ended with missing events:", "Simulacija je završila bez događaja:")} ${s.exitTime === null ? t("BB exit. ", "Izlazak BB-a. ") : ""}${s.pistonHitTime === null ? t("Piston contact. ", "Kontakt pistona. ") : ""}${t("Missing contact is not a predicted soft landing. Increase modeled time if appropriate.", "Izostanak kontakta ne znači predviđen mekan udar. Po potrebi povećajte vrijeme simulacije.")}</div>` : ""}
      <section class="panel timing-card"><div class="timing-head"><strong>${verdict}</strong><span>${fmt(delta, 2, "ms")}</span></div><p class="small-note">${t("The amber event is measured from the modeled acceleration after entry—not proof that all slowing is caused by the pin. Compression can slow a piston without an airbrake. Green marks a chosen share of maximum BB energy before exit, not a universal optimum.", "Jantarni događaj temelji se na modeliranom ubrzanju nakon ulaska — nije dokaz da je sve usporavanje uzrokovano pinom. Kompresija može usporiti piston i bez kočnice. Zelena označuje odabrani udio najveće energije BB-a prije izlaska, ne univerzalni optimum.")}</p><div class="event-list">${events().map(([key, label, cls]) => `<button type="button" data-event="${key}" class="${cls}" ${s[key] === null ? "disabled" : ""}>${label}<br><span class="mono">${stamp(s[key])}</span></button>`).join("")}</div></section>
      <section class="panel stage"><div class="stage-toolbar"><button class="primary-button" type="button" id="playButton">${t("Fire / play", "Opali / pokreni")}</button><button class="secondary-button" id="resetButton" type="button">${t("Reset", "Početak")}</button><input id="scrubber" aria-label="${t("Shot time", "Vrijeme opaljenja")}" type="range" min="0" max="1000" value="${fraction * 1000}"><span id="clock" class="clock mono"></span></div><canvas id="mechanism" role="img" aria-label="${t("Schematic piston, bumper, airbrake, BB and optional silencer positions; live numeric values below", "Shematski položaji pistona, odbojne gumice, pina, BB-a i neobaveznog prigušivača; brojčane vrijednosti ispod")}"></canvas><div id="phaseText" class="stage-status" aria-live="off"></div><div id="liveStrip" class="live-strip"></div><p class="results-note">${t("Schematic cutaway. The green pad visibly compresses according to the lumped stiffness/damping model; its exact rubber shape is still illustrative. The silencer drawing follows entered geometry but not exact baffle shape. After inner-barrel exit the drawn BB coasts at its exit speed: acceleration between baffles is not solved. Glow indicates modeled pressure; particles and trails illustrate flow and motion, not resolved gas dynamics or sound. Every cue pauses with model time.", "Shematski presjek. Zelena gumica vidljivo se stišće prema koncentriranom modelu krutosti/prigušenja; točan oblik gume i dalje je ilustrativan. Crtež prigušivača prati unesenu geometriju, ali ne točan oblik pregrada. Nakon izlaska iz unutarnje cijevi nacrtani BB nastavlja izlaznom brzinom: ubrzavanje između pregrada nije riješeno. Sjaj označuje modelirani tlak; čestice i tragovi ilustriraju protok i gibanje, ne razriješenu dinamiku plina ni zvuk. Sve se pauzira s vremenom modela.")}</p></section>
      <section class="panel graphs"><div class="graphs-header"><div><h2>${t("Shot traces", "Krivulje opaljenja")}</h2><p>${t(`Pressure: amber cylinder, cyan behind BB, violet ahead of BB${p.silencerEnabled ? ", green silencer chamber" : ""}; dashed blue is the causal travel-time estimate, not a solved 1D pressure. Events: green energy threshold, dashed amber slowing, cyan exit. Negative values remain visible.`, `Tlak: jantarni cilindar, cijan iza BB-a, ljubičasti ispred BB-a${p.silencerEnabled ? ", zelena komora prigušivača" : ""}; isprekidana plava je uzročna procjena vremena putovanja, a ne riješeni 1D tlak. Događaji: zeleni prag energije, isprekidano jantarno usporavanje, cijan izlazak. Negativne vrijednosti ostaju vidljive.`)}</p></div></div><div class="graphs-mechanism"><div class="graphs-mechanism-heading"><strong>${t("Live firing cutaway", "Živi presjek opaljenja")}</strong><span>${t("synchronized with graph cursor", "sinkronizirano s pokazivačem grafova")}</span></div><canvas id="mechanismGraph" role="img" aria-label="${t("Synchronized piston, bumper, airbrake, BB and optional silencer above the shot graphs", "Sinkronizirani položaji pistona, gumice, pina, BB-a i neobaveznog prigušivača iznad grafova opaljenja")}"></canvas></div><div class="chart-grid">${[["pressureChart", t("Pressure vs time", "Tlak kroz vrijeme"), "bar(g)"], ["pistonChart", t("Piston velocity vs time", "Brzina pistona kroz vrijeme"), "m/s"], ["bbChart", t("BB velocity vs time", "Brzina BB-a kroz vrijeme"), "m/s"]].map(([id, label, units]) => `<div class="chart"><div class="chart-title"><span>${label}</span><span>${units} / ms</span></div><canvas id="${id}" role="img" aria-label="${label}; ${t("numeric values in live readouts; export full trace below", "brojčane vrijednosti u prikazu uživo; izvoz cijele krivulje ispod")}"></canvas></div>`).join("")}</div>${I.impactMarkup(s, "impactGraph", "graphs", t, fmt)}</section>
      ${Parts.markup(p, t)}
      ${I.soundMarkup(s, baseline, unsilencedReference, t, fmt)}
      ${I.impactMarkup(s, "impactResultsChart", "results", t, fmt)}
      ${I.feedbackMarkup(changeComparison, s, baseline, p, provenance, fields, t, fmt)}
      <section class="panel insight"><div class="panel-heading"><h2>${t("Energy, verification and uncertainty", "Energija, provjera i nesigurnost")}</h2><span class="tag unknown">${t("not experimentally validated", "nije eksperimentalno potvrđeno")}</span></div><div class="assumption-grid"><span>${t("Maximum BB energy observed", "Najveća opažena energija BB-a")}</span><strong>${fmt(s.maxBbEnergy, 3, "J")}</strong><span>${t("Energy lost before exit", "Energija izgubljena prije izlaska")}</span><strong>${fmt(s.bbEnergyLoss, 3, "J")}</strong><span>${t("Positive / negative net BB work", "Pozitivan / negativan neto rad na BB-u")}</span><strong>${fmt(s.positiveBbWork, 3)} / ${fmt(s.negativeBbWork, 3, "J")}</strong><span>${t("Energy balance residual", "Odstupanje energetske bilance")}</span><strong>${fmt(s.energyResidual * 1000, 4, "mJ")}</strong><span>${t("Gas mass residual", "Odstupanje bilance mase plina")}</span><strong>${s.massResidual.toExponential(2)} kg</strong><span>${t("Ambient barrel sound-crossing scale", "Vrijeme prolaza zvuka kroz cijev pri okolišnim uvjetima")}</span><strong>${stamp(s.soundCrossingTime)}</strong><span>${t("Causal transit / 24-cell reference scale", "Uzročni prolaz / referentna skala 24 ćelije")}</span><strong>${stamp(s.waveDiagnostics.maxTransit)} / ${stamp(s.waveDiagnostics.referenceCellTransit)}</strong><span>${t("Wave-envelope pressure spread", "Raspon tlačne ovojnice")}</span><strong>${fmt(s.waveDiagnostics.maxPressureDelta / 1e5, 3, "bar")} · ${fmt(s.waveDiagnostics.relativePressureSpan * 100, 1, "%")}</strong></div>
      <p class="small-note">${t("A small numerical residual does not validate the physics. Cylinder, behind-BB, ahead-BB and optional silencer gas are conservative lumped control volumes; profile-sliced duct losses, the effective leaky-piston BB and lumped silencer loss factor remain approximations. The front volume vents through the muzzle and opposes BB motion. The solved BB trajectory ends at the inner-barrel crown; its later travel through a silencer is drawn at constant exit speed. Spatial pressure waves, moving-BB blockage inside the silencer, baffle-resolved jets, acoustic transmission, spring surge, distributed rubber deformation and structural acoustics are not resolved. Sub-millisecond timing and silencer behavior still need instrumented validation.", "Malo numeričko odstupanje ne potvrđuje fizikalni model. Plin u cilindru, iza BB-a, ispred BB-a i neobavezno u prigušivaču predstavljaju konzervativne koncentrirane kontrolne volumene; gubici kanala podijeljeni po profilu, BB kao efektivni propusni klip i koncentrirani faktor gubitaka prigušivača ostaju aproksimacije. Prednji volumen odzračuje kroz usta i suprotstavlja se gibanju BB-a. Riješena putanja BB-a završava na kruni unutarnje cijevi; kasniji prolaz kroz prigušivač nacrtan je stalnom izlaznom brzinom. Prostorni tlačni valovi, blokiranje protoka BB-om unutar prigušivača, mlazovi kroz pojedine pregrade, akustički prijenos, valovi opruge, raspodijeljena deformacija gume ni strukturna akustika nisu razriješeni. Vremenski odnos ispod milisekunde i ponašanje prigušivača i dalje traže instrumentiranu provjeru.")}</p>
      <div class="fit-row"><button class="secondary-button" id="convergenceButton" type="button">${t("Check finer time steps", "Provjeri manje vremenske korake")}</button><button class="secondary-button" id="sensitivityButton" type="button">${t("Check input sensitivity", "Provjeri osjetljivost na ulaze")}</button><button class="secondary-button" id="exportRun" type="button">${t("Export setup and full trace", "Izvezi postavke i cijelu krivulju")}</button></div>
      <p class="small-note">${t("Sensitivity examples vary head and pin diameter by ±0.02 mm and spring force by ±5%, in all eight combinations. These are explicit test ranges, not measured tolerances or statistical confidence intervals.", "Primjeri osjetljivosti mijenjaju promjer glave i pina za ±0,02 mm te silu opruge za ±5%, u svih osam kombinacija. To su izričito zadani ispitni rasponi, a ne izmjerene tolerancije ili statistički intervali pouzdanosti.")}</p><p id="diagnosticReport" class="status-line" role="status">${diagnostic ? esc(t(...diagnostic)) : ""}</p>
      <div class="source-links"><a href="https://tridos.design/products/ultimate-ssg10-vsr10-piston-cylinder-head-kit" target="_blank" rel="noreferrer">AMP / Tridos</a><a href="https://www.grc.nasa.gov/www/k-12/airplane/mflchk.html" target="_blank" rel="noreferrer">${t("Compressible mass flow", "Stlačivi protok")}</a><a href="https://cris.technion.ac.il/en/publications/the-internal-ballistics-of-airguns/" target="_blank" rel="noreferrer">${t("Thermodynamic model reference", "Referenca termodinamičkog modela")}</a></div></section>`;
    const stage = next.querySelector(".stage"), graphs = next.querySelector(".graphs");
    stage.insertAdjacentHTML("afterbegin", `<p class="playback-reference">${p.airbrakeLength === 0 ? t("Reference shot · airbrake off. No pin dimensions are implied for your AMP/SSG10. Enter your measured pin geometry to enable it; the other starting values are illustrative, not a verified rifle setup.", "Referentni hitac · zračna kočnica isključena. Dimenzije pina vašeg AMP/SSG10 nisu pretpostavljene. Unesite izmjerenu geometriju pina za uključivanje; ostale početne vrijednosti su ilustrativne, ne potvrđena konfiguracija replike.") : t("Airbrake active · motion depends on the entered passage, pin, spring and loss assumptions. Internal timing needs experimental validation.", "Zračna kočnica uključena · gibanje ovisi o unesenom kanalu, pinu, opruzi i gubicima. Unutarnji vremenski odnos traži eksperimentalnu provjeru.")}</p>
      ${s.maxPreContactRetreat > .001 ? `<div class="lab-warning" role="status"><strong>${t("Large predicted reversal — check the model inputs", "Velik predviđeni povrat — provjerite ulaze modela")}</strong><p>${t(`The piston travels backward by up to ${fmt(s.maxPreContactRetreat * 1000, 2)} mm BEFORE touching the head. This is pressure-driven motion in this model, not a bumper bounce or a verified SSG10 prediction. Check pin clearance, head passage, spring force and losses. Motion has not been clipped or forced forward.`, `Piston se vraća do ${fmt(s.maxPreContactRetreat * 1000, 2)} mm PRIJE dodira s glavom. To je gibanje zbog tlaka u modelu, ne odskok od odbojnika ni potvrđeno predviđanje SSG10. Provjerite zazor pina, kanal glave, silu opruge i gubitke. Gibanje nije odrezano ni prisiljeno naprijed.`)}</p></div>` : ""}
      <div class="playback-options"><label for="playbackMode">${t("Playback", "Prikaz")}<select id="playbackMode"><option value="focus" ${!playbackUniform ? "selected" : ""}>${t("Firing focus + faster settling", "Fokus opaljenja + brže smirivanje")}</option><option value="uniform" ${playbackUniform ? "selected" : ""}>${t("Uniform full-run slow motion", "Jednoliko usporena cijela simulacija")}</option></select></label><label for="playbackSpeed">${t("Playback speed", "Brzina prikaza")}<select id="playbackSpeed">${[.5, 1, 2].map(v => `<option value="${v}" ${playbackSpeed === v ? "selected" : ""}>${v}×</option>`).join("")}</select></label></div><p id="playbackPhase" class="small-note" aria-live="off"></p>`);
    stage.insertAdjacentHTML("beforeend", `<p class="small-note">${t("Firing focus reserves 80% of playback for the shot and initial muzzle discharge when a long tail remains; it then speeds through the full settling interval. No motion or events are removed. The clock, scrubber and graph axes always use actual model time. The cylinder and head share one axial drawing scale; the barrel has a separate scale.", "Fokus opaljenja odvaja 80% prikaza za hitac i početno pražnjenje kad preostaje dugo smirivanje; zatim ubrzava prikaz cijelog preostalog intervala. Gibanje i događaji nisu uklonjeni. Sat, klizač i osi grafova uvijek koriste stvarno vrijeme modela. Cilindar i glava imaju zajedničko uzdužno mjerilo; cijev ima zasebno mjerilo.")} ${t("Maximum modeled backward travel", "Najveći modelirani povratni pomak")}: ${fmt(s.maxPistonRetreat * 1000, 3, "mm")}; ${t("before first contact", "prije prvog kontakta")}: ${fmt(s.maxPreContactRetreat * 1000, 3, "mm")}.</p>`);
    const compactMetric = (label, value, note) => `<div><span>${label}</span><strong>${value}</strong><small>${note}</small></div>`;
    const summary = [
      compactMetric(t("Predicted exit", "Predviđeni izlazak"), fmt(s.exitEnergy, 3, "J"), `${fmt(fps(s.exitVelocity), 1, "fps")} · ${t("volume ratio", "omjer volumena")} ${fmt(s.ratio, 2)}`),
      compactMetric(t("Piston strike", "Udar pistona"), fmt(s.impactEnergy === null ? null : s.impactEnergy * 1000, 2, "mJ"), s.impactEnergy === null ? t("No contact recorded", "Kontakt nije zabilježen") : p.bumperThickness > 0 ? `${t("Peak modeled force", "Vršna modelirana sila")} ${fmt(s.peakBumperForce, 1, "N")} · ${t("not dB", "nije dB")}` : t("Rigid contact energy · not dB", "Energija krutog kontakta · nije dB")),
      compactMetric(p.silencerEnabled ? t("Silencer outlet", "Izlaz prigušivača") : t("Muzzle pressure", "Tlak na ustima"), p.silencerEnabled ? fmt(s.peakOutflow * 1000, 2, "g/s") : fmt(s.exitPressure === null ? null : (s.exitPressure - s.ambientPressure) / 1e5, 2, "bar(g)"), p.silencerEnabled ? `${t("Peak chamber pressure", "Vršni tlak komore")}: ${fmt((s.peakSilencerPressure - s.ambientPressure) / 1e5, 2, "bar(g)")} · ${t("not dB", "nije dB")}` : `${t("Peak outflow", "Vršni protok")}: ${fmt(s.exitTime === null ? null : s.peakOutflow * 1000, 2, "g/s")}`),
      compactMetric(t("Useful energy → slowing", "Korisna energija → usporavanje"), fmt(delta, 2, "ms"), delta === null ? t("Timing unavailable", "Vrijeme nije dostupno") : delta === 0 ? t("Threshold and slowing coincide", "Prag i usporavanje se podudaraju") : delta > 0 ? t("Threshold reached first", "Prag je dosegnut prvi") : t("Slowing begins first", "Usporavanje počinje prvo"))
    ].join("");
    globalThis.PneumaticWorkspace.prepareResults(next, summary, {
      timingHTML: I.timingMarkup(s, p, t, fmt, stamp),
      explainSound: t("Piston impact & muzzle blast — what do these mean?", "Udar pistona i prasak na ustima — što to znači?"),
      explainFeedback: t("What changed & recommended next steps", "Što se promijenilo i preporučeni sljedeći koraci"),
      live: t("Live values · pressure, velocity & spring", "Vrijednosti uživo · tlak, brzina i opruga"),
      help: t("Playback options & model notes", "Opcije prikaza i napomene modela"),
      flag: `${p.airbrakeLength ? t("Airbrake active", "Zračna kočnica uključena") : t("No-airbrake reference", "Referenca bez kočnice")} · ${p.silencerEnabled ? t("silencer chamber active", "komora prigušivača uključena") : t("direct muzzle", "izravna usta")} · ${t("conditional model, not measured performance", "uvjetni model, ne izmjerene performanse")}`
    }, s.complete ? "" : t("Incomplete run: ", "Nezavršena simulacija: ") + (s.exitTime === null ? t("BB has not exited. ", "BB nije izašao. ") : "") + (s.pistonHitTime === null ? t("Piston contact unknown—not a soft landing.", "Kontakt pistona nepoznat — nije mekan udar.") : ""));
    // Stable panel keys keep conditional warnings from replacing neighboring UI.
    for (const parent of [next, stage]) for (const element of parent.children) {
      if (!element.id && element.className) element.setAttribute("data-view-key", element.className);
    }
    next.querySelectorAll("canvas, #liveStrip, #phaseText, #clock, #playbackPhase").forEach(element => element.setAttribute("data-live", ""));
    setResultState("ready");
    globalThis.PneumaticView.patchChildren($("resultContent"), next);
    workspace?.sync();
    setFrame(fraction);
  }
  function bindLanguage() {
    document.querySelectorAll("[data-lang]").forEach(button => button.addEventListener("click", () => {
      if (busy) return;
      language = button.dataset.lang;
      try { localStorage.setItem("ssg10-pneumatic-lab-language", language); } catch (_) { /* no-op */ }
      if (calculationPending) recalculate();
      render();
    }));
  }
  function recalculate() {
    clearTimeout(debounce);
    if (optimizer?.result && JSON.stringify(p) !== JSON.stringify(optimizer.result.base)) invalidateOptimizer();
    stop(); diagnostic = null; calculationPending = false; chartCache.clear();
    const nextShot = P.simulate(p);
    if (nextShot.valid) {
      const nextComparison = I.comparisonSnapshot(lastValidShot, nextShot);
      if (nextComparison?.changes.length) changeComparison = nextComparison;
      lastValidShot = nextShot;
    }
    shot = nextShot;
    baseline = shot.valid ? P.simulate({ ...p, airbrakeLength: 0, airbrakeTaper: 0 }) : null;
    unsilencedReference = shot.valid && p.silencerEnabled ? P.simulate({ ...p, silencerEnabled: 0 }) : null;
    if (shot.valid) fraction = Math.min(1, playheadTime / shot.duration);
    updateResults();
  }
  function scheduleCalculation() {
    invalidateOptimizer();
    stop(); clearTimeout(debounce);
    calculationPending = true;
    setResultState("pending");
    debounce = setTimeout(recalculate, 140);
  }
  function syncSetupControls() {
    for (const [key, value] of Object.entries(p)) {
      const input = $(key), range = document.querySelector(`[data-range="${key}"]`);
      if (input?.matches("[data-number]")) input.value = finite(value) ? value : "";
      if (range) range.value = finite(value) ? value : 0;
    }
    for (const [id, value] of Object.entries({ platformPreset: selectedPlatform, component, springLabel, pinLabel })) $(id).value = value;
    $("springLengthMode").checked = p.springLengthMode === 1;
    $("silencerEnabled").checked = p.silencerEnabled === 1;
    $("springCurve").value = p.springCurve.map(pair => pair.join(", ")).join("\n");
    $("bumperCurve").value = p.bumperCurve.map(pair => pair.join(", ")).join("\n");
    document.querySelectorAll("[data-provenance]").forEach(box => { box.checked = provenance[box.dataset.provenance] === "measured"; });
    document.querySelectorAll("[data-mass]").forEach(button => button.setAttribute("aria-pressed", String(p.pistonMass === Number(button.dataset.mass))));
    $("measurementConfirm").checked = false;
    syncSpringControls(); syncBumperControls(); syncSilencerControls();
  }
  function bindFieldHelp() {
    const place = button => {
      const tooltip = $(button.dataset.fieldInfo);
      if (!tooltip) return;
      const margin = 12, gap = 9, width = Math.min(340, Math.max(160, window.innerWidth - margin * 2));
      tooltip.style.width = `${width}px`;
      const trigger = button.getBoundingClientRect(), height = tooltip.getBoundingClientRect().height;
      const left = Math.max(margin, Math.min(window.innerWidth - width - margin, trigger.right - width));
      const below = trigger.bottom + gap;
      const opensAbove = below + height > window.innerHeight - margin && trigger.top - height - gap >= margin;
      tooltip.style.left = `${left}px`;
      const maximumTop = Math.max(margin, window.innerHeight - height - margin);
      tooltip.style.top = `${opensAbove ? trigger.top - height - gap : Math.max(margin, Math.min(below, maximumTop))}px`;
      tooltip.dataset.side = opensAbove ? "above" : "below";
    };
    document.querySelectorAll("[data-field-info]").forEach(button => {
      button.addEventListener("pointerenter", () => place(button));
      button.addEventListener("focus", () => place(button));
      button.addEventListener("click", () => place(button));
      button.addEventListener("keydown", event => {
        if (event.key === "Escape") button.blur();
      });
    });
  }
  function bindControls() {
    $("toggleControls").addEventListener("click", e => { const closed = document.querySelector(".controls-panel").classList.toggle("is-collapsed"); e.currentTarget.setAttribute("aria-expanded", String(!closed)); });
    document.querySelectorAll("[data-number], [data-range]").forEach(input => input.addEventListener("input", () => {
      const key = input.dataset.number || input.dataset.range;
      const previous = p[key];
      p[key] = input.value === "" ? NaN : Number(input.value);
      if (optimizer && optimizer.values[key] === String(previous)) optimizer.values[key] = String(p[key]);
      const pair = input.dataset.number ? document.querySelector(`[data-range="${key}"]`) : $(key);
      pair.value = input.value;
      selectedPlatform = "custom"; $("platformPreset").value = "custom";
      if (key.startsWith("airbrake")) { pinLabel = p.airbrakeLength > 0 ? "custom" : "plug"; $("pinLabel").value = pinLabel; }
      if (key.startsWith("spring")) { provenance.spring = "assumed"; invalidateFit(); }
      else if (["cylinderBore", "strokeLength", "barrelLength", "barrelDiameter", "frontDeadVolume", "pistonMass", "bbMass", "bbDiameter", "headBore", "headLength", "nozzleBore", "nozzleLength", "bumperThickness", "bumperBore", "bumperStiffness", "bumperDamping", "bumperMaxCompression", "restitution", "airbrakeLength", "airbrakeDiameter", "airbrakeTipDiameter", "airbrakeTaper", "deadVolume", "breechVolume", "silencerLength", "silencerInnerDiameter", "silencerBaffleCount", "silencerBaffleThickness", "silencerBaffleBore", "silencerEndCapBore", "silencerPackingFraction", "silencerDischargeCoefficient", "silencerHeatTransfer"].includes(key)) provenance.geometry = "assumed";
      document.querySelectorAll("[data-provenance]").forEach(box => { box.checked = provenance[box.dataset.provenance] === "measured"; });
      $("measurementConfirm").checked = false;
      document.querySelectorAll("[data-mass]").forEach(button => button.setAttribute("aria-pressed", Number(button.dataset.mass) === p.pistonMass));
      syncSpringControls(); syncBumperControls(); syncSilencerControls(); scheduleCalculation();
    }));
    document.querySelectorAll("[data-provenance]").forEach(box => box.addEventListener("change", () => { provenance[box.dataset.provenance] = box.checked ? "measured" : "assumed"; }));
    document.querySelectorAll("[data-mass]").forEach(button => button.addEventListener("click", () => { $("pistonMass").value = button.dataset.mass; $("pistonMass").dispatchEvent(new Event("input", { bubbles: true })); }));
    $("springLengthMode").addEventListener("change", e => {
      p.springLengthMode = e.target.checked ? 1 : 0;
      provenance.spring = "assumed"; document.querySelector('[data-provenance="spring"]').checked = false;
      $("measurementConfirm").checked = false; selectedPlatform = "custom"; $("platformPreset").value = "custom";
      invalidateFit(); syncSpringControls(); scheduleCalculation();
    });
    $("silencerEnabled").addEventListener("change", e => {
      p.silencerEnabled = e.target.checked ? 1 : 0;
      provenance.geometry = "assumed"; document.querySelectorAll('[data-provenance="geometry"]').forEach(box => { box.checked = false; });
      $("measurementConfirm").checked = false; selectedPlatform = "custom"; $("platformPreset").value = "custom";
      invalidateFit(); syncSilencerControls(); scheduleCalculation();
    });
    $("platformPreset").addEventListener("change", event => {
      selectedPlatform = event.target.value;
      const v = platforms[selectedPlatform];
      if (v) {
        p = P.normalize({ cylinderBore: Math.sqrt(v.volume * 1000 / v.stroke / Math.PI) * 2, strokeLength: v.stroke, barrelLength: v.barrel, barrelDiameter: v.bore, pistonMass: v.mass });
        component = selectedPlatform.startsWith("ssg10") ? "amp" : "custom";
        if (component !== "amp") { p.airbrakeLength = 0; p.airbrakeTaper = 0; }
        provenance = { geometry: "assumed", spring: "assumed" }; pinLabel = "plug"; springLabel = "unspecified"; fit = null;
      }
      invalidateFit(); syncSetupControls(); recalculate();
    });
    $("component").addEventListener("change", e => { component = e.target.value; provenance.geometry = "assumed"; document.querySelector('[data-provenance="geometry"]').checked = false; $("measurementConfirm").checked = false; });
    $("springLabel").addEventListener("change", e => { springLabel = e.target.value; provenance.spring = "assumed"; document.querySelector('[data-provenance="spring"]').checked = false; $("measurementConfirm").checked = false; });
    $("pinLabel").addEventListener("change", e => {
      pinLabel = e.target.value; provenance.geometry = "assumed";
      if (pinLabel === "plug") { p.airbrakeLength = 0; p.airbrakeTaper = 0; syncSetupControls(); recalculate(); }
      else { document.querySelector('[data-provenance="geometry"]').checked = false; $("measurementConfirm").checked = false; setStatus("Pin label recorded. Enter its measured projection, diameter and assembled mass; no undocumented dimensions were assigned.", "Oznaka pina je zabilježena. Unesite izmjereno izbočenje, promjer i masu sklopa; nisu dodijeljene nepoznate dimenzije."); }
    });
    $("springCurve").addEventListener("change", e => {
      p.springCurve = parseCurveText(e.target.value);
      provenance.spring = "assumed"; document.querySelector('[data-provenance="spring"]').checked = false; $("measurementConfirm").checked = false; invalidateFit(); syncSpringControls(); scheduleCalculation();
    });
    $("bumperCurve").addEventListener("change", e => {
      p.bumperCurve = parseCurveText(e.target.value);
      provenance.geometry = "assumed"; document.querySelector('[data-provenance="geometry"]').checked = false; $("measurementConfirm").checked = false;
      invalidateFit(); syncBumperControls(); scheduleCalculation();
    });
    const energyReadout = () => { $("measurementEnergy").textContent = `${t("Derived energy", "Izvedena energija")}: ${fmt(C.energy(Number($("measurementMass").value), Number($("measurementFps").value)), 3, "J")}`; };
    $("measurementMass").addEventListener("input", energyReadout); $("measurementFps").addEventListener("input", energyReadout); energyReadout();
    $("measurementForm").addEventListener("submit", event => {
      event.preventDefault();
      if (busy) return;
      if (measurements.length >= 2000) { setStatus("Dataset limit: 2,000 shots. Export a backup before removing records.", "Ograničenje: 2000 hitaca. Izvezite sigurnosnu kopiju prije uklanjanja zapisa."); return; }
      const confirmed = $("measurementConfirm").checked, mass = Number($("measurementMass").value);
      if (confirmed && P.validate({ ...p, bbMass: mass }).length) { setStatus("Correct invalid setup inputs before recording a confirmed shot.", "Ispravite nevaljane ulaze prije spremanja potvrđenog hica."); return; }
      const row = C.cleanRecord({ id: `shot-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, bbMass: mass, fps: Number($("measurementFps").value), sigma: Number($("measurementSigma").value),
        pistonHitMs: $("measurementHitMs").value, peakCylinderBarG: $("measurementPressure").value, peakSilencerBarG: $("measurementSilencerPressure").value, peakBumperForceN: $("measurementBumperForce").value,
        setup: confirmed ? { ...clone(p), bbMass: mass } : null, confirmed, provenance: clone(provenance), role: $("measurementRole").value, solverVersion: P.VERSION,
        notes: `${component} / ${pinLabel} / ${springLabel}. ${$("measurementNotes").value}` });
      if (!row) return;
      measurements.push(row); invalidateFit(); save(); renderMeasurements(); setStatus("Shot saved; previous fit cleared. Only eligible training shots enter a fit; setup metadata remains attached to this record.", "Hitac je spremljen; prethodna prilagodba poništena je. Samo prikladni podaci ulaze u prilagodbu; konfiguracija ostaje pridružena zapisu.");
    });
    document.querySelectorAll("[data-fit-parameter]").forEach(box => box.addEventListener("change", () => {
      const selected = [...document.querySelectorAll("[data-fit-parameter]:checked")].map(input => input.dataset.fitParameter);
      if (selected.length > 3) { box.checked = false; setStatus("Select no more than three fitted parameters.", "Odaberite najviše tri parametra za prilagodbu."); return; }
      fitSelection = selected; invalidateFit();
    }));
    $("exportMeasurements").addEventListener("click", () => download("airsoft-chrono-data.json", { ...C.encode(measurements), lastFit: fit }));
    $("importMeasurements").addEventListener("change", async e => {
      if (busy || !e.target.files[0]) return;
      try {
        const file = e.target.files[0]; if (file.size > 8e6) throw new Error("size");
        const data = C.decode(await file.text());
        if (measurements.length + data.measurements.length > 2000) throw new Error("record limit");
        const ids = new Set(measurements.map(r => r.id));
        for (const row of data.measurements) { if (ids.has(row.id)) row.id += `-import-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`; measurements.push(row); ids.add(row.id); }
        invalidateFit(); save(); renderMeasurements(); setStatus(`Imported ${data.measurements.length} shots. Existing data was kept; previous fit cleared; legacy records are unverified references.`, `Uvezeno je ${data.measurements.length} hitaca. Postojeći podaci sačuvani su; prethodna prilagodba poništena je; stari zapisi ostaju nepotvrđene reference.`);
      } catch (_) { setStatus("Import rejected: invalid JSON, unsupported records, file too large or 2,000-shot limit exceeded. Existing data was not changed.", "Uvoz odbijen: nevaljan JSON, nepodržani zapisi, prevelika datoteka ili više od 2000 hitaca. Postojeći podaci nisu promijenjeni."); }
    });
    $("fitButton").addEventListener("click", async () => {
      if (busy) return;
      stop(); clearTimeout(debounce);
      if (calculationPending) recalculate();
      if (!fitSelection.length) { setStatus("Select at least one parameter to fit.", "Odaberite barem jedan parametar za prilagodbu."); return; }
      setBusy(true); setStatus("Fitting selected parameters. Results remain conditional on the measured observables and model structure…", "Prilagođavanje odabranih parametara. Rezultati ostaju uvjetovani izmjerenim veličinama i strukturom modela…");
      try {
        fit = await C.fitParameters(clone(measurements), fitSelection, n => setStatus(`Evaluating fit ${n}…`, `Provjera prilagodbe ${n}…`));
        const fitted = Object.entries(fit.parameters).map(([key, value]) => `${fields[key]?.[language === "hr" ? 1 : 0] || key} = ${value.toPrecision(5)}`).join(" · ");
        const en = `${fitted}. Training RMSE ${fmt(fit.training.rmse, 2)} fps (${fit.training.count} shots, ${fit.training.observations} observables, ${fit.distinctTrainingSetups} distinct setups). Held-out RMSE ${fmt(fit.validation.rmse, 2)} fps (${fit.validation.count} shots; ${fit.validation.failures} failed predictions).${fit.boundReached ? " Parameter bound reached." : ""}${fit.weaklyConstrained ? " Parameters are weakly constrained; do not extrapolate." : ""}`;
        const hr = `${fitted}. RMSE prilagodbe ${fmt(fit.training.rmse, 2)} fps (${fit.training.count} hitaca, ${fit.training.observations} opažanja, ${fit.distinctTrainingSetups} različitih konfiguracija). Neovisni RMSE ${fmt(fit.validation.rmse, 2)} fps (${fit.validation.count} hitaca; ${fit.validation.failures} neuspjelih predviđanja).${fit.boundReached ? " Dosegnuta granica parametra." : ""}${fit.weaklyConstrained ? " Parametri su slabo određeni; nemojte ekstrapolirati." : ""}`;
        setStatus(en, hr);
        $("fitReport").innerHTML = `<button class="secondary-button" type="button" id="applyFit">${t("Apply fitted parameters to current setup", "Primijeni prilagođene parametre na trenutačnu konfiguraciju")}</button>`;
        $("applyFit").addEventListener("click", () => { for (const [key, value] of Object.entries(fit.parameters)) p[key] = value; syncSetupControls(); $("measurementConfirm").checked = false; recalculate(); });
      } catch (error) {
        const messages = {
          "fit:too-many-configurations": ["Fit limit: 32 distinct configurations per dataset.", "Ograničenje prilagodbe: 32 različite konfiguracije po skupu."],
          "fit:not-identifiable": ["Not enough distinct training configurations for the selected number of parameters.", "Nema dovoljno različitih konfiguracija za odabrani broj parametara."],
          "fit:parameters": ["Select between one and three supported parameters.", "Odaberite jedan do tri podržana parametra."],
          "fit:silencer-disabled": ["Silencer outlet Cd needs at least one eligible training setup with that silencer installed.", "Cd izlaza prigušivača traži barem jednu prikladnu konfiguraciju za prilagodbu s ugrađenim prigušivačem."],
          "fit:measured-spring": ["Spring stiffness cannot be fitted while a measured force curve is active.", "Krutost opruge ne može se prilagođavati dok je aktivna izmjerena krivulja sile."],
          "fit:measured-bumper": ["Bumper stiffness cannot be fitted while a measured bumper force curve is active.", "Krutost gumice ne može se prilagođavati dok je aktivna izmjerena krivulja sile gumice."]
        };
        setStatus(...(messages[error.message] || ["Fit unavailable: add eligible measured training data whose simulations produce valid exits.", "Prilagodba nije dostupna: dodajte prikladne izmjerene podatke čije simulacije daju valjan izlazak."]));
      }
      finally { setBusy(false); }
    });
  }
  function renderMeasurements() {
    if (!$("measurementRows")) return;
    $("measurementRows").innerHTML = measurements.map((r, i) => `<tr><td>${fmt(r.bbMass, 2, "g")}</td><td>${fmt(r.fps, 1)} / ${fmt(C.energy(r.bbMass, r.fps), 3)}${Number.isFinite(r.pistonHitMs) ? `<br><small>${t("contact", "kontakt")} ${fmt(r.pistonHitMs, 2, "ms")}</small>` : ""}${Number.isFinite(r.peakCylinderBarG) ? `<br><small>${t("peak cylinder", "vršni tlak cilindra")} ${fmt(r.peakCylinderBarG, 2, "bar(g)")}</small>` : ""}${Number.isFinite(r.peakSilencerBarG) ? `<br><small>${t("peak silencer", "vršni tlak prigušivača")} ${fmt(r.peakSilencerBarG, 2, "bar(g)")}</small>` : ""}${Number.isFinite(r.peakBumperForceN) ? `<br><small>${t("peak bumper force", "vršna sila gumice")} ${fmt(r.peakBumperForceN, 1, "N")}</small>` : ""}</td><td>${r.role === "train" ? t("Training", "Prilagodba") : r.role === "validation" ? t("Held-out", "Neovisna provjera") : t("Reference only", "Samo referenca")}<br><small>${C.eligible(r) ? t("Measured inputs confirmed", "Izmjereni ulazi potvrđeni") : t("Not fit-eligible", "Nije prikladno za prilagodbu")}${r.setup ? ` · ${fmt(r.setup.pistonMass, 1, "g")} / ${fmt(r.setup.barrelLength, 0, "mm")}` : ` · ${t("setup incomplete", "nepotpuna konfiguracija")}`}</small></td><td>${esc(r.notes)}</td><td><button type="button" class="danger-button" data-remove="${i}" aria-label="${t("Remove shot", "Ukloni hitac")} ${i + 1}">×</button></td></tr>`).join("");
    document.querySelectorAll("[data-remove]").forEach(button => button.addEventListener("click", () => {
      if (busy) return;
      const i = Number(button.dataset.remove);
      if (!confirm(t("Remove this measurement from browser storage? Export first if you need a backup.", "Ukloniti ovo mjerenje iz pohrane preglednika? Najprije izvezite podatke ako trebate kopiju."))) return;
      measurements.splice(i, 1); invalidateFit(); save(); renderMeasurements(); setStatus("Measurement removed from browser storage; previous fit cleared. An earlier export can restore the measurement.", "Mjerenje je uklonjeno iz pohrane preglednika; prethodna prilagodba poništena je. Mjerenje se može vratiti iz ranijeg izvoza.");
    }));
  }
  function setBusy(value) {
    busy = value;
    document.querySelectorAll("button, input, select, textarea").forEach(el => { if (value) { el.dataset.preDisabled = el.disabled ? "1" : "0"; el.disabled = true; } else { el.disabled = el.dataset.preDisabled === "1"; delete el.dataset.preDisabled; } });
    if (!value && location.hash !== "#pneumatic-timing") render();
  }
  function download(name, data) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }), url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function startPlayback() {
    if (calculationPending || !shot?.valid || busy) return;
    if (fraction > .999) fraction = 0;
    playing = true; $("playButton").textContent = t("Pause", "Pauza");
    const timeline = B.timeline(shot, playbackUniform), screenMs = 8000 / playbackSpeed;
    const start = performance.now() - timeline.progressAt(fraction * shot.duration) * screenMs;
    function tick(now) {
      if (!playing) return;
      const progress = Math.min(1, (now - start) / screenMs);
      setFrame(timeline.timeAt(progress) / shot.duration);
      if (progress >= 1) stop(); else animation = requestAnimationFrame(tick);
    }
    animation = requestAnimationFrame(tick);
  }
  function bindResults() {
    // One delegated handler per event, installed only when the shell mounts.
    const results = $("results");
    results.onclick = event => {
      if (calculationPending || !shot?.valid || busy) return;
      const button = event.target.closest("button");
      if (!button || button.disabled || !results.contains(button)) return;
      if (button.dataset.impactTime !== undefined) {
        const time = Number(button.dataset.impactTime);
        if (Number.isFinite(time)) { stop(); setFrame(time / shot.duration); }
      } else if (button.dataset.event) {
        const time = shot[button.dataset.event];
        if (time !== null) { stop(); setFrame(time / shot.duration); }
      } else if (button.id === "playButton") { if (playing) stop(); else startPlayback(); }
      else if (button.id === "resetButton") { stop(); setFrame(0); }
      else if (button.id === "convergenceButton") runDiagnostic("convergence");
      else if (button.id === "sensitivityButton") runDiagnostic("sensitivity");
      else if (button.id === "explainSound") {
        stop(); workspace.selectView("details"); $("workspaceBody").scrollTop = 0;
        $("soundExplanations").focus({ preventScroll: true });
        if (window.innerWidth <= 960) $("previewPanel").scrollIntoView({ block: "start" });
      }
      else if (button.id === "explainFeedback") {
        stop(); workspace.selectView("details"); $("setupFeedback").focus({ preventScroll: true });
        $("setupFeedback").scrollIntoView({ block: "start" });
        if (window.innerWidth <= 960) $("previewPanel").scrollIntoView({ block: "start" });
      }
      else if (button.dataset.feedbackCategory) {
        stop(); workspace.selectCategory(button.dataset.feedbackCategory);
        document.querySelector(".controls-panel").classList.remove("is-collapsed"); $("toggleControls").setAttribute("aria-expanded", "true");
        if (window.innerWidth <= 960) $("settingsPanel").scrollIntoView({ block: "start" });
      }
      else if (button.dataset.feedbackView) {
        stop(); workspace.selectView(button.dataset.feedbackView);
      }
      else if (button.id === "exportRun") download("airsoft-pneumatic-run.json", { schemaVersion: 4, solverVersion: P.VERSION, identity: { selectedPlatform, component, springLabel, pinLabel }, provenance, setup: p, result: shot, baseline: { exitEnergy: baseline?.exitEnergy ?? null, impactEnergy: baseline?.impactEnergy ?? null, unsilencedPeakOutflow: unsilencedReference?.peakOutflow ?? null }, limitations: "Unvalidated lumped control-volume model with optional silencer chamber and a causal wave-travel envelope; not a baffle-resolved CFD/acoustic solution and not exact joules or dB; see docs/MODEL.md" });
    };
    results.oninput = event => {
      if (calculationPending || !shot?.valid || busy) return;
      if (event.target.id === "scrubber") { stop(); setFrame(Number(event.target.value) / 1000); }
    };
    results.onchange = event => {
      if (calculationPending || !shot?.valid || busy) return;
      if (event.target.id === "playbackMode") { stop(); playbackUniform = event.target.value === "uniform"; setFrame(fraction); }
      if (event.target.id === "playbackSpeed") { stop(); playbackSpeed = Number(event.target.value); }
    };
  }
  async function runDiagnostic(mode) {
    if (busy || calculationPending || !shot?.valid) return;
    stop(); setBusy(true);
    $("diagnosticReport").textContent = t("Computing diagnostic runs…", "Računanje provjernih simulacija…");
    const setup = clone(p), original = shot;
    await new Promise(resolve => setTimeout(resolve, 20));
    try {
      if (mode === "convergence") {
        const a = P.simulate(setup, { dt: 5e-6, tolerance: 5e-6 }), b = P.simulate(setup, { dt: 2.5e-6, tolerance: 1.25e-6 });
        const difference = (one, two, k, scale = 1) => one.valid && two.valid && one[k] !== null && two[k] !== null ? Math.abs(one[k] - two[k]) * scale : null;
        const dv = difference(a, b, "exitVelocity"), dt = difference(a, b, "exitTime", 1000), contact = difference(a, b, "impactEnergy", 1000);
        diagnostic = [
          `Between 5 and 2.5 μs limits: speed Δ ${fmt(dv, 4, "m/s")}; exit time Δ ${fmt(dt, 4, "ms")}; contact energy Δ ${fmt(contact, 4, "mJ")}. Energy residuals: ${[original, a, b].map(s => fmt(s.energyResidual * 1000, 4)).join(" / ")} mJ. Missing events stay unavailable. Numerical convergence is not experimental validation.`,
          `Između ograničenja 5 i 2,5 μs: brzina Δ ${fmt(dv, 4, "m/s")}; vrijeme izlaska Δ ${fmt(dt, 4, "ms")}; energija kontakta Δ ${fmt(contact, 4, "mJ")}. Odstupanja energije: ${[original, a, b].map(s => fmt(s.energyResidual * 1000, 4)).join(" / ")} mJ. Nedostajući događaji nisu dostupni. Numerička konvergencija nije eksperimentalna potvrda.`
        ];
      } else {
        const runs = [];
        for (const head of [-.02, .02]) for (const pin of [-.02, .02]) for (const spring of [.95, 1.05]) {
          runs.push(P.simulate({ ...setup, headBore: setup.headBore + head, airbrakeDiameter: setup.airbrakeDiameter + pin, springStiffness: setup.springStiffness * spring, springCurve: setup.springCurve.map(([x, f]) => [x, f * spring]) }, { sampleInterval: 1 }));
          await new Promise(resolve => setTimeout(resolve, 0));
        }
        const speeds = runs.filter(s => s.valid && s.exitVelocity !== null).map(s => fps(s.exitVelocity));
        const margins = runs.filter(s => s.valid && s.usefulTime !== null && s.strongBrakeTime !== null).map(s => (s.strongBrakeTime - s.usefulTime) * 1000);
        const range = (values, unit) => values.length ? `${fmt(Math.min(...values), 2)} … ${fmt(Math.max(...values), 2, unit)}` : "—";
        diagnostic = [
          `Eight-corner sensitivity: exit speed ${range(speeds, "fps")}; energy-threshold → slowing margin ${range(margins, "ms")}. ${8 - speeds.length} cases had no valid exit; ${8 - margins.length} had no comparable timing events. These ranges are not confidence intervals and do not include model-form error.`,
          `Osjetljivost u osam rubnih kombinacija: izlazna brzina ${range(speeds, "fps")}; razmak prag energije → usporavanje ${range(margins, "ms")}. ${8 - speeds.length} slučajeva bez valjanog izlaska; ${8 - margins.length} bez usporedivih događaja. Rasponi nisu intervali pouzdanosti i ne uključuju pogrešku fizikalnog modela.`
        ];
      }
      if ($("diagnosticReport")) $("diagnosticReport").textContent = t(...diagnostic);
    } finally { setBusy(false); }
  }
  function stop() { playing = false; cancelAnimationFrame(animation); if ($("playButton")) $("playButton").textContent = t("Fire / play", "Opali / pokreni"); }
  function atTime(time) {
    return B.frameAt(shot, time);
  }
  function setFrame(next) {
    if (calculationPending || !shot?.valid || !$("mechanism")) return;
    fraction = Math.max(0, Math.min(1, next));
    const f = atTime(shot.duration * fraction);
    playheadTime = f.t;
    $("scrubber").value = fraction * 1000; $("clock").textContent = stamp(f.t);
    const timeline = B.timeline(shot, playbackUniform);
    $("playbackPhase").textContent = playbackUniform || timeline.split === 1 ? t("Uniform slow motion · clock shows actual model time", "Jednoliko usporeno · sat prikazuje stvarno vrijeme modela") : f.t <= timeline.focusEnd ? t("Firing focus · slower playback", "Fokus opaljenja · sporiji prikaz") : t("Post-exit settling · faster playback, no states removed", "Smirivanje nakon izlaska · brži prikaz, bez uklanjanja stanja");
    const parts = [];
    if (f.t === 0) parts.push(t("Spring held; gas at atmospheric pressure.", "Opruga zapeta; plin na atmosferskom tlaku."));
    else {
      if (f.pistonV < -.005) parts.push(f.pistonHit ? t("Modeled reverse motion after head contact.", "Modelirano povratno gibanje nakon kontakta s glavom.") : t("Modeled pressure-driven reversal before head contact; not verified rifle behavior.", "Modelirani povrat zbog tlaka prije kontakta s glavom; nije potvrđeno gibanje replike."));
      else if (f.pistonV > .02) parts.push(f.pistonA < 0 ? t("Piston decelerating.", "Piston usporava.") : t("Spring releasing; piston accelerating.", "Opruga se otpušta; piston ubrzava."));
      else parts.push(t("Piston at rest or turning.", "Piston miruje ili mijenja smjer."));
      if (f.insertion > 0) {
        const overlap = f.insertion * 1000;
        if (p.bumperThickness > 0 && overlap <= p.bumperThickness + 1e-6) parts.push(t("Pin is inside the bumper opening only; it has not entered the metal head bore.", "Pin je samo u otvoru gumice; nije ušao u metalni provrt glave."));
        else if (overlap <= p.bumperThickness + p.headLength + 1e-6) parts.push(t("Pin has entered the metal head bore; pressure difference and local clearance set airflow.", "Pin je ušao u metalni provrt glave; razlika tlaka i lokalni zazor određuju protok."));
        else parts.push(t("Pin reaches the nozzle segment; all overlapped passages contribute to flow resistance.", "Pin doseže segment mlaznice; svi preklopljeni kanali doprinose otporu protoku."));
      }
      if (f.bbExited) parts.push(p.silencerEnabled ? t("BB has left the inner barrel; gas expands into the silencer and exits through its end cap.", "BB je napustio unutarnju cijev; plin se širi u prigušivač i izlazi kroz završnu kapu.") : t("BB has exited; gas continues to flow through the muzzle.", "BB je izašao; plin se nastavlja prazniti kroz usta cijevi."));
      else if (Math.abs(f.bbV) < .01) parts.push(t("BB held or stalled.", "BB zadržan ili zaustavljen."));
      else parts.push(f.bbA >= 0 ? t("BB gaining speed in the barrel.", "BB ubrzava u cijevi.") : t("BB losing speed in the barrel.", "BB usporava u cijevi."));
      if (f.bumperCompression > 0) parts.push(t(`The bumper is compressed by ${fmt(f.bumperCompression * 1000, 3)} mm and applies ${fmt(f.bumperForce, 1)} N in the entered contact model.`, `Gumica je stisnuta ${fmt(f.bumperCompression * 1000, 3)} mm i djeluje silom ${fmt(f.bumperForce, 1)} N u unesenom modelu kontakta.`));
      else if (f.pistonHit) parts.push(p.bumperThickness > 0 ? t("The piston has reached the bumper; the pad is no longer compressed at this frame.", "Piston je dosegnuo gumicu; u ovom kadru gumica više nije stisnuta.") : t("First rigid-head contact has occurred.", "Dogodio se prvi kontakt s krutom glavom."));
    }
    $("phaseText").textContent = parts.join(" ");
    const liveValues = [
      [t("Cylinder / behind / ahead pressure", "Tlak cilindra / iza / ispred BB-a"), `${fmt((f.cylinderPressure - shot.ambientPressure) / 1e5, 2)} / ${fmt((f.pressure - shot.ambientPressure) / 1e5, 2)} / ${fmt((f.frontPressure - shot.ambientPressure) / 1e5, 2, "bar(g)")}`],
      [t("Piston velocity", "Brzina pistona"), fmt(f.pistonV, 2, "m/s")],
      [t("Piston travel / bumper contact", "Pomak pistona / kontakt s gumicom"), `${fmt(f.pistonX * 1000, 2)} / ${fmt(shot.stroke * 1000, 1, "mm")}`],
      [t("Bumper compression / force", "Stlačenje gumice / sila"), `${fmt(f.bumperCompression * 1000, 3)} / ${fmt(f.bumperForce, 1, "N")}`],
      [t("Piston momentum", "Količina gibanja pistona"), fmt(f.pistonV * p.pistonMass / 1000, 3, "kg·m/s")],
      [t("BB velocity", "Brzina BB-a"), fmt(f.bbV, 2, "m/s")],
      [t("BB acceleration", "Ubrzanje BB-a"), fmt(f.bbA, 0, "m/s²")],
      [t("Head airflow", "Protok kroz glavu"), fmt(f.flow * 1000, 3, "g/s")],
      [t("Silencer pressure / outlet flow", "Tlak prigušivača / izlazni protok"), p.silencerEnabled ? `${fmt((f.silencerPressure - shot.ambientPressure) / 1e5, 2, "bar(g)")} / ${fmt(f.silencerOutflow * 1000, 3, "g/s")}` : t("inactive", "neaktivno")],
      [t("Spring compression", "Stlačenje opruge"), fmt(P.springState(p).cockedCompression - f.pistonX * 1000, 1, "mm")],
      [t("Spring force", "Sila opruge"), fmt(P.springForce(p, f.pistonX), 2, "N")]
    ];
    if (!$("liveStrip").firstChild) $("liveStrip").innerHTML = liveValues.map(() => '<div class="live-item"><span></span><strong></strong></div>').join("");
    liveValues.forEach(([label, value], index) => {
      const item = $("liveStrip").children[index];
      if (item.firstChild.textContent !== label) item.firstChild.textContent = label;
      if (item.lastChild.textContent !== value) item.lastChild.textContent = value;
    });
    if (workspaceState.view === "shot") drawMechanism(f, "mechanism");
    if (workspaceState.view === "graphs") { drawMechanism(f, "mechanismGraph"); drawCharts(f.t); drawImpactChart("impactGraph", f.t); }
    if (workspaceState.view === "details") drawImpactChart("impactResultsChart", f.t);
  }
  function canvasContext(id, fallbackWidth = 900, fallbackHeight = 300) {
    const canvas = $(id), rect = canvas.getBoundingClientRect(), w = rect.width || fallbackWidth, h = rect.height || fallbackHeight, dpr = Math.min(devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) { canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); }
    const ctx = canvas.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h); return { ctx, w, h };
  }
  function drawMechanism(f, canvasId = "mechanism") {
    const { ctx, w, h } = canvasContext(canvasId);
    globalThis.PneumaticAnimation.draw(ctx, w, h, p, shot, f, t, fmt);
  }
  function drawCharts(time) {
    const traces = [
      ["pressureChart", [[f => (f.cylinderPressure - shot.ambientPressure) / 1e5, "#ffbf69"], [f => (f.pressure - shot.ambientPressure) / 1e5, "#5de4e7"], [f => (f.frontPressure - shot.ambientPressure) / 1e5, "#b99cff"], ...(p.silencerEnabled ? [[f => (f.silencerPressure - shot.ambientPressure) / 1e5, "#6ee7a8"]] : []), [f => (f.wavePressureEstimate - shot.ambientPressure) / 1e5, "#8da2ff", [5, 4]]]],
      ["pistonChart", [[f => f.pistonV, "#ffbf69"]]], ["bbChart", [[f => f.bbV, "#5de4e7"]]]
    ];
    for (const [id, series] of traces) {
      const { ctx, w, h } = canvasContext(id, 300, 200), left = 44, right = w - 12, top = 18, bottom = h - 28;
      let cached = chartCache.get(id);
      if (!cached || cached.w !== w || cached.h !== h || cached.shot !== shot || cached.dpr !== devicePixelRatio) {
      let lo = 0, hi = 0;
      for (const [value] of series) for (const f of shot.frames) { const v = value(f); lo = Math.min(lo, v); hi = Math.max(hi, v); }
      const span = Math.max(.1, hi - lo); lo -= span * .06; hi += span * .08;
      const x = v => left + v / shot.duration * (right - left), y = v => bottom - (v - lo) / (hi - lo) * (bottom - top);
      ctx.font = "12px ui-monospace, monospace"; ctx.textAlign = "right";
      for (let i = 0; i < 4; i++) { const v = lo + (hi - lo) * i / 3, yy = y(v); ctx.strokeStyle = "#28343c"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(left, yy); ctx.lineTo(right, yy); ctx.stroke(); ctx.fillStyle = "#91a0a7"; ctx.fillText(v.toFixed(hi > 20 ? 0 : 1), left - 6, yy + 4); }
      ctx.strokeStyle = "#62757d"; ctx.beginPath(); ctx.moveTo(left, y(0)); ctx.lineTo(right, y(0)); ctx.stroke();
      ctx.save(); ctx.beginPath(); ctx.rect(left, top, right - left, bottom - top); ctx.clip();
      for (const [get, color, dash] of series) { ctx.strokeStyle = color; ctx.lineWidth = 1.6; ctx.setLineDash(dash || []); ctx.beginPath(); shot.frames.forEach((f, i) => { if (i) ctx.lineTo(x(f.t), y(get(f))); else ctx.moveTo(x(f.t), y(get(f))); }); ctx.stroke(); }
      ctx.setLineDash([]);
      for (const [key, color] of [["usefulTime", "#6ee7a8"], ["strongBrakeTime", "#ffbf69"], ["exitTime", "#5de4e7"]]) {
        if (shot[key] === null) continue;
        ctx.strokeStyle = color; ctx.lineWidth = 1.2; ctx.setLineDash(key === "strongBrakeTime" ? [4, 4] : [2, 3]); ctx.beginPath(); ctx.moveTo(x(shot[key]), top); ctx.lineTo(x(shot[key]), bottom); ctx.stroke();
      }
      ctx.setLineDash([]); ctx.restore();
      ctx.textAlign = "left"; ctx.fillStyle = "#91a0a7"; ctx.fillText("0", left, h - 7); ctx.textAlign = "right"; ctx.fillText(`${(shot.duration * 1000).toFixed(0)} ms`, right, h - 7);
      const bitmap = document.createElement("canvas");
      bitmap.width = $(id).width; bitmap.height = $(id).height;
      bitmap.getContext("2d").drawImage($(id), 0, 0);
      cached = { bitmap, w, h, shot, dpr: devicePixelRatio }; chartCache.set(id, cached);
      } else ctx.drawImage(cached.bitmap, 0, 0, w, h);
      const cursor = left + time / shot.duration * (right - left);
      ctx.save(); ctx.beginPath(); ctx.rect(left, top, right - left, bottom - top); ctx.clip();
      ctx.strokeStyle = "#fff"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(cursor, top); ctx.lineTo(cursor, bottom); ctx.stroke(); ctx.restore();
    }
  }
  function drawImpactChart(id, time) {
    const canvas = $(id);
    if (!canvas) return;
    const { ctx, w, h } = canvasContext(id, 900, 220), summary = I.impactSummary(shot), impacts = summary.impacts;
    const left = 58, right = w - 18, top = 24, bottom = h - 34, plotWidth = Math.max(1, right - left), plotHeight = Math.max(1, bottom - top);
    ctx.font = "11px ui-monospace, monospace";
    if (!impacts.length) {
      ctx.fillStyle = "#91a0a7"; ctx.textAlign = "center";
      ctx.fillText(t("No piston contact recorded", "Kontakt pistona nije zabilježen"), w / 2, h / 2);
      return;
    }
    const firstTime = impacts[0].time, lastTime = impacts.at(-1).time;
    const eventSpan = Math.max(0, lastTime - firstTime), padding = eventSpan > 0 ? Math.max(.00008, eventSpan * .16) : .00075;
    const startTime = Math.max(0, firstTime - padding), endTime = Math.min(shot.duration, Math.max(firstTime + padding, lastTime + padding));
    const timeSpan = Math.max(1e-9, endTime - startTime), maxEnergy = Math.max(...impacts.map(event => event.pistonEnergy * 1000), 1e-6), yMax = maxEnergy * 1.12;
    const x = value => left + (value - startTime) / timeSpan * plotWidth;
    const y = value => bottom - value / yMax * plotHeight;
    ctx.textAlign = "right";
    for (let i = 0; i < 4; i++) {
      const value = yMax * i / 3, yy = y(value);
      ctx.strokeStyle = "#28343c"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(left, yy); ctx.lineTo(right, yy); ctx.stroke();
      ctx.fillStyle = "#91a0a7"; ctx.fillText(value < .1 ? value.toFixed(3) : value < 10 ? value.toFixed(2) : value.toFixed(0), left - 7, yy + 4);
    }
    ctx.strokeStyle = "#62757d"; ctx.beginPath(); ctx.moveTo(left, bottom); ctx.lineTo(right, bottom); ctx.stroke();
    ctx.save(); ctx.beginPath(); ctx.rect(left, top, plotWidth, plotHeight); ctx.clip();
    impacts.forEach((event, index) => {
      const xx = x(event.time), yy = y(event.pistonEnergy * 1000), color = index === 0 ? "#ffbf69" : "#5de4e7";
      ctx.strokeStyle = color; ctx.globalAlpha = .22; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(xx, top); ctx.lineTo(xx, bottom); ctx.stroke();
      ctx.globalAlpha = 1; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(xx, bottom); ctx.lineTo(xx, yy); ctx.stroke();
      ctx.fillStyle = color; ctx.beginPath(); ctx.arc(xx, yy, 4, 0, Math.PI * 2); ctx.fill();
    });
    if (time >= startTime && time <= endTime) {
      const cursor = x(time); ctx.strokeStyle = "#fff"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(cursor, top); ctx.lineTo(cursor, bottom); ctx.stroke();
    }
    ctx.restore();
    ctx.textAlign = "center"; ctx.fillStyle = "#91a0a7";
    ctx.fillText(`${(startTime * 1000).toFixed(2)} ms`, left, h - 10); ctx.fillText(`${(endTime * 1000).toFixed(2)} ms`, right, h - 10);
    impacts.slice(0, 8).forEach((event, index) => {
      const xx = Math.max(left + 8, Math.min(right - 8, x(event.time)));
      ctx.fillStyle = index === 0 ? "#ffbf69" : "#5de4e7"; ctx.fillText(`#${index + 1}`, xx, top - 7);
    });
  }
  window.addEventListener("hashchange", () => { if (busy) return; clearTimeout(debounce); if (location.hash === "#pneumatic-timing") recalculate(); render(); });
  window.addEventListener("resize", () => { if (shot?.valid && $("mechanism")) setFrame(fraction); });
  if (location.hash === "#pneumatic-timing") { shot = P.simulate(p); lastValidShot = shot.valid ? shot : null; baseline = P.simulate({ ...p, airbrakeLength: 0, airbrakeTaper: 0 }); }
  render();
})();
